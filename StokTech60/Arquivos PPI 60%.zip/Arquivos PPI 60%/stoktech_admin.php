<?php
require_once 'auth.php';
require_once 'conexao.php';
verificar_admin();

if (empty($_SESSION['email']) || !isset($_SESSION['foto_perfil'])) {
    $stmt = $pdo->prepare("SELECT EMAIL, FOTO_PERFIL FROM USUARIO WHERE IDUSUARIO = ?");
    $stmt->execute([$_SESSION['idusuario']]);
    $row = $stmt->fetch();
    if ($row) {
        $_SESSION['email']       = $row['EMAIL'];
        $_SESSION['foto_perfil'] = $row['FOTO_PERFIL'];
    }
}

// CPF só para exibição em "Meu perfil" — não fica em sessão de propósito.
$dadosPessoaisAdmin = ['cpf' => ''];
$stmtCpfAdmin = $pdo->prepare("SELECT CPF FROM USUARIO WHERE IDUSUARIO = ?");
$stmtCpfAdmin->execute([$_SESSION['idusuario']]);
if ($rowCpfAdmin = $stmtCpfAdmin->fetch()) {
    $dadosPessoaisAdmin['cpf'] = $rowCpfAdmin['CPF'] ?? '';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="css/protecao.css">
    <title>StokTech — Painel Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
:root {
    --primary: #6b1fad;
    --primary-light: #b662ff;
    --primary-subtle: rgba(107,31,173,0.10);
    --bg: #0d0d0f;
    --surface: #131316;
    --surface-2: #1a1a1f;
    --surface-3: #202028;
    --border: #252530;
    --text: #f0f0f4;
    --text-muted: #7a7a90;
    --text-subtle: #4a4a60;
    --success: #22c55e;
    --warning: #f59e0b;
    --danger: #ef4444;
    --radius: 4px;
    --sidebar-w: 260px;
    --header-h: 64px;
}
body.light-mode {
    --bg: #f0f0f5;
    --surface: #ffffff;
    --surface-2: #f6f6fb;
    --surface-3: #ebebf5;
    --border: #dcdce8;
    --text: #0d0d1a;
    --text-muted: #55556a;
    --text-subtle: #aaaabc;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: 'IBM Plex Sans', sans-serif;
    background: var(--bg); color: var(--text);
    transition: background 0.3s, color 0.3s;
    overflow-x: hidden;
}

/* ── HEADER ── */
.header {
    height: var(--header-h); background: var(--surface);
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; padding: 0 1.5rem; gap: 1rem;
    position: sticky; top: 0; z-index: 200;
}
.logo-img { height: 30px; object-fit: contain; }
.header-sep { width: 1px; height: 20px; background: var(--border); margin: 0 0.25rem; }
.admin-badge {
    font-size: 0.75rem; font-family: 'IBM Plex Mono', monospace;
    text-transform: uppercase; letter-spacing: 0.1em;
    color: var(--primary-light); background: var(--primary-subtle);
    border: 1px solid rgba(107,31,173,0.2);
    padding: 0.2rem 0.5rem; border-radius: 2px;
}
.header-actions { margin-left: auto; display: flex; align-items: center; gap: 0.5rem; }
.hdr-btn {
    width: 42px; height: 42px; background: transparent;
    border: 1px solid var(--border); border-radius: var(--radius);
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    font-size: 1.15rem; color: var(--text-muted); transition: all 0.2s;
}
.hdr-btn svg { width: 20px; height: 20px; }
.hdr-btn:hover { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }

/* Header user profile */
.hdr-user {
    display: flex; align-items: center; gap: 0.65rem;
    cursor: pointer; padding: 0.3rem 0.7rem;
    border-radius: var(--radius); border: 1px solid transparent;
    transition: all 0.2s; position: relative;
}
.hdr-user:hover { border-color: var(--border); background: var(--surface-2); }
.hdr-user:hover .edit-pencil { opacity: 1; }
.hdr-avatar {
    width: 38px; height: 38px; border-radius: 50%;
    background: var(--primary-subtle); border: 2px solid var(--primary);
    overflow: hidden; display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; font-size: 0.98rem; font-weight: 700;
    color: var(--primary-light); font-family: 'IBM Plex Sans', sans-serif;
}
.hdr-avatar img { width: 100%; height: 100%; object-fit: cover; }
.hdr-user-info { display: flex; flex-direction: column; line-height: 1.25; }
.hdr-user-name { font-size: 0.92rem; font-weight: 600; white-space: nowrap; max-width: 150px; overflow: hidden; text-overflow: ellipsis; }
.hdr-user-email { font-size: 0.78rem; color: var(--text-muted); white-space: nowrap; max-width: 150px; overflow: hidden; text-overflow: ellipsis; }
.edit-pencil { opacity: 0; transition: opacity 0.2s; font-size: 0.72rem; color: var(--primary-light); }

/* ── LAYOUT ── */
.main-container { display: flex; }

/* ── SIDEBAR (fixed) ── */
.sidebar {
    width: var(--sidebar-w); flex-shrink: 0;
    background: var(--surface); border-right: 1px solid var(--border);
    min-height: calc(100vh - var(--header-h));
    position: sticky; top: var(--header-h);
    height: calc(100vh - var(--header-h)); overflow-y: auto;
}
.sidebar-inner { padding: 1.25rem 0; }
.sidebar-section-label {
    padding: 0 1.25rem 0.6rem;
    font-size: 0.76rem; font-weight: 600;
    text-transform: uppercase; letter-spacing: 0.1em;
    color: var(--text-subtle); font-family: 'IBM Plex Mono', monospace;
}
.nav-item {
    display: flex; align-items: center; gap: 0.85rem;
    padding: 0.8rem 1.25rem; cursor: pointer;
    color: var(--text-muted); font-size: 1rem; font-weight: 400;
    transition: all 0.15s; border-left: 2px solid transparent;
    position: relative; white-space: nowrap;
}
.nav-item:hover { background: var(--surface-2); color: var(--text); border-left-color: var(--border); }
.nav-item.active { background: var(--primary-subtle); color: var(--primary-light); border-left-color: var(--primary); font-weight: 500; }
.nav-icon {
    width: 20px; height: 20px; display: flex; align-items: center;
    justify-content: center; flex-shrink: 0; opacity: 0.6;
}
.nav-icon svg { width: 19px; height: 19px; }
.nav-item.active .nav-icon, .nav-item:hover .nav-icon { opacity: 1; }
.notification-badge {
    margin-left: auto; background: var(--primary); color: white;
    font-size: 0.7rem; font-weight: 700; font-family: 'IBM Plex Mono', monospace;
    min-width: 20px; height: 20px; padding: 0 5px; border-radius: 999px;
    display: flex; align-items: center; justify-content: center;
}

/* ── CONTENT ── */
.content-area { flex: 1; padding: 2rem; min-width: 0; }
.section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
.section-title { font-size: 1.4rem; font-weight: 600; letter-spacing: -0.02em; }

/* ── STATS ── */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.stat-card {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 1.25rem;
    transition: border-color 0.2s, box-shadow 0.2s;
}
.stat-card:hover { border-color: var(--primary); box-shadow: 0 4px 16px rgba(107,31,173,0.1); }
.stat-icon { font-size: 1.4rem; margin-bottom: 0.6rem; }
.stat-value { font-size: 2rem; font-weight: 700; color: var(--primary-light); font-family: 'IBM Plex Mono', monospace; margin-bottom: 0.2rem; }
.stat-label { font-size: 0.8rem; color: var(--text-muted); }

/* ── TABLES ── */
.table-container { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; overflow-x: auto; }
.table { width: 100%; border-collapse: collapse; min-width: 500px; }
.table thead { background: var(--surface-2); border-bottom: 1px solid var(--border); }
.table th {
    padding: 0.75rem 1rem; text-align: left;
    font-size: 0.75rem; font-weight: 600; text-transform: uppercase;
    letter-spacing: 0.07em; color: var(--text-muted); font-family: 'IBM Plex Mono', monospace;
    white-space: nowrap;
}
.table td { padding: 0.85rem 1rem; font-size: 0.88rem; border-bottom: 1px solid var(--border); vertical-align: middle; }
.table tbody tr:last-child td { border-bottom: none; }
.table tbody tr:hover { background: var(--surface-2); }
.table-actions { display: flex; gap: 0.35rem; }
.btn-icon {
    width: 30px; height: 30px; background: transparent;
    border: 1px solid var(--border); border-radius: 2px;
    cursor: pointer; font-size: 0.85rem; display: flex; align-items: center;
    justify-content: center; transition: all 0.15s; color: var(--text-muted);
}
.btn-icon:hover { background: var(--surface-3); }
.btn-edit:hover { border-color: var(--primary); color: var(--primary-light); }
.btn-delete:hover { border-color: var(--danger); color: var(--danger); }
.btn-ban:hover { border-color: var(--warning); color: var(--warning); }

/* ── BADGES ── */
.badge {
    display: inline-block; padding: 0.2rem 0.6rem;
    font-size: 0.72rem; font-weight: 600; border-radius: 2px;
    font-family: 'IBM Plex Mono', monospace; text-transform: uppercase;
    letter-spacing: 0.04em;
}
.badge-success { background: rgba(34,197,94,0.12); color: var(--success); }
.badge-warning { background: rgba(245,158,11,0.12); color: var(--warning); }
.badge-danger { background: rgba(239,68,68,0.12); color: var(--danger); }
.badge-primary { background: rgba(107,31,173,0.14); color: var(--primary-light); }

/* ── CHAT LIST ── */
.chat-list-admin { display: flex; flex-direction: column; gap: 0.75rem; }
.chat-item {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 1.25rem;
    cursor: pointer; transition: all 0.15s; display: flex; gap: 1rem; align-items: center;
}
.chat-item:hover { border-color: var(--primary); background: var(--primary-subtle); }
.chat-item.pending { border-left: 3px solid var(--warning); }
.chat-avatar-admin {
    width: 44px; height: 44px; border-radius: 50%;
    background: var(--surface-2); border: 1px solid var(--border);
    display: flex; align-items: center; justify-content: center;
    font-size: 0.9rem; font-weight: 700; color: var(--text-muted);
    flex-shrink: 0; font-family: 'IBM Plex Sans', sans-serif;
}
.chat-info { flex: 1; min-width: 0; }
.chat-name { font-weight: 600; font-size: 0.9rem; margin-bottom: 0.2rem; }
.chat-last { color: var(--text-muted); font-size: 0.8rem; margin-bottom: 0.2rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.chat-date { color: var(--text-subtle); font-size: 0.75rem; font-family: 'IBM Plex Mono', monospace; }

/* ── EMPTY STATE ── */
.empty-state { text-align: center; padding: 3.5rem 2rem; color: var(--text-muted); }
.empty-state svg { margin-bottom: 1rem; opacity: 0.3; }
.empty-state p { font-size: 0.9rem; }

/* ── MODALS ── */
.modal {
    display: none; position: fixed; inset: 0;
    background: rgba(0,0,0,0.6); backdrop-filter: blur(4px);
    z-index: 1000; align-items: center; justify-content: center; padding: 1rem;
}
.modal.active { display: flex; animation: fadeModal 0.2s ease; }
@keyframes fadeModal { from { opacity: 0; } to { opacity: 1; } }
.modal-content {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); width: 100%; max-width: 560px;
    max-height: 88vh; overflow: hidden; display: flex; flex-direction: column;
    animation: slideModal 0.25s ease;
}
.modal-large { max-width: 760px; }
.modal-chat { max-width: 500px; max-height: 580px; }
@keyframes slideModal { from { transform: translateY(14px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
.modal-header {
    padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--border);
    display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-shrink: 0;
}
.modal-header h2 { font-size: 1rem; font-weight: 600; }
.close-modal {
    width: 28px; height: 28px; background: transparent; border: none;
    cursor: pointer; color: var(--text-muted); font-size: 1.3rem;
    display: flex; align-items: center; justify-content: center;
    border-radius: 2px; transition: all 0.15s; padding: 0; line-height: 1;
}
.close-modal:hover { color: var(--danger); background: rgba(239,68,68,0.1); }
.modal-body { padding: 1.5rem; overflow-y: auto; flex: 1; }

/* Forms in modals */
.form-group { margin-bottom: 1.25rem; }
.form-group label {
    display: block; font-size: 0.78rem; font-weight: 500;
    color: var(--text-muted); text-transform: uppercase;
    letter-spacing: 0.06em; margin-bottom: 0.45rem;
}
.form-group input,
.form-group select,
.form-group textarea {
    width: 100%; padding: 0.75rem 0.85rem;
    background: var(--surface-2); border: 1px solid var(--border);
    border-radius: var(--radius); color: var(--text);
    font-size: 0.9rem; font-family: 'IBM Plex Sans', sans-serif;
    outline: none; transition: border-color 0.2s;
}
.form-group input:focus, .form-group select:focus, .form-group textarea:focus {
    border-color: var(--primary); box-shadow: 0 0 0 3px rgba(107,31,173,0.1);
}
.form-group select { background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%237a7a90' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 0.75rem center; appearance: none; padding-right: 2rem; }
.form-group textarea { resize: vertical; min-height: 90px; }
.spec-input { display: flex; gap: 0.5rem; margin-bottom: 0.5rem; }
.spec-input input { flex: 1; }
.remove-spec-btn {
    background: rgba(239,68,68,0.1); color: var(--danger);
    border: 1px solid rgba(239,68,68,0.2); border-radius: var(--radius);
    padding: 0 0.75rem; cursor: pointer; font-size: 1.1rem; transition: all 0.15s;
}
.remove-spec-btn:hover { background: rgba(239,68,68,0.2); }
.add-spec-btn {
    width: 100%; padding: 0.65rem; background: transparent; color: var(--text-muted);
    border: 1px dashed var(--border); border-radius: var(--radius); cursor: pointer;
    font-size: 0.85rem; font-family: 'IBM Plex Sans', sans-serif; transition: all 0.2s;
}
.add-spec-btn:hover { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }
.form-actions { display: flex; gap: 0.75rem; margin-top: 1.5rem; }
.cancel-btn {
    flex: 1; padding: 0.85rem; background: transparent; color: var(--text-muted);
    border: 1px solid var(--border); border-radius: var(--radius);
    cursor: pointer; font-weight: 600; font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.88rem; transition: all 0.2s;
}
.cancel-btn:hover { border-color: var(--danger); color: var(--danger); background: rgba(239,68,68,0.08); }
.save-btn {
    flex: 1; padding: 0.85rem; background: var(--primary); color: white; border: none;
    border-radius: var(--radius); cursor: pointer; font-weight: 600;
    font-family: 'IBM Plex Sans', sans-serif; font-size: 0.88rem; transition: background 0.2s;
}
.save-btn:hover { background: var(--primary-light); }
.save-btn:disabled { opacity: 0.6; cursor: not-allowed; }

/* Action buttons */
.action-btn {
    background: var(--primary); color: white; border: none;
    padding: 0.65rem 1.2rem; border-radius: var(--radius);
    cursor: pointer; font-weight: 600; font-size: 0.85rem;
    font-family: 'IBM Plex Sans', sans-serif; transition: all 0.2s;
    display: flex; align-items: center; gap: 0.4rem;
}
.action-btn:hover { background: var(--primary-light); transform: translateY(-1px); }

/* Chat messages */
.chat-messages {
    padding: 1.25rem; overflow-y: auto; flex: 1;
    background: var(--bg); max-height: 360px;
}
.chat-message { padding: 0.75rem 1rem; margin-bottom: 0.6rem; border-radius: var(--radius); font-size: 0.85rem; line-height: 1.6; }
.chat-message.system { background: var(--primary-subtle); border: 1px solid rgba(107,31,173,0.2); }
.chat-message.user { background: var(--surface); border: 1px solid var(--border); margin-left: 15%; }
.chat-message.manager { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.2); margin-right: 15%; }
.chat-input-container {
    padding: 1rem; border-top: 1px solid var(--border);
    display: flex; gap: 0.5rem; flex-shrink: 0;
}
.chat-input-container input {
    flex: 1; padding: 0.65rem 0.85rem; background: var(--surface-2);
    border: 1px solid var(--border); border-radius: var(--radius);
    color: var(--text); font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.88rem; outline: none; transition: border-color 0.2s;
}
.chat-input-container input:focus { border-color: var(--primary); }
.send-btn {
    padding: 0.65rem 1.25rem; background: var(--primary); color: white;
    border: none; border-radius: var(--radius); cursor: pointer;
    font-weight: 600; font-family: 'IBM Plex Sans', sans-serif; font-size: 0.85rem;
    transition: background 0.2s;
}
.send-btn:hover { background: var(--primary-light); }
.loan-request {
    background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.25);
    border-left: 3px solid var(--warning); padding: 1rem;
    border-radius: var(--radius); margin-bottom: 0.6rem;
}
.loan-request strong { color: var(--warning); font-size: 0.88rem; }
.loan-actions { display: flex; gap: 0.5rem; margin-top: 0.75rem; }
.loan-actions button {
    flex: 1; padding: 0.6rem; border: none; border-radius: var(--radius);
    cursor: pointer; font-weight: 600; font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.82rem; transition: all 0.2s;
}
.approve-btn { background: rgba(34,197,94,0.15); color: var(--success); border: 1px solid rgba(34,197,94,0.25) !important; }
.approve-btn:hover { background: rgba(34,197,94,0.25); }
.reject-btn { background: rgba(239,68,68,0.12); color: var(--danger); border: 1px solid rgba(239,68,68,0.2) !important; }
.reject-btn:hover { background: rgba(239,68,68,0.2); }

/* Toast */
.notification-toast {
    position: fixed; top: 72px; right: 1.25rem;
    background: var(--surface); border: 1px solid var(--primary);
    border-left: 3px solid var(--primary); color: var(--text);
    padding: 0.75rem 1rem; border-radius: var(--radius);
    font-size: 0.85rem; font-weight: 500; z-index: 9999; max-width: 280px;
    animation: toastIn 0.2s ease; box-shadow: 0 4px 16px rgba(0,0,0,0.2);
}
@keyframes toastIn { from { opacity: 0; transform: translateX(10px); } to { opacity: 1; transform: translateX(0); } }

/* Responsive */
@media (max-width: 900px) {
    :root { --sidebar-w: 220px; }
    .content-area { padding: 1.25rem; }
}
@media (max-width: 680px) {
    .sidebar { display: none; }
    .hdr-user-info { display: none; }
    .stats-grid { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 480px) {
    .stats-grid { grid-template-columns: 1fr; }
    .content-area { padding: 1rem; }
}

/* ══════════════════════════════════════════════════════════
   CHAT DE EMPRÉSTIMOS — layout estilo WhatsApp Web
   (2ª sidebar com as conversas + painel de chat em tela cheia)
   ══════════════════════════════════════════════════════════ */
body.wa-mode { overflow: hidden; }
.wa-layout {
    display: none; flex: 1; min-width: 0;
    height: calc(100vh - var(--header-h));
    height: calc(100dvh - var(--header-h));
    position: sticky; top: var(--header-h);
    background: var(--bg);
}
.wa-layout.active { display: flex; }

/* ── 2ª sidebar: lista de conversas ── */
.wa-list {
    width: 360px; flex-shrink: 0; min-height: 0;
    display: flex; flex-direction: column;
    background: var(--surface); border-right: 1px solid var(--border);
}
.wa-list-head { padding: 1.1rem 1.1rem 0.8rem; border-bottom: 1px solid var(--border); flex-shrink: 0; }
.wa-list-title {
    display: flex; align-items: center; justify-content: space-between;
    font-size: 1.2rem; font-weight: 600; letter-spacing: -0.01em; margin-bottom: 0.8rem;
}
.wa-live {
    display: inline-flex; align-items: center; gap: 0.4rem;
    font-size: 0.68rem; font-weight: 500; color: var(--text-muted);
    font-family: 'IBM Plex Mono', monospace; letter-spacing: 0.02em;
}
.wa-live i {
    width: 7px; height: 7px; border-radius: 50%; background: var(--success);
    box-shadow: 0 0 0 0 rgba(34,197,94,0.5); animation: waPulse 2s infinite;
}
@keyframes waPulse {
    0% { box-shadow: 0 0 0 0 rgba(34,197,94,0.5); }
    70% { box-shadow: 0 0 0 7px rgba(34,197,94,0); }
    100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); }
}
.wa-search {
    width: 100%; padding: 0.65rem 0.85rem;
    background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--radius);
    color: var(--text); font-size: 0.9rem; font-family: 'IBM Plex Sans', sans-serif; outline: none;
    transition: border-color 0.2s;
}
.wa-search:focus { border-color: var(--primary); }
.wa-search::placeholder { color: var(--text-subtle); }
.wa-filters { display: flex; gap: 0.4rem; margin-top: 0.7rem; flex-wrap: wrap; }
.wa-chip {
    padding: 0.32rem 0.75rem; border-radius: 999px; cursor: pointer;
    background: transparent; border: 1px solid var(--border); color: var(--text-muted);
    font-size: 0.78rem; font-family: 'IBM Plex Sans', sans-serif; font-weight: 500;
    transition: all 0.15s;
}
.wa-chip:hover { border-color: var(--primary); color: var(--text); }
.wa-chip.active { background: var(--primary-subtle); border-color: var(--primary); color: var(--primary-light); }
.wa-list-body { flex: 1; overflow-y: auto; min-height: 0; }
.wa-list-empty { padding: 2.5rem 1.5rem; text-align: center; color: var(--text-muted); font-size: 0.9rem; }

.wa-item {
    display: flex; gap: 0.85rem; align-items: center;
    padding: 0.9rem 1.1rem; cursor: pointer;
    border-bottom: 1px solid var(--border); border-left: 3px solid transparent;
    transition: background 0.15s;
}
.wa-item:hover { background: var(--surface-2); }
.wa-item.active { background: var(--primary-subtle); border-left-color: var(--primary); }
.wa-avatar {
    position: relative; width: 50px; height: 50px; border-radius: 50%; flex-shrink: 0;
    overflow: hidden; display: flex; align-items: center; justify-content: center;
    background: var(--primary-subtle); border: 1px solid var(--border);
    color: var(--primary-light); font-weight: 700; font-size: 1.05rem;
}
.wa-avatar img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
.wa-avatar svg { width: 24px; height: 24px; }
.wa-item-main { flex: 1; min-width: 0; }
.wa-item-top { display: flex; justify-content: space-between; align-items: baseline; gap: 0.5rem; }
.wa-item-name { font-weight: 600; font-size: 0.98rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wa-item-time { font-size: 0.72rem; color: var(--text-subtle); font-family: 'IBM Plex Mono', monospace; flex-shrink: 0; }
.wa-item.unread .wa-item-time { color: var(--primary-light); }
.wa-item-mid { display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; margin-top: 0.25rem; }
.wa-item-preview { font-size: 0.85rem; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; }
.wa-item.unread .wa-item-preview { color: var(--text); font-weight: 500; }
.wa-item-preview.alerta { color: var(--warning); font-weight: 500; }
.wa-item-bot { display: flex; align-items: center; gap: 0.45rem; margin-top: 0.4rem; }
.wa-item-id { font-size: 0.72rem; color: var(--text-subtle); font-family: 'IBM Plex Mono', monospace; }
.wa-unread {
    min-width: 21px; height: 21px; padding: 0 6px; border-radius: 999px; flex-shrink: 0;
    background: var(--primary); color: #fff; font-size: 0.72rem; font-weight: 700;
    font-family: 'IBM Plex Mono', monospace; display: flex; align-items: center; justify-content: center;
}

.wa-status {
    display: inline-block; padding: 0.12rem 0.5rem; border-radius: 2px;
    font-size: 0.68rem; font-weight: 600; letter-spacing: 0.04em; text-transform: uppercase;
    font-family: 'IBM Plex Mono', monospace; white-space: nowrap;
}
.wa-status.st-pendente { background: rgba(245,158,11,0.15); color: var(--warning); }
.wa-status.st-aprovado, .wa-status.st-retirado { background: rgba(34,197,94,0.14); color: var(--success); }
.wa-status.st-devolvido { background: rgba(107,31,173,0.16); color: var(--primary-light); }
.wa-status.st-recusado { background: rgba(239,68,68,0.14); color: var(--danger); }
.wa-status.st-cancelado { background: rgba(156,163,175,0.16); color: #9ca3af; }

/* ── Painel do chat ── */
.wa-chat {
    flex: 1; min-width: 0; min-height: 0; display: flex; flex-direction: column; position: relative;
    background-color: var(--bg);
    background-image: radial-gradient(rgba(182,98,255,0.07) 1px, transparent 1px);
    background-size: 22px 22px;
}
.wa-empty {
    flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
    gap: 0.6rem; padding: 2rem; text-align: center; color: var(--text-muted);
}
.wa-empty svg { width: 64px; height: 64px; opacity: 0.35; margin-bottom: 0.5rem; }
.wa-empty h2 { font-size: 1.25rem; font-weight: 600; color: var(--text); }
.wa-empty p { font-size: 0.92rem; max-width: 340px; line-height: 1.6; }
.wa-conversa { display: none; flex: 1; flex-direction: column; min-height: 0; }

.wa-chat-head {
    display: flex; align-items: center; gap: 0.9rem; flex-shrink: 0;
    padding: 0.75rem 1.25rem; background: var(--surface); border-bottom: 1px solid var(--border);
}
.wa-back {
    display: none; width: 38px; height: 38px; flex-shrink: 0; cursor: pointer;
    align-items: center; justify-content: center; background: transparent;
    border: 1px solid var(--border); border-radius: var(--radius); color: var(--text-muted);
}
.wa-back:hover { border-color: var(--primary); color: var(--primary-light); }
.wa-head-info { flex: 1; min-width: 0; }
.wa-head-name { font-weight: 600; font-size: 1.05rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wa-head-sub {
    font-size: 0.76rem; color: var(--text-muted); margin-top: 0.15rem;
    font-family: 'IBM Plex Mono', monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.wa-head-actions { display: flex; align-items: center; gap: 0.6rem; flex-shrink: 0; }
.wa-head-btn {
    padding: 0.5rem 0.9rem; background: transparent; border: 1px solid var(--border);
    border-radius: var(--radius); color: var(--text-muted); cursor: pointer;
    font-size: 0.8rem; font-weight: 600; font-family: 'IBM Plex Sans', sans-serif; transition: all 0.15s;
}
.wa-head-btn:hover { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }

.wa-actionbar {
    display: none; align-items: center; justify-content: space-between; gap: 0.75rem 1rem; flex-wrap: wrap;
    padding: 0.7rem 1.25rem; flex-shrink: 0; font-size: 0.86rem; line-height: 1.5;
    background: var(--surface-2); border-bottom: 1px solid var(--border);
}
.wa-actionbar.warn { background: rgba(245,158,11,0.09); }
.wa-act-btns { display: flex; gap: 0.5rem; }
.wa-actionbar button {
    padding: 0.5rem 1.05rem; border: none; border-radius: var(--radius); cursor: pointer;
    font-size: 0.82rem; font-weight: 600; font-family: 'IBM Plex Sans', sans-serif; transition: all 0.15s;
}
.wa-actionbar .primary-btn { background: var(--primary); color: #fff; }
.wa-actionbar .primary-btn:hover { background: var(--primary-light); }

.wa-messages {
    flex: 1; min-height: 0; overflow-y: auto; display: flex; flex-direction: column; gap: 0.3rem;
    padding: 1.25rem clamp(1rem, 7%, 7rem);
}
.wa-day { align-self: center; margin: 0.9rem 0 0.5rem; }
.wa-day span {
    display: inline-block; padding: 0.25rem 0.8rem; border-radius: 999px;
    background: var(--surface); border: 1px solid var(--border);
    font-size: 0.72rem; color: var(--text-muted); font-family: 'IBM Plex Mono', monospace;
}
.wa-msg {
    max-width: min(640px, 78%); padding: 0.5rem 0.8rem 0.3rem; border-radius: 10px;
    font-size: 0.95rem; line-height: 1.5; overflow-wrap: anywhere;
    box-shadow: 0 1px 2px rgba(0,0,0,0.12);
}
.wa-msg.theirs { align-self: flex-start; background: var(--surface); border: 1px solid var(--border); border-top-left-radius: 2px; }
.wa-msg.mine { align-self: flex-end; background: var(--primary); color: #fff; border-top-right-radius: 2px; }
.wa-msg-author { font-size: 0.74rem; font-weight: 600; color: var(--primary-light); margin-bottom: 0.15rem; }
.wa-msg.mine .wa-msg-author { color: rgba(255,255,255,0.75); }
.wa-text { white-space: pre-wrap; }
.wa-msg-time { display: block; text-align: right; margin-top: 0.15rem; font-size: 0.68rem; opacity: 0.6; font-family: 'IBM Plex Mono', monospace; }

.wa-card {
    align-self: center; width: min(580px, 94%); margin: 0.45rem 0;
    padding: 0.9rem 1.1rem; border-radius: 8px; font-size: 0.87rem; line-height: 1.65;
    background: var(--primary-subtle); border: 1px solid rgba(107,31,173,0.28); color: var(--text);
}
.wa-card.warn { background: rgba(245,158,11,0.1); border-color: rgba(245,158,11,0.3); }
.wa-card.ok { background: rgba(34,197,94,0.09); border-color: rgba(34,197,94,0.28); }
.wa-card.bad { background: rgba(239,68,68,0.09); border-color: rgba(239,68,68,0.28); }
.wa-card-title { font-weight: 600; font-size: 0.92rem; margin-bottom: 0.4rem; }
.wa-card .wa-msg-time { margin-top: 0.4rem; }
.wa-card-actions { display: flex; gap: 0.5rem; margin-top: 0.75rem; }
.wa-card-actions button {
    flex: 1; padding: 0.55rem; border: none; border-radius: var(--radius); cursor: pointer;
    font-weight: 600; font-family: 'IBM Plex Sans', sans-serif; font-size: 0.82rem;
}
.wa-notice {
    align-self: center; margin: 0.3rem 0; padding: 0.3rem 0.85rem; border-radius: 999px;
    background: var(--surface); border: 1px solid var(--border);
    font-size: 0.76rem; color: var(--text-muted); text-align: center;
}

.wa-input {
    display: flex; align-items: flex-end; gap: 0.6rem; flex-shrink: 0;
    padding: 0.8rem 1.25rem; background: var(--surface); border-top: 1px solid var(--border);
}
.wa-input textarea {
    flex: 1; resize: none; max-height: 130px; min-height: 46px; padding: 0.8rem 1.1rem;
    background: var(--surface-2); border: 1px solid var(--border); border-radius: 23px;
    color: var(--text); font-size: 0.95rem; line-height: 1.4; font-family: 'IBM Plex Sans', sans-serif;
    outline: none; transition: border-color 0.2s;
}
.wa-input textarea:focus { border-color: var(--primary); }
.wa-input textarea::placeholder { color: var(--text-subtle); }
.wa-send {
    width: 46px; height: 46px; flex-shrink: 0; border: none; border-radius: 50%; cursor: pointer;
    background: var(--primary); color: #fff; display: flex; align-items: center; justify-content: center;
    transition: background 0.2s, transform 0.15s;
}
.wa-send:hover { background: var(--primary-light); transform: scale(1.05); }
.wa-send:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }
.wa-send svg { width: 20px; height: 20px; }
.wa-closed {
    display: none; flex-shrink: 0; padding: 1rem 1.25rem; text-align: center;
    background: var(--surface); border-top: 1px solid var(--border);
    font-size: 0.86rem; color: var(--text-muted);
}

@media (max-width: 860px) {
    .wa-list { width: 100%; border-right: none; }
    .wa-chat { display: none; }
    .wa-layout.chat-active .wa-list { display: none; }
    .wa-layout.chat-active .wa-chat { display: flex; }
    .wa-back { display: flex; }
    .wa-messages { padding: 1rem; }
    .wa-msg { max-width: 88%; }
    .wa-chat-head, .wa-input, .wa-actionbar { padding-left: 0.9rem; padding-right: 0.9rem; }
}

/* ── Meu perfil (aba interna do painel, sem modal) ── */
.acc-profile-photo { display: flex; align-items: center; gap: 1.25rem; margin-bottom: 1.75rem; }
.acc-photo-preview {
    width: 84px; height: 84px; border-radius: 50%; overflow: hidden; flex-shrink: 0;
    background: var(--primary-subtle); border: 2px solid var(--primary);
    display: flex; align-items: center; justify-content: center; font-size: 2rem;
}
.acc-photo-preview img { width: 100%; height: 100%; object-fit: cover; }
.acc-readonly-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
.acc-static { padding: 0.75rem 0.85rem; background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--radius); color: var(--text-muted); font-size: 0.9rem; }
.upload-btn {
    background: transparent; border: 1px solid var(--border); color: var(--text-muted);
    padding: 0.55rem 1.25rem; border-radius: var(--radius); cursor: pointer; font-size: 0.82rem;
    font-family: 'IBM Plex Sans', sans-serif; transition: all 0.2s; display: inline-block; white-space: nowrap;
}
.upload-btn:hover { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }

/* ── Calendário de prazos (aba "Prazos") ── */
.acc-cal-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
.acc-cal-nav { display: flex; align-items: center; gap: 0.6rem; }
.acc-cal-nav button {
    width: 34px; height: 34px; border-radius: var(--radius); border: 1px solid var(--border); background: transparent;
    color: var(--text-muted); cursor: pointer; display: flex; align-items: center; justify-content: center;
}
.acc-cal-nav button:hover { border-color: var(--primary); color: var(--primary-light); }
.acc-cal-month { font-weight: 600; font-size: 1.05rem; min-width: 170px; text-align: center; text-transform: capitalize; }
.acc-cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 0.35rem; max-width: 640px; }
.acc-cal-dow { text-align: center; font-size: 0.72rem; color: var(--text-subtle); font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; padding-bottom: 0.4rem; }
.acc-cal-day {
    aspect-ratio: 1; border-radius: 6px; border: 1px solid var(--border); background: var(--surface);
    display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.2rem;
    font-size: 0.85rem; color: var(--text); position: relative; cursor: pointer;
}
.acc-cal-day:hover { border-color: var(--primary); }
.acc-cal-day.outro-mes { opacity: 0.3; }
.acc-cal-day.hoje { border-color: var(--primary); border-width: 2px; font-weight: 700; color: var(--primary-light); }
.acc-cal-day.feriado { background: rgba(239,68,68,0.09); }
.acc-cal-day.ferias { background: rgba(245,158,11,0.1); }
.acc-cal-dots { display: flex; gap: 3px; }
.acc-cal-dots span { width: 5px; height: 5px; border-radius: 50%; }
.acc-cal-legend { display: flex; gap: 1.1rem; flex-wrap: wrap; margin-top: 1.1rem; font-size: 0.8rem; color: var(--text-muted); }
.acc-cal-legend span { display: inline-flex; align-items: center; gap: 0.4rem; }
.acc-cal-legend i { width: 11px; height: 11px; border-radius: 3px; display: inline-block; }

/* ── Modal de confirmação de e-mail (copiado do painel do usuário) ── */
.modal-email { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.65); align-items: center; justify-content: center; z-index: 9999; }
.modal-email-box { background: #131316; border: 1px solid #6b1fad; border-radius: 10px; padding: 30px; width: 380px; text-align: center; color: #f0f0f4; font-family: 'IBM Plex Sans', sans-serif; }
.modal-email-box h2 { color: #ffffff; margin-bottom: 15px; }
.modal-email-box p { color: #7a7a90; margin-bottom: 20px; }
.modal-email-box input { width: 100%; padding: 12px; background: #1a1a1f; border: 1px solid #252530; color: white; border-radius: 4px; text-align: center; font-size: 20px; letter-spacing: 5px; margin-bottom: 20px; }
.modal-email-box button { padding: 10px 20px; margin: 5px; background: #6b1fad; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: 600; }
.modal-email-box button:hover { background: #b662ff; }

/* ── "Minha conta" — mesmo padrão visual do painel do usuário ── */
.acc-nav {
    width: 250px; flex-shrink: 0; min-height: 0; overflow-y: auto;
    background: var(--surface); border-right: 1px solid var(--border);
    padding: 1.1rem 0.9rem;
}
.acc-nav-title { font-size: 1.15rem; font-weight: 600; padding: 0 0.5rem 1rem; letter-spacing: -0.01em; }
.acc-tab {
    display: flex; align-items: center; gap: 0.8rem; width: 100%;
    padding: 0.75rem 0.9rem; margin-bottom: 0.2rem; border-radius: var(--radius);
    background: transparent; border: none; cursor: pointer; text-align: left;
    color: var(--text-muted); font-size: 0.92rem; font-family: 'IBM Plex Sans', sans-serif;
    transition: all 0.15s; position: relative;
}
.acc-tab svg { width: 19px; height: 19px; flex-shrink: 0; opacity: 0.75; }
.acc-tab:hover { background: var(--surface-2); color: var(--text); }
.acc-tab.active { background: var(--primary-subtle); color: var(--primary-light); font-weight: 600; }
.acc-tab.active svg { opacity: 1; }
.acc-content { flex: 1; min-width: 0; overflow-y: auto; padding: 1.75rem clamp(1.25rem, 4%, 3rem); }
.acc-section { display: none; max-width: 880px; }
.acc-section.active { display: block; }
.acc-head { margin-bottom: 1.5rem; }
.acc-head h2 { font-size: 1.4rem; font-weight: 600; letter-spacing: -0.01em; margin-bottom: 0.3rem; }
.acc-head p { color: var(--text-muted); font-size: 0.9rem; }

@media (max-width: 860px) {
    #adminProfileLayout { flex-direction: column; }
    .acc-nav { width: 100%; display: flex; gap: 0.5rem; padding: 0.9rem; border-right: none; border-bottom: 1px solid var(--border); flex-shrink: 0; align-items: center; }
    .acc-nav-title { flex: 1; padding: 0; }
    .acc-content { padding: 1.25rem 1rem; }
    .acc-readonly-row { grid-template-columns: 1fr; }
}
    </style>
</head>
<body>
    <!-- HEADER -->
    <header class="header">
        <img class="logo-img" src="img/logo_stoktech.png" alt="StokTech">
        <div class="header-sep"></div>
        <span class="admin-badge">Admin</span>
        <div class="header-actions">
            <a class="hdr-btn" href="menu_principal.php?visao=usuario" title="Ver como usuário" style="text-decoration:none; display:flex; align-items:center; justify-content:center;">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z"/><circle cx="12" cy="12" r="3"/></svg>
            </a>
            <button class="hdr-btn" id="themeToggle" title="Alternar tema">&#9790;</button>
            <div class="hdr-user" id="profileBtn" title="Meu perfil">
                <div class="hdr-avatar" id="headerAvatar">A</div>
                <div class="hdr-user-info">
                    <span class="hdr-user-name" id="headerAdminName"><?= htmlspecialchars($_SESSION['nome'] ?? 'Administrador') ?></span>
                    <span class="hdr-user-email" id="headerAdminEmail"><?= htmlspecialchars($_SESSION['email'] ?? '') ?></span>
                </div>
                <span class="edit-pencil">&#9998;</span>
            </div>
            <button class="hdr-btn" id="logoutBtn" title="Sair">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
            </button>
        </div>
    </header>

    <div class="main-container">
        <!-- SIDEBAR (fixed) -->
        <aside class="sidebar" id="adminSidebar">
            <div class="sidebar-inner">
                <div class="sidebar-section-label">Navegação</div>
                <nav>
                    <div class="nav-item active" data-section="dashboard">
                        <span class="nav-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect></svg></span>
                        Dashboard
                    </div>
                    <div class="nav-item" data-section="components">
                        <span class="nav-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="6" height="6"></rect><path d="M3 9h2M3 12h2M3 15h2M19 9h2M19 12h2M19 15h2M9 3v2M12 3v2M15 3v2M9 19v2M12 19v2M15 19v2"></path><rect x="5" y="5" width="14" height="14" rx="1"></rect></svg></span>
                        Componentes
                    </div>
                    <div class="nav-item" data-section="categories">
                        <span class="nav-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg></span>
                        Categorias
                    </div>
                    <div class="nav-item" data-section="chats">
                        <span class="nav-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg></span>
                        Empréstimos
                        <span class="notification-badge" id="chatBadge">0</span>
                    </div>
                    <div class="nav-item" data-section="prazos">
                        <span class="nav-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><path d="M16 2v4M8 2v4M3 10h18"></path></svg></span>
                        Prazos
                    </div>
                    <div class="nav-item" data-section="users">
                        <span class="nav-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg></span>
                        Usuários
                    </div>
                    <div class="nav-item" data-section="logs">
                        <span class="nav-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg></span>
                        Logs
                    </div>
                </nav>
            </div>
        </aside>

        <!-- CONTENT -->
        <main class="content-area" id="contentArea"></main>

        <!-- CHAT DE EMPRÉSTIMOS: 2ª sidebar (conversas) + chat em tela cheia, estilo WhatsApp Web -->
        <div class="wa-layout" id="waLayout">
            <aside class="wa-list">
                <div class="wa-list-head">
                    <div class="wa-list-title">
                        <span>Empréstimos</span>
                        <span class="wa-live" title="Esta lista atualiza sozinha"><i></i>ao vivo</span>
                    </div>
                    <input type="text" class="wa-search" id="waSearch" placeholder="Buscar aluno ou nº do empréstimo" autocomplete="off">
                    <div class="wa-filters" id="waFilters">
                        <button type="button" class="wa-chip active" data-filtro="todos">Todos</button>
                        <button type="button" class="wa-chip" data-filtro="pendentes">Pendentes</button>
                        <button type="button" class="wa-chip" data-filtro="andamento">Em andamento</button>
                        <button type="button" class="wa-chip" data-filtro="encerrados">Encerrados</button>
                    </div>
                </div>
                <div class="wa-list-body" id="waListBody"></div>
            </aside>

            <section class="wa-chat">
                <div class="wa-empty" id="waEmpty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                    <h2>Chat de empréstimos</h2>
                    <p>Selecione uma conversa ao lado para ver o pedido, responder ao aluno e aprovar, recusar ou dar baixa no empréstimo.</p>
                </div>

                <div class="wa-conversa" id="waConversa">
                    <div class="wa-chat-head">
                        <button type="button" class="wa-back" id="waBack" title="Voltar para a lista">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                        </button>
                        <div class="wa-avatar" id="waHeadAvatar"></div>
                        <div class="wa-head-info">
                            <div class="wa-head-name" id="chatUserName"></div>
                            <div class="wa-head-sub" id="chatUserEmail"></div>
                        </div>
                        <div class="wa-head-actions">
                            <span id="waHeadStatus"></span>
                            <button type="button" class="wa-head-btn" onclick="saveChat()">Salvar log</button>
                        </div>
                    </div>
                    <div class="wa-actionbar" id="waActionBar"></div>
                    <div class="wa-messages" id="chatMessagesAdmin"></div>
                    <div class="wa-input" id="waInputArea">
                        <textarea id="chatInputAdmin" rows="1" placeholder="Digite uma mensagem"></textarea>
                        <button type="button" class="wa-send" id="sendMessageAdmin" title="Enviar">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                        </button>
                    </div>
                    <div class="wa-closed" id="waClosed">Este empréstimo está encerrado e não aceita mais mensagens.</div>
                </div>
            </section>
        </div>

        <!-- MINHA CONTA (perfil do gerenciador) — mesmo padrão visual do painel do usuário -->
        <div class="wa-layout" id="adminProfileLayout">
            <aside class="acc-nav">
                <div class="acc-nav-title" style="display:flex;align-items:center;justify-content:space-between;">
                    Minha conta
                    <button type="button" onclick="abrirPerfilAdmin()" title="Voltar" style="background:transparent;border:1px solid var(--border);border-radius:var(--radius);width:30px;height:30px;color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                    </button>
                </div>
                <button type="button" class="acc-tab active" data-aba="dados">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    Dados Pessoais
                </button>
            </aside>

            <div class="acc-content">
                <section class="acc-section active" id="admAccDados">
                    <div class="acc-head"><h2>Dados pessoais</h2><p>Suas informações de administrador no StokTech.</p></div>

                    <div class="acc-profile-photo">
                        <div class="acc-photo-preview" id="profilePreview">&#9751;</div>
                        <div>
                            <label for="profileImageInput" class="upload-btn" style="cursor:pointer;">Alterar foto</label>
                            <input type="file" id="profileImageInput" accept="image/*" style="display:none;" onchange="handleProfileImageUploadAdmin(event)">
                        </div>
                    </div>

                    <div class="acc-readonly-row" style="margin-bottom:1.25rem;">
                        <div class="form-group" style="margin-bottom:0;"><label>CPF</label><div class="acc-static" id="profCpf">—</div></div>
                        <div class="form-group" style="margin-bottom:0;"><label>Tipo de conta</label><div class="acc-static">Administrador</div></div>
                    </div>

                    <div class="form-group"><label>Nome *</label><input type="text" id="profileName"></div>
                    <div class="form-group"><label>Email *</label><input type="email" id="profileEmail"></div>
                    <div class="form-group"><label>Nova senha (deixe em branco para manter)</label><input type="password" id="profilePassword" placeholder="••••••••"></div>
                    <div class="form-group"><label>Confirmar nova senha</label><input type="password" id="profileConfirmPassword" placeholder="••••••••"></div>
                    <div class="form-actions">
                        <button type="button" class="cancel-btn" onclick="carregarCamposPerfilAdmin()">Desfazer alterações</button>
                        <button type="button" class="save-btn" id="saveProfileBtn" onclick="salvarPerfilAdmin()">Salvar alterações</button>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <!-- COMPONENT MODAL -->
    <div class="modal" id="componentModal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2 id="componentModalTitle">Adicionar Componente</h2>
                <button class="close-modal" id="closeComponentModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="componentForm" enctype="multipart/form-data">
                    <input type="hidden" id="compId">
                    <input type="hidden" id="compImagemAtual">
                    <div class="form-group">
                        <label>Imagem do Componente</label>
                        <div id="imagePreviewContainer" style="margin-bottom:0.5rem;">
                            <img id="imagePreview" src="" style="display:none;width:100px;height:100px;object-fit:cover;border-radius:var(--radius);border:1px solid var(--border);">
                        </div>
                        <input type="file" id="compImagem" accept="image/*" onchange="previewImage(this)" style="color:var(--text-muted);font-size:0.85rem;">
                    </div>
                    <div class="form-group">
                        <label>Nome do Componente *</label>
                        <input type="text" id="compName" required placeholder="Ex: Arduino Uno R3">
                    </div>
                    <div class="form-group">
                        <label>Categoria *</label>
                        <select id="compCategory" required>
                            <option value="">Selecione uma categoria</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Descrição Curta *</label>
                        <input type="text" id="compDescription" placeholder="Resumo em uma linha" required>
                    </div>
                    <div class="form-group">
                        <label>Descrição Completa *</label>
                        <textarea id="compFullDescription" rows="3" required placeholder="Descrição técnica completa"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Quantidade em Estoque *</label>
                        <input type="number" id="compStock" min="0" required placeholder="0">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="cancel-btn" onclick="closeComponentModal()">Cancelar</button>
                        <button type="submit" class="save-btn">Salvar Componente</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- CATEGORY MODAL -->
    <div class="modal" id="categoryModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="categoryModalTitle">Adicionar Categoria</h2>
                <button class="close-modal" id="closeCategoryModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="categoryForm">
                    <input type="hidden" id="catId">
                    <div class="form-group">
                        <label>Ícone / Emoji *</label>
                        <input type="text" id="catIcon" placeholder="Ex: 🔌" maxlength="2" required>
                    </div>
                    <div class="form-group">
                        <label>Nome da Categoria *</label>
                        <input type="text" id="catName" required placeholder="Ex: Microcontroladores">
                    </div>
                    <div class="form-group">
                        <label>Descrição</label>
                        <input type="text" id="catDescricao" placeholder="Opcional">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="cancel-btn" onclick="closeCategoryModal()">Cancelar</button>
                        <button type="submit" class="save-btn">Salvar Categoria</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- USER MODAL -->
    <div class="modal" id="userModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Editar Usuário</h2>
                <button class="close-modal" id="closeUserModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="userForm">
                    <input type="hidden" id="userId">
                    <div class="form-group">
                        <label>Nome *</label>
                        <input type="text" id="userName" required>
                    </div>
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" id="userEmail" required>
                    </div>
                    <div class="form-group">
                        <label>CPF *</label>
                        <input type="text" id="userCpf" required>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="cancel-btn" onclick="closeUserModal()">Cancelar</button>
                        <button type="submit" class="save-btn">Salvar Alterações</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- EVENTO (PRAZOS) MODAL -->
    <div class="modal" id="eventoModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="eventoModalTitle">Novo evento</h2>
                <button class="close-modal" id="closeEventoModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="eventoForm">
                    <input type="hidden" id="eventoId">
                    <div class="form-group">
                        <label>Tipo *</label>
                        <select id="eventoTipo" required>
                            <option value="FERIADO">Feriado</option>
                            <option value="FERIAS">Férias</option>
                            <option value="IMPORTANTE">Data importante</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Título *</label>
                        <input type="text" id="eventoTitulo" required placeholder="Ex: Recesso de julho">
                    </div>
                    <div class="form-group">
                        <label>Data de início *</label>
                        <input type="date" id="eventoDataInicio" required>
                    </div>
                    <div class="form-group">
                        <label>Data final (opcional — deixe em branco para um evento de um dia só)</label>
                        <input type="date" id="eventoDataFim">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="cancel-btn" onclick="closeEventoModal()">Cancelar</button>
                        <button type="submit" class="save-btn">Salvar evento</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- MODAL CONFIRMAR EMAIL -->
    <div id="modalConfirmarEmail" class="modal-email">
        <div class="modal-email-box">
            <h2>Confirmar novo email</h2>
            <p>Enviamos um código de confirmação para o novo email informado.</p>
            <input type="text" id="codigoConfirmacaoEmail" maxlength="6" placeholder="Digite o código">
            <button type="button" onclick="confirmarEmailNovoAdmin()">Confirmar</button>
            <button type="button" onclick="fecharModalEmailAdmin()">Cancelar</button>
        </div>
    </div>

    <script>
        let categories = [];
        let components = [];
        let users = [];
        let chats = [];
        let emprestimos = [];
        let logs = [];
        let currentChatId = null;
        let adminProfile = {
            name: <?= json_encode($_SESSION['nome'] ?? 'Administrador') ?>,
            email: <?= json_encode($_SESSION['email'] ?? '') ?>,
            foto: <?= json_encode($_SESSION['foto_perfil'] ?? '') ?>
        };
        const DADOS_PESSOAIS_ADMIN = <?= json_encode($dadosPessoaisAdmin, JSON_UNESCAPED_UNICODE) ?>;
        let secaoAntesPerfil = 'dashboard';
        let eventosAdmin = [];
        let admCalRef = new Date();

        document.addEventListener('DOMContentLoaded', () => {
            loadTheme();
            updateHeaderProfile();
            setupEventListeners();
            carregarBadgeEmprestimos();
            loadSection('dashboard');
        });

        function setupEventListeners() {
            document.getElementById('themeToggle').addEventListener('click', toggleTheme);
            document.querySelectorAll('.nav-item').forEach(item => {
                item.addEventListener('click', function() {
                    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
                    this.classList.add('active');
                    loadSection(this.dataset.section);
                });
            });
            document.getElementById('logoutBtn').addEventListener('click', logout);
            document.getElementById('profileBtn').addEventListener('click', abrirPerfilAdmin);
            document.getElementById('closeEventoModal').addEventListener('click', closeEventoModal);
            document.getElementById('eventoForm').addEventListener('submit', saveEvento);
            document.getElementById('closeComponentModal').addEventListener('click', closeComponentModal);
            document.getElementById('componentForm').addEventListener('submit', saveComponent);
            document.getElementById('closeCategoryModal').addEventListener('click', closeCategoryModal);
            document.getElementById('categoryForm').addEventListener('submit', saveCategory);
            document.getElementById('closeUserModal').addEventListener('click', closeUserModal);
            document.getElementById('userForm').addEventListener('submit', saveUser);
            waConfigurar();
            document.querySelectorAll('.modal').forEach(modal => {
                modal.addEventListener('click', function(e) { if(e.target === this) this.classList.remove('active'); });
            });
        }

        // Theme
        function loadTheme() {
            if (localStorage.getItem('theme') === 'light') { document.body.classList.add('light-mode'); document.getElementById('themeToggle').innerHTML = '&#9728;'; }
        }
        function toggleTheme() {
            document.body.classList.toggle('light-mode');
            const isLight = document.body.classList.contains('light-mode');
            localStorage.setItem('theme', isLight ? 'light' : 'dark');
            document.getElementById('themeToggle').innerHTML = isLight ? '&#9728;' : '&#9790;';
        }

        async function logout() {
            const ok = await stoktechConfirm({ titulo: 'Sair do sistema', mensagem: 'Deseja realmente sair do sistema?', textoConfirmar: 'Sair' });
            if (ok) {
                showNotification('Saindo...');
                setTimeout(() => window.location.href = 'sairdacontasuperlegal.php', 800);
            }
        }

        // Header profile
        function updateHeaderProfile() {
            document.getElementById('headerAdminName').textContent = adminProfile.name;
            document.getElementById('headerAdminEmail').textContent = adminProfile.email;
            const av = document.getElementById('headerAvatar');
            av.innerHTML = adminProfile.foto
                ? `<img src="${adminProfile.foto}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`
                : (adminProfile.name ? adminProfile.name.charAt(0).toUpperCase() : 'A');
        }

        // Section loader
        function loadSection(section) {
            secaoAtual = section;
            const ca = document.getElementById('contentArea');
            const modoChat = section === 'chats';
            const modoPerfil = section === 'perfil';
            // "Minha conta" é uma tela cheia própria (igual ao chat), com sua
            // própria sidebar interna — não usa o contentArea normal.
            ca.style.display = (modoChat || modoPerfil) ? 'none' : '';
            document.getElementById('waLayout').classList.toggle('active', modoChat);
            document.getElementById('adminProfileLayout').classList.toggle('active', modoPerfil);
            document.body.classList.toggle('wa-mode', modoChat || modoPerfil);
            // Enquanto o gerenciador está editando o próprio perfil, a
            // sidebar de navegação principal some; volta ao fechar o perfil.
            const sidebarEl = document.getElementById('adminSidebar');
            if (sidebarEl) sidebarEl.style.display = modoPerfil ? 'none' : '';
            if (modoPerfil) { carregarCamposPerfilAdmin(); return; }
            switch(section) {
                case 'dashboard': ca.innerHTML = renderDashboard(); carregarDashboard(); break;
                case 'components': renderComponents(); break;
                case 'categories': renderCategories(); break;
                case 'chats': renderChats(); break;
                case 'users': renderUsers(); break;
                case 'logs': ca.innerHTML = renderLogs(); break;
                case 'prazos': renderPrazos(); break;
            }
        }

        // Clicar de novo no botão de perfil volta exatamente pra seção
        // (ou chat) em que o gerenciador estava antes de clicar.
        function abrirPerfilAdmin() {
            if (secaoAtual === 'perfil') { loadSection(secaoAntesPerfil || 'dashboard'); return; }
            secaoAntesPerfil = secaoAtual;
            loadSection('perfil');
        }

        function renderDashboard() {
            return `
                <div class="section-header"><h1 class="section-title">Dashboard</h1></div>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">&#128230;</div>
                        <div class="stat-value" id="dashTotalComponentes">0</div>
                        <div class="stat-label">Tipos de Componentes</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">&#9826;</div>
                        <div class="stat-value" id="dashTotalEstoque">0</div>
                        <div class="stat-label">Itens em Estoque</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">&#9203;</div>
                        <div class="stat-value" id="dashPendentes">0</div>
                        <div class="stat-label">Solicitações Pendentes</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">&#128100;</div>
                        <div class="stat-value" id="dashUsuarios">0</div>
                        <div class="stat-label">Usuários Cadastrados</div>
                    </div>
                </div>
                <div class="section-header"><h2 style="font-size:1rem;font-weight:600;color:var(--text-muted);">Atividade Recente</h2></div>
                <div class="table-container">
                    <table class="table">
                        <thead><tr><th>Aluno</th><th>Ação</th><th>Data</th><th>Status</th></tr></thead>
                        <tbody id="dashAtividade">
                            <tr><td colspan="4" style="text-align:center;padding:2rem;color:var(--text-muted);font-size:0.85rem;">Carregando...</td></tr>
                        </tbody>
                    </table>
                </div>`;
        }

        async function carregarDashboard() {
            try {
                const fdComp = new FormData(); fdComp.append('acao', 'listar_componentes');
                const resComp = await fetch('gerenciar_componentes.php', { method: 'POST', body: fdComp });
                const dataComp = await resComp.json();
                if (dataComp.sucesso) components = dataComp.componentes;

                const fdUser = new FormData(); fdUser.append('acao', 'listar');
                const resUser = await fetch('gerenciar_usuarios.php', { method: 'POST', body: fdUser });
                const dataUser = await resUser.json();
                if (dataUser.sucesso) users = dataUser.usuarios;

                await carregarEmprestimos();

                const totalStock = components.reduce((s, c) => s + (parseInt(c.QUANTIDADE) || 0), 0);
                document.getElementById('dashTotalComponentes').textContent = components.length;
                document.getElementById('dashTotalEstoque').textContent = totalStock;
                document.getElementById('dashPendentes').textContent = emprestimos.filter(e => e.STATUS === 'PENDENTE').length;
                document.getElementById('dashUsuarios').textContent = users.length;

                const tbody = document.getElementById('dashAtividade');
                if (!emprestimos.length) {
                    tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;padding:2rem;color:var(--text-muted);font-size:0.85rem;">Nenhuma solicitação registrada.</td></tr>`;
                    return;
                }
                tbody.innerHTML = emprestimos.slice(0, 5).map(e => `
                    <tr>
                        <td>${e.ALUNO_NOME || '—'}</td>
                        <td>Solicitou empréstimo de ${e.ITENS.length} item${e.ITENS.length !== 1 ? 'ns' : ''}</td>
                        <td style="font-family:'IBM Plex Mono',monospace;font-size:0.8rem;">${formatarData(e.DATA_EMPRESTIMO)}</td>
                        <td>${statusBadge(e.STATUS)}</td>
                    </tr>`).join('');
            } catch(e) {
                const tbody = document.getElementById('dashAtividade');
                if (tbody) tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;padding:2rem;color:var(--danger);font-size:0.85rem;">Erro ao carregar dashboard.</td></tr>`;
            }
        }

        async function renderComponents() {
            const ca = document.getElementById('contentArea');
            ca.innerHTML = `<div class="section-header"><h1 class="section-title">Componentes</h1></div><div style="text-align:center;padding:3rem;color:var(--text-muted);font-size:0.88rem;">Carregando...</div>`;
            try {
                const fd = new FormData(); fd.append('acao', 'listar_componentes');
                const res = await fetch('gerenciar_componentes.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (!data.sucesso) { ca.innerHTML = `<div class="empty-state"><p>Erro ao carregar componentes.</p></div>`; return; }
                components = data.componentes;
                ca.innerHTML = `
                    <div class="section-header">
                        <h1 class="section-title">Componentes</h1>
                        <button class="action-btn" onclick="openAddComponent()">+ Adicionar</button>
                    </div>
                    <div class="table-container">
                        <table class="table">
                            <thead><tr><th>Imagem</th><th>Nome</th><th>Categoria</th><th>Estoque</th><th>Criado por</th><th>Ações</th></tr></thead>
                            <tbody>
                                ${components.length === 0 ? `<tr><td colspan="6" style="text-align:center;padding:2rem;color:var(--text-muted);font-size:0.85rem;">Nenhum componente cadastrado ainda.</td></tr>` : components.map(comp => `
                                    <tr>
                                        <td>${comp.IMAGEM ? `<img src="${comp.IMAGEM}" style="width:44px;height:44px;object-fit:cover;border-radius:var(--radius);border:1px solid var(--border);">` : `<div style="width:44px;height:44px;background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:1.2rem;">&#128230;</div>`}</td>
                                        <td><strong style="font-size:0.88rem;">${comp.NOME}</strong><br><span style="color:var(--text-muted);font-size:0.78rem;">${comp.DESCRICAO_CURTA}</span></td>
                                        <td style="font-size:0.85rem;">${comp.CATEGORIA_ICONE || ''} ${comp.CATEGORIA_NOME || '—'}</td>
                                        <td><span class="badge ${comp.QUANTIDADE > 10 ? 'badge-success' : 'badge-warning'}">${comp.QUANTIDADE}</span></td>
                                        <td style="font-size:0.78rem;color:var(--text-muted);font-family:'IBM Plex Mono',monospace;">${comp.CRIADO_POR_NOME || '—'}</td>
                                        <td class="table-actions">
                                            <button class="btn-icon btn-edit" onclick="editComponent(${comp.IDCOMPONENTE})" title="Editar">&#9998;</button>
                                            <button class="btn-icon btn-delete" onclick="deleteComponent(${comp.IDCOMPONENTE})" title="Excluir">&#128465;</button>
                                        </td>
                                    </tr>`).join('')}
                            </tbody>
                        </table>
                    </div>`;
            } catch { ca.innerHTML = `<div class="empty-state"><p>Erro de conexão.</p></div>`; }
        }

        async function renderCategories() {
            const ca = document.getElementById('contentArea');
            ca.innerHTML = `<div class="section-header"><h1 class="section-title">Categorias</h1></div><div style="text-align:center;padding:3rem;color:var(--text-muted);font-size:0.88rem;">Carregando...</div>`;
            try {
                const fd = new FormData(); fd.append('acao', 'listar_categorias');
                const res = await fetch('gerenciar_componentes.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (!data.sucesso) { ca.innerHTML = `<div class="empty-state"><p>Erro ao carregar categorias.</p></div>`; return; }
                categories = data.categorias;
                ca.innerHTML = `
                    <div class="section-header">
                        <h1 class="section-title">Categorias</h1>
                        <button class="action-btn" onclick="openAddCategory()">+ Adicionar</button>
                    </div>
                    <div class="table-container">
                        <table class="table">
                            <thead><tr><th>Ícone</th><th>Nome</th><th>Descrição</th><th>Ações</th></tr></thead>
                            <tbody>
                                ${categories.length === 0 ? `<tr><td colspan="4" style="text-align:center;padding:2rem;color:var(--text-muted);font-size:0.85rem;">Nenhuma categoria cadastrada.</td></tr>` : categories.map(cat => `
                                    <tr>
                                        <td style="font-size:1.4rem;">${cat.ICONE}</td>
                                        <td><strong style="font-size:0.88rem;">${cat.NOME}</strong></td>
                                        <td style="color:var(--text-muted);font-size:0.85rem;">${cat.DESCRIÇÃO || '—'}</td>
                                        <td class="table-actions">
                                            <button class="btn-icon btn-edit" onclick="editCategory(${cat.IDCATEGORIA})" title="Editar">&#9998;</button>
                                            <button class="btn-icon btn-delete" onclick="deleteCategory(${cat.IDCATEGORIA})" title="Excluir">&#128465;</button>
                                        </td>
                                    </tr>`).join('')}
                            </tbody>
                        </table>
                    </div>`;
            } catch { ca.innerHTML = `<div class="empty-state"><p>Erro de conexão.</p></div>`; }
        }

        async function carregarEmprestimos() {
            const fd = new FormData(); fd.append('acao', 'listar');
            const res = await fetch('gerenciar_emprestimos.php', { method: 'POST', body: fd, cache: 'no-store' });
            const data = await res.json();
            if (data.sucesso) {
                emprestimos = data.emprestimos;
                waAposCarregar();
            }
            return emprestimos;
        }

        async function carregarBadgeEmprestimos() {
            try { await carregarEmprestimos(); } catch(e) {}
        }

        function statusBadge(status) {
    const s = (status || 'PENDENTE').toUpperCase();

    if (s === 'PENDENTE') {
        return '<span class="badge badge-warning">Pendente</span>';
    }

    if (s === 'APROVADO') {
        return '<span class="badge badge-success">Aprovado</span>';
    }

    if (s === 'RETIRADO') {
        return '<span class="badge badge-success">Retirado</span>';
    }

    if (s === 'DEVOLVIDO') {
        return '<span class="badge badge-success">Devolvido</span>';
    }

    if (s === 'RECUSADO') {
        return '<span class="badge badge-danger">Recusado</span>';
    }

    if (s === 'CANCELADO') {
        return '<span class="badge badge-danger">Cancelado</span>';
    }

    return '<span class="badge badge-warning">' + s + '</span>';
}

        function formatarData(data) {
            if (!data) return '—';
            const partes = String(data).split('-');
            if (partes.length === 3) return `${partes[2]}/${partes[1]}/${partes[0]}`;
            return data;
        }

        async function renderUsers() {
            const ca = document.getElementById('contentArea');
            ca.innerHTML = `<div class="section-header"><h1 class="section-title">Usuários</h1></div><div style="text-align:center;padding:3rem;color:var(--text-muted);font-size:0.88rem;">Carregando...</div>`;
            try {
                const fd = new FormData(); fd.append('acao', 'listar');
                const res = await fetch('gerenciar_usuarios.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (!data.sucesso) { ca.innerHTML = `<div class="empty-state"><p>Erro ao carregar usuários.</p></div>`; return; }
                users = data.usuarios;
                ca.innerHTML = `
                    <div class="section-header"><h1 class="section-title">Usuários</h1></div>
                    <div class="table-container">
                        <table class="table">
                            <thead><tr><th>Nome</th><th>Email</th><th>CPF</th><th>Tipo</th><th>Ações</th></tr></thead>
                            <tbody>
                                ${users.map(u => `
                                    <tr id="user-row-${u.IDUSUARIO}">
                                        <td><strong style="font-size:0.88rem;">${u.NOME}</strong></td>
                                        <td style="font-family:'IBM Plex Mono',monospace;font-size:0.8rem;">${u.EMAIL}</td>
                                        <td style="font-family:'IBM Plex Mono',monospace;font-size:0.8rem;">${u.CPF}</td>
                                        <td><span class="badge ${u.TIPO === 'ADMINISTRADOR' ? 'badge-danger' : 'badge-success'}">${u.TIPO === 'ADMINISTRADOR' ? 'Admin' : 'Aluno'}</span></td>
                                        <td class="table-actions">
                                            <button class="btn-icon btn-edit" onclick="editUser(${u.IDUSUARIO})" title="Editar">&#9998;</button>
                                            <button class="btn-icon btn-ban" onclick="toggleAdmin(${u.IDUSUARIO})" title="${u.TIPO === 'ADMINISTRADOR' ? 'Remover Admin' : 'Tornar Admin'}">&#9733;</button>
                                            <button class="btn-icon btn-delete" onclick="deleteUser(${u.IDUSUARIO})" title="Excluir">&#128465;</button>
                                        </td>
                                    </tr>`).join('')}
                            </tbody>
                        </table>
                    </div>`;
            } catch { ca.innerHTML = `<div class="empty-state"><p>Erro de conexão.</p></div>`; }
        }

        function renderLogs() {
            if (!logs.length) return `<div class="section-header"><h1 class="section-title">Logs</h1></div><div class="empty-state"><p>Nenhum log salvo ainda.</p></div>`;
            return `
                <div class="section-header"><h1 class="section-title">Logs</h1></div>
                <div class="table-container">
                    <table class="table">
                        <thead><tr><th>Arquivo</th><th>Usuário</th><th>Data</th><th>Ações</th></tr></thead>
                        <tbody>
                            ${logs.map((log, i) => `
                                <tr>
                                    <td style="font-family:'IBM Plex Mono',monospace;font-size:0.8rem;"><strong>${log.filename}</strong></td>
                                    <td style="font-size:0.85rem;">${log.userName}</td>
                                    <td style="font-family:'IBM Plex Mono',monospace;font-size:0.78rem;color:var(--text-muted);">${log.date}</td>
                                    <td class="table-actions">
                                        <button class="btn-icon" onclick="downloadLog(${i})" title="Baixar">&#8595;</button>
                                        <button class="btn-icon btn-delete" onclick="deleteLog(${i})" title="Excluir">&#128465;</button>
                                    </td>
                                </tr>`).join('')}
                        </tbody>
                    </table>
                </div>`;
        }

        // Component CRUD
        function previewImage(input) {
            const preview = document.getElementById('imagePreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = e => { preview.src = e.target.result; preview.style.display = 'block'; };
                reader.readAsDataURL(input.files[0]);
            }
        }
        async function openAddComponent() {
            document.getElementById('componentModalTitle').textContent = 'Adicionar Componente';
            document.getElementById('componentForm').reset();
            document.getElementById('compId').value = '';
            document.getElementById('compImagemAtual').value = '';
            document.getElementById('imagePreview').style.display = 'none';
            await populateCategorySelect();
            document.getElementById('componentModal').classList.add('active');
        }
        async function editComponent(id) {
            const comp = components.find(c => c.IDCOMPONENTE == id);
            if (!comp) return;
            document.getElementById('componentModalTitle').textContent = 'Editar Componente';
            document.getElementById('compId').value = comp.IDCOMPONENTE;
            document.getElementById('compImagemAtual').value = comp.IMAGEM || '';
            document.getElementById('compName').value = comp.NOME;
            document.getElementById('compDescription').value = comp.DESCRICAO_CURTA;
            document.getElementById('compFullDescription').value = comp.DESCRICAO_COMPLETA;
            document.getElementById('compStock').value = comp.QUANTIDADE;
            const preview = document.getElementById('imagePreview');
            if (comp.IMAGEM) { preview.src = comp.IMAGEM; preview.style.display = 'block'; } else { preview.style.display = 'none'; }
            await populateCategorySelect(comp.IDCATEGORIA);
            document.getElementById('componentModal').classList.add('active');
        }
        function closeComponentModal() { document.getElementById('componentModal').classList.remove('active'); }
        async function populateCategorySelect(selectedId = null) {
            const select = document.getElementById('compCategory');
            select.innerHTML = '<option value="">Selecione uma categoria</option>';
            try {
                const fd = new FormData(); fd.append('acao', 'listar_categorias');
                const res = await fetch('gerenciar_componentes.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (data.sucesso) {
                    data.categorias.forEach(cat => {
                        const opt = document.createElement('option');
                        opt.value = cat.IDCATEGORIA; opt.textContent = `${cat.ICONE} ${cat.NOME}`;
                        if (selectedId && cat.IDCATEGORIA == selectedId) opt.selected = true;
                        select.appendChild(opt);
                    });
                }
            } catch {}
        }
        async function saveComponent(e) {
    e.preventDefault();

    const btn = e.target.querySelector('[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Salvando...';

    const fd = new FormData();

    fd.append('acao', 'salvar_componente');
    fd.append('id', document.getElementById('compId').value);
    fd.append('imagem_atual', document.getElementById('compImagemAtual').value);
    fd.append('nome', document.getElementById('compName').value);
    fd.append('idcategoria', document.getElementById('compCategory').value);
    fd.append('descricao_curta', document.getElementById('compDescription').value);
    fd.append('descricao_completa', document.getElementById('compFullDescription').value);
    fd.append('quantidade', document.getElementById('compStock').value);

    const imgFile = document.getElementById('compImagem').files[0];

    if (imgFile) {
        fd.append('imagem', imgFile);
    }

    try {
        const res = await fetch('gerenciar_componentes.php', {
            method: 'POST',
            body: fd
        });

        const texto = await res.text();

        let data;

        try {
            data = JSON.parse(texto);
        } catch (erroJson) {
            stoktechToast('O PHP não retornou JSON. Resposta: ' + texto.substring(0, 300, 'erro'));
            console.error(texto);
            return;
        }

        if (data.sucesso) {
            showNotification(data.mensagem);
            closeComponentModal();
            renderComponents();
        } else {
            stoktechToast(data.mensagem, 'erro');
        }

    } catch (erro) {
        stoktechToast('Erro de conexão: ' + erro.message, 'erro');
        console.error(erro);

    } finally {
        btn.disabled = false;
        btn.textContent = 'Salvar Componente';
    }
}
        async function deleteComponent(id) {
            const comp = components.find(c => c.IDCOMPONENTE == id);

            if (!comp) return;

            const confirmar = await stoktechConfirm({
                titulo: 'Excluir componente',
                mensagem: `Você tem certeza que deseja excluir "${comp.NOME}"?`,
                textoConfirmar: 'Excluir'
            });

            if (!confirmar) return;

            const fd = new FormData();
            fd.append('acao', 'excluir_componente');
            fd.append('id', id);

            try {
                const res = await fetch('gerenciar_componentes.php', {
                    method: 'POST',
                    body: fd
                });

                const texto = await res.text();

                let data;

                try {
                    data = JSON.parse(texto);
                } catch (erroJson) {
                    stoktechToast('O PHP não retornou JSON. Resposta: ' + texto.substring(0, 300), 'erro');
                    console.error(texto);
                    return;
                }

                if (data.sucesso) {
                    showNotification(data.mensagem);
                    renderComponents();
                } else {
                    stoktechToast(data.mensagem, 'erro');
                }

            } catch (erro) {
                stoktechToast('Erro de conexão: ' + erro.message, 'erro');
                console.error(erro);
            }
        }

        // Category CRUD
        function openAddCategory() {
            document.getElementById('categoryModalTitle').textContent = 'Adicionar Categoria';
            document.getElementById('categoryForm').reset(); document.getElementById('catId').value = '';
            document.getElementById('categoryModal').classList.add('active');
        }
        function editCategory(id) {
            const cat = categories.find(c => c.IDCATEGORIA == id);
            if (!cat) return;
            document.getElementById('categoryModalTitle').textContent = 'Editar Categoria';
            document.getElementById('catId').value = cat.IDCATEGORIA;
            document.getElementById('catIcon').value = cat.ICONE;
            document.getElementById('catName').value = cat.NOME;
            document.getElementById('catDescricao').value = cat.DESCRIÇÃO || '';
            document.getElementById('categoryModal').classList.add('active');
        }
        function closeCategoryModal() { document.getElementById('categoryModal').classList.remove('active'); }
        async function saveCategory(e) {
    e.preventDefault();

    const btn = e.target.querySelector('[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Salvando...';

    const fd = new FormData();
    fd.append('acao', 'salvar_categoria');
    fd.append('id', document.getElementById('catId').value);
    fd.append('icone', document.getElementById('catIcon').value);
    fd.append('nome', document.getElementById('catName').value);
    fd.append('descricao', document.getElementById('catDescricao').value);

    try {
        const res = await fetch('gerenciar_componentes.php', {
            method: 'POST',
            body: fd
        });

        const texto = await res.text();

        let data;

        try {
            data = JSON.parse(texto);
        } catch (erroJson) {
            stoktechToast('O PHP não retornou JSON. Resposta: ' + texto.substring(0, 300, 'erro'));
            console.error(texto);
            return;
        }

        if (data.sucesso) {
            showNotification(data.mensagem);
            closeCategoryModal();
            renderCategories();
        } else {
            stoktechToast(data.mensagem, 'erro');
        }

    } catch (erro) {
        stoktechToast('Erro de conexão: ' + erro.message, 'erro');
        console.error(erro);

    } finally {
        btn.disabled = false;
        btn.textContent = 'Salvar Categoria';
    }
}
        async function deleteCategory(id) {
            const cat = categories.find(c => c.IDCATEGORIA == id);
            if (!cat) return;
            if (!(await stoktechConfirm({ titulo: 'Excluir categoria', mensagem: `Você tem certeza que deseja excluir "${cat.NOME}"?`, textoConfirmar: 'Excluir' }))) return;
            const fd = new FormData(); fd.append('acao', 'excluir_categoria'); fd.append('id', id);
            try {
                const res = await fetch('gerenciar_componentes.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (data.sucesso) { showNotification(data.mensagem); renderCategories(); } else { stoktechToast(data.mensagem, 'erro'); }
            } catch { stoktechToast('Erro de conexão.', 'erro'); }
        }

        // User CRUD
        function editUser(id) {
            const u = users.find(u => u.IDUSUARIO == id);
            if (!u) return;
            document.getElementById('userId').value = u.IDUSUARIO;
            document.getElementById('userName').value = u.NOME;
            document.getElementById('userEmail').value = u.EMAIL;
            document.getElementById('userCpf').value = u.CPF;
            document.getElementById('userModal').classList.add('active');
        }
        function closeUserModal() { document.getElementById('userModal').classList.remove('active'); }
        async function saveUser(e) {
            e.preventDefault();
            const btn = e.target.querySelector('[type="submit"]');
            btn.disabled = true; btn.textContent = 'Salvando...';
            const fd = new FormData();
            fd.append('acao', 'editar'); fd.append('id', document.getElementById('userId').value);
            fd.append('nome', document.getElementById('userName').value);
            fd.append('email', document.getElementById('userEmail').value);
            fd.append('cpf', document.getElementById('userCpf').value);
            try {
                const res = await fetch('gerenciar_usuarios.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (data.sucesso) { showNotification(data.mensagem); closeUserModal(); renderUsers(); } else { stoktechToast(data.mensagem, 'erro'); }
            } catch { stoktechToast('Erro de conexão.', 'erro'); }
            btn.disabled = false; btn.textContent = 'Salvar Alterações';
        }
        async function toggleAdmin(id) {
            const u = users.find(u => u.IDUSUARIO == id);
            if (!u) return;
            const acao = u.TIPO === 'ADMINISTRADOR' ? 'remover admin de' : 'tornar administrador';
            if (!(await stoktechConfirm({ titulo: 'Confirmar ação', mensagem: `Deseja realmente ${acao} ${u.NOME}?`, textoConfirmar: 'Confirmar' }))) return;
            const fd = new FormData(); fd.append('acao', 'toggle_admin'); fd.append('id', id);
            try {
                const res = await fetch('gerenciar_usuarios.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (data.sucesso) { showNotification(data.mensagem); renderUsers(); } else { stoktechToast(data.mensagem, 'erro'); }
            } catch { stoktechToast('Erro de conexão.', 'erro'); }
        }
        async function deleteUser(id) {
            const u = users.find(u => u.IDUSUARIO == id);
            if (!u) return;
            if (!(await stoktechConfirm({ titulo: 'Excluir usuário', mensagem: `Excluir o usuário ${u.NOME}? Esta ação não pode ser desfeita.`, textoConfirmar: 'Excluir' }))) return;
            const fd = new FormData(); fd.append('acao', 'excluir'); fd.append('id', id);
            try {
                const res = await fetch('gerenciar_usuarios.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (data.sucesso) { showNotification(data.mensagem); renderUsers(); } else { stoktechToast(data.mensagem, 'erro'); }
            } catch { stoktechToast('Erro de conexão.', 'erro'); }
        }

        // ══════════════════════════════════════════════════════
        // Chat / Empréstimos — estilo WhatsApp Web
        // ══════════════════════════════════════════════════════
        const ADMIN_ID = <?= (int)($_SESSION['idusuario'] ?? 0) ?>;
        const WA_VISTOS_KEY = 'stokAdminVistos_' + ADMIN_ID;
        const WA_INTERVALO_MS = 3000;
        let waVistos = {};
        let waVistosExistia = false;
        let waFiltro = 'todos';
        let waBusca = '';
        let waAssinatura = null;
        let waSincronizando = false;
        let waEnviando = false;
        let secaoAtual = 'dashboard';

        (function () {
            try {
                const salvo = localStorage.getItem(WA_VISTOS_KEY);
                if (salvo) { waVistos = JSON.parse(salvo) || {}; waVistosExistia = true; }
            } catch (e) { waVistos = {}; }
        })();
        function waSalvarVistos() { try { localStorage.setItem(WA_VISTOS_KEY, JSON.stringify(waVistos)); } catch (e) {} }

        function waUltimoIdMsg(emp) {
            return (emp.MENSAGENS || []).reduce((max, m) => Math.max(max, Number(m.IDMENSAGEM) || 0), 0);
        }
        function waNaoLidas(emp) {
            const visto = Number(waVistos[emp.IDEMPRESTIMO] || 0);
            return (emp.MENSAGENS || []).filter(m => m.USUARIO_TIPO !== 'ADMINISTRADOR' && Number(m.IDMENSAGEM) > visto).length;
        }
        function waMarcarVisto(emp) {
            const ultimo = waUltimoIdMsg(emp);
            if (Number(waVistos[emp.IDEMPRESTIMO] || 0) !== ultimo) { waVistos[emp.IDEMPRESTIMO] = ultimo; waSalvarVistos(); }
        }
        function waRenovacaoPendente(emp) { return (emp.RENOVACOES || []).some(r => String(r.STATUS).toUpperCase() === 'PENDENTE'); }
        function waEncerrado(emp) { return ['DEVOLVIDO', 'RECUSADO', 'CANCELADO'].includes(String(emp.STATUS).toUpperCase()); }
        function waBuscarEmp(id) { return emprestimos.find(e => e.IDEMPRESTIMO == id); }

        function waAposCarregar() {
            // Primeira vez neste navegador: considera o histórico existente como já lido
            if (!waVistosExistia) {
                emprestimos.forEach(e => { waVistos[e.IDEMPRESTIMO] = waUltimoIdMsg(e); });
                waVistosExistia = true;
                waSalvarVistos();
            }
            atualizarBadgeChats();
        }
        function atualizarBadgeChats() {
            const badge = document.getElementById('chatBadge');
            if (!badge) return;
            const total = emprestimos.filter(e => String(e.STATUS).toUpperCase() === 'PENDENTE' || waRenovacaoPendente(e) || waNaoLidas(e) > 0).length;
            badge.textContent = total > 99 ? '99+' : total;
            badge.style.display = total > 0 ? 'flex' : 'none';
        }

        // ── datas ──
        function waDia(str) { return String(str || '').slice(0, 10); }
        function waIso(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
        function waRotuloDia(dia) {
            if (dia === waIso(new Date())) return 'Hoje';
            const o = new Date(); o.setDate(o.getDate() - 1);
            if (dia === waIso(o)) return 'Ontem';
            return formatarData(dia);
        }
        function waRotuloLista(ts) {
            const dia = waDia(ts);
            if (!dia) return '';
            if (dia === waIso(new Date())) { const h = String(ts).slice(11, 16); return (!h || h === '00:00') ? 'Hoje' : h; }
            const o = new Date(); o.setDate(o.getDate() - 1);
            if (dia === waIso(o)) return 'Ontem';
            return formatarData(dia);
        }
        function waAtividade(emp) {
            const cand = [waDia(emp.DATA_EMPRESTIMO) + ' 00:00:00'];
            const ms = emp.MENSAGENS || [];
            if (ms.length) cand.push(String(ms[ms.length - 1].DATA_ENVIO));
            (emp.RENOVACOES || []).forEach(r => {
                if (r.DATA_SOLICITACAO) cand.push(String(r.DATA_SOLICITACAO));
                if (r.DATA_RESPOSTA) cand.push(String(r.DATA_RESPOSTA));
            });
            return cand.sort().pop();
        }

        // ── peças visuais ──
        function waAvatar(nome, foto) {
            const inicial = escapeHtml((nome || 'A').trim().charAt(0).toUpperCase() || 'A');
            const img = foto ? `<img src="${escapeHtml(foto)}" alt="" onerror="this.remove()">` : '';
            return inicial + img;
        }
        function waStatus(status) {
            const s = String(status || 'PENDENTE').toUpperCase();
            const nomes = { PENDENTE: 'Pendente', APROVADO: 'Aprovado', RETIRADO: 'Retirado', DEVOLVIDO: 'Devolvido', RECUSADO: 'Recusado', CANCELADO: 'Cancelado' };
            return `<span class="wa-status st-${s.toLowerCase()}">${nomes[s] || escapeHtml(s)}</span>`;
        }
        function waPreview(emp) {
            if (waRenovacaoPendente(emp)) return { texto: 'Pedido de renovação pendente', alerta: true };
            const ms = emp.MENSAGENS || [];
            if (ms.length) {
                const u = ms[ms.length - 1];
                let prefixo = '';
                if (u.USUARIO_TIPO === 'ADMINISTRADOR') prefixo = Number(u.IDUSUARIO) === ADMIN_ID ? 'Você: ' : String(u.USUARIO_NOME || 'Admin').split(' ')[0] + ': ';
                return { texto: prefixo + String(u.MENSAGEM).replace(/\s+/g, ' '), alerta: false };
            }
            const n = (emp.ITENS || []).length;
            return { texto: `${n} item${n !== 1 ? 'ns' : ''} solicitado${n !== 1 ? 's' : ''}`, alerta: false };
        }

        // ── 2ª sidebar: lista de conversas ──
        function renderListaChats() {
            const el = document.getElementById('waListBody');
            if (!el) return;
            if (!emprestimos.length) { el.innerHTML = '<div class="wa-list-empty">Nenhuma solicitação de empréstimo ainda.</div>'; return; }

            let itens = emprestimos.filter(e => {
                const s = String(e.STATUS).toUpperCase();
                if (waFiltro === 'pendentes' && !(s === 'PENDENTE' || waRenovacaoPendente(e))) return false;
                if (waFiltro === 'andamento' && !(s === 'APROVADO' || s === 'RETIRADO')) return false;
                if (waFiltro === 'encerrados' && !waEncerrado(e)) return false;
                if (waBusca) {
                    const alvo = ((e.ALUNO_NOME || '') + ' #' + e.IDEMPRESTIMO).toLowerCase();
                    if (!alvo.includes(waBusca.replace(/^#/, '#'))) return false;
                }
                return true;
            });
            itens.sort((a, b) => {
                const ta = waAtividade(a), tb = waAtividade(b);
                return ta < tb ? 1 : ta > tb ? -1 : Number(b.IDEMPRESTIMO) - Number(a.IDEMPRESTIMO);
            });

            const rolagem = el.scrollTop;
            el.innerHTML = itens.length ? itens.map(e => {
                const id = Number(e.IDEMPRESTIMO);
                const nl = waNaoLidas(e);
                const p = waPreview(e);
                return `
                <div class="wa-item ${id == currentChatId ? 'active' : ''} ${nl > 0 ? 'unread' : ''}" onclick="abrirConversa(${id})">
                    <div class="wa-avatar">${waAvatar(e.ALUNO_NOME, e.ALUNO_FOTO)}</div>
                    <div class="wa-item-main">
                        <div class="wa-item-top">
                            <span class="wa-item-name">${escapeHtml(e.ALUNO_NOME || 'Aluno')}</span>
                            <span class="wa-item-time">${waRotuloLista(waAtividade(e))}</span>
                        </div>
                        <div class="wa-item-mid">
                            <span class="wa-item-preview ${p.alerta ? 'alerta' : ''}">${escapeHtml(p.texto)}</span>
                            ${nl > 0 ? `<span class="wa-unread">${nl}</span>` : ''}
                        </div>
                        <div class="wa-item-bot">${waStatus(e.STATUS)}<span class="wa-item-id">#${id}</span></div>
                    </div>
                </div>`;
            }).join('') : '<div class="wa-list-empty">Nenhum empréstimo encontrado.</div>';
            el.scrollTop = rolagem;
        }

        // ── chat em tela cheia ──
        function abrirConversa(id) {
            const emp = waBuscarEmp(id);
            if (!emp) return;
            currentChatId = Number(id);
            waMarcarVisto(emp);
            document.getElementById('waLayout').classList.add('chat-active');
            renderListaChats();
            renderConversa({ irParaFim: true });
            atualizarBadgeChats();
            if (!waEncerrado(emp) && window.innerWidth > 860) setTimeout(() => document.getElementById('chatInputAdmin').focus(), 50);
        }
        function waVoltarLista() {
            currentChatId = null;
            document.getElementById('waLayout').classList.remove('chat-active');
            renderListaChats();
            renderConversa();
        }

        function waBarraAcoes(emp) {
            const bar = document.getElementById('waActionBar');
            const s = String(emp.STATUS).toUpperCase();
            let html = '', aviso = false;
            if (s === 'PENDENTE') {
                aviso = true;
                html = `<span><strong>Solicitação pendente</strong> — analise os itens e responda ao aluno.</span>
                        <span class="wa-act-btns"><button class="reject-btn" onclick="rejectLoan()">Recusar</button><button class="approve-btn" onclick="approveLoan()">Aprovar</button></span>`;
            } else if (s === 'APROVADO') {
                html = `<span><strong>Aprovado</strong> — o aluno tem até ${formatarData(emp.DATA_LIMITE_RETIRADA)} para retirar.</span>
                        <span class="wa-act-btns"><button class="primary-btn" onclick="markWithdrawn()">Marcar como retirado</button></span>`;
            } else if (s === 'RETIRADO') {
                html = `<span><strong>Retirado</strong> — devolução prevista para ${formatarData(emp.PRAZO_DEVOLUCAO)}.</span>
                        <span class="wa-act-btns"><button class="primary-btn" onclick="markReturned()">Marcar como devolvido</button></span>`;
            }
            bar.innerHTML = html;
            bar.classList.toggle('warn', aviso);
            bar.style.display = html ? 'flex' : 'none';
        }

        function waMontarLinhaDoTempo(emp) {
            const ev = [];
            const itens = (emp.ITENS || []).map(i => `• ${escapeHtml(i.COMPONENTE_NOME)} — Quantidade: ${i.QUANTIDADE}`).join('<br>');
            ev.push({ ts: waDia(emp.DATA_EMPRESTIMO) + ' 00:00:00', ord: 0, id: 0, html: `
                <div class="wa-card">
                    <div class="wa-card-title">Solicitação de empréstimo #${emp.IDEMPRESTIMO}</div>
                    <strong>Aluno:</strong> ${escapeHtml(emp.ALUNO_NOME || '—')}<br>
                    <strong>Data:</strong> ${formatarData(waDia(emp.DATA_EMPRESTIMO))}<br><br>
                    <strong>Itens solicitados:</strong><br>${itens || 'Nenhum item encontrado.'}
                </div>` });

            (emp.MENSAGENS || []).forEach(m => {
                const adm = m.USUARIO_TIPO === 'ADMINISTRADOR';
                const outroAdm = adm && Number(m.IDUSUARIO) !== ADMIN_ID;
                ev.push({ ts: String(m.DATA_ENVIO), ord: 2, id: Number(m.IDMENSAGEM), html: `
                    <div class="wa-msg ${adm ? 'mine' : 'theirs'}">
                        ${outroAdm ? `<div class="wa-msg-author">${escapeHtml(m.USUARIO_NOME || 'Administrador')}</div>` : ''}
                        <div class="wa-text">${escapeHtml(m.MENSAGEM)}</div>
                        <span class="wa-msg-time">${escapeHtml(String(m.DATA_ENVIO).slice(11, 16))}</span>
                    </div>` });
            });

            if (emp.FEEDBACK_DEVOLUCAO) {
                const f = emp.FEEDBACK_DEVOLUCAO;
                ev.push({ ts: String(f.DATA_REGISTRO || ''), ord: 3, id: 0, html: `
                    <div class="wa-card ${Number(f.HOUVE_DANO) === 1 ? 'bad' : 'ok'}">
                        <div class="wa-card-title">Checklist de devolução</div>
                        <strong>Houve dano:</strong> ${Number(f.HOUVE_DANO) === 1 ? 'Sim' : 'Não'}<br>
                        <strong>Tipo do dano:</strong> ${escapeHtml(f.TIPO_DANO || '—')}<br>
                        <strong>Gravidade:</strong> ${escapeHtml(f.GRAVIDADE || '—')}<br>
                        <strong>Laudo:</strong> ${escapeHtml(f.LAUDO || '—')}<br>
                        <strong>Registrado por:</strong> ${escapeHtml(f.ADM_NOME || 'Administrador')}
                    </div>` });
            }

            (emp.RENOVACOES || []).forEach(r => {
                const st = String(r.STATUS).toUpperCase();
                ev.push({ ts: String(r.DATA_SOLICITACAO || ''), ord: 3, id: Number(r.IDRENOVACAO), html: `
                    <div class="wa-card warn">
                        <div class="wa-card-title">Pedido de renovação</div>
                        <strong>Nova data solicitada:</strong> ${formatarData(r.NOVA_DATA_SOLICITADA)}<br>
                        <strong>Motivo:</strong> ${escapeHtml(r.MOTIVO)}
                        ${st === 'PENDENTE' ? `
                        <div class="wa-card-actions">
                            <button class="approve-btn" onclick="responderRenovacao(${r.IDRENOVACAO}, 'APROVADA')">Aprovar renovação</button>
                            <button class="reject-btn" onclick="responderRenovacao(${r.IDRENOVACAO}, 'RECUSADA')">Recusar renovação</button>
                        </div>` : ''}
                    </div>` });
                if (st !== 'PENDENTE' && r.DATA_RESPOSTA) {
                    ev.push({ ts: String(r.DATA_RESPOSTA), ord: 4, id: Number(r.IDRENOVACAO), html: `
                        <div class="wa-card ${st === 'APROVADA' ? 'ok' : 'bad'}">
                            <div class="wa-card-title">Renovação ${st === 'APROVADA' ? 'aprovada' : 'recusada'}</div>
                            <strong>Comentário:</strong> ${escapeHtml(r.COMENTARIO_ADMIN || '—')}<br>
                            <strong>Respondido por:</strong> ${escapeHtml(r.ADM_NOME || 'Administrador')}
                        </div>` });
                }
            });

            ev.sort((a, b) => a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : (a.ord - b.ord) || (a.id - b.id));
            let html = '', ultimoDia = '';
            ev.forEach(e => {
                const dia = waDia(e.ts);
                if (dia && dia !== ultimoDia) { html += `<div class="wa-day"><span>${waRotuloDia(dia)}</span></div>`; ultimoDia = dia; }
                html += e.html;
            });
            return html;
        }

        function renderConversa(opts = {}) {
            const vazio = document.getElementById('waEmpty');
            const conv = document.getElementById('waConversa');
            const emp = currentChatId == null ? null : waBuscarEmp(currentChatId);
            if (!emp) { conv.style.display = 'none'; vazio.style.display = 'flex'; return; }
            vazio.style.display = 'none';
            conv.style.display = 'flex';

            document.getElementById('chatUserName').textContent = emp.ALUNO_NOME || 'Aluno';
            document.getElementById('chatUserEmail').textContent = `Empréstimo #${emp.IDEMPRESTIMO}` + (emp.ALUNO_EMAIL ? ' · ' + emp.ALUNO_EMAIL : '');
            document.getElementById('waHeadAvatar').innerHTML = waAvatar(emp.ALUNO_NOME, emp.ALUNO_FOTO);
            document.getElementById('waHeadStatus').innerHTML = waStatus(emp.STATUS);
            waBarraAcoes(emp);

            const encerrado = waEncerrado(emp);
            document.getElementById('waInputArea').style.display = encerrado ? 'none' : 'flex';
            document.getElementById('waClosed').style.display = encerrado ? 'block' : 'none';

            const box = document.getElementById('chatMessagesAdmin');
            const noFim = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
            const anterior = box.scrollTop;
            box.innerHTML = waMontarLinhaDoTempo(emp);
            box.scrollTop = (opts.irParaFim || noFim) ? box.scrollHeight : anterior;
        }

        async function renderChats() {
            const corpo = document.getElementById('waListBody');
            if (!emprestimos.length) corpo.innerHTML = '<div class="wa-list-empty">Carregando...</div>';
            else renderListaChats();
            try {
                await carregarEmprestimos();
            } catch (e) {
                corpo.innerHTML = '<div class="wa-list-empty">Erro ao carregar empréstimos.</div>';
                return;
            }
            if (currentChatId != null && !waBuscarEmp(currentChatId)) currentChatId = null;
            const aberto = currentChatId == null ? null : waBuscarEmp(currentChatId);
            if (aberto) waMarcarVisto(aberto);
            renderListaChats();
            renderConversa({ irParaFim: true });
            atualizarBadgeChats();
        }

        // ── tempo real (polling leve a cada 3s) ──
        async function sincronizarChats(forcar = false, opts = {}) {
            if (!forcar && (waSincronizando || document.hidden)) return;
            if (!forcar) waSincronizando = true;
            try {
                const fd = new FormData(); fd.append('acao', 'resumo');
                const res = await fetch('gerenciar_emprestimos.php', { method: 'POST', body: fd, cache: 'no-store' });
                const data = await res.json();
                if (!data.sucesso) return;
                const assinatura = JSON.stringify(data.resumo);
                if (!forcar && assinatura === waAssinatura) return;
                waAssinatura = assinatura;
                await waAplicarAtualizacao(opts);
            } catch (e) { /* rede instável: tenta de novo no próximo ciclo */ }
            finally { if (!forcar) waSincronizando = false; }
        }
        async function waAplicarAtualizacao(opts = {}) {
            const antes = new Map(emprestimos.map(e => [String(e.IDEMPRESTIMO), waUltimoIdMsg(e)]));
            await carregarEmprestimos();

            emprestimos.forEach(e => {
                const id = String(e.IDEMPRESTIMO);
                if (!antes.has(id)) {
                    if (antes.size > 0) stoktechToast(`Nova solicitação de ${e.ALUNO_NOME || 'aluno'}`, 'aviso');
                    return;
                }
                const vendo = secaoAtual === 'chats' && currentChatId == e.IDEMPRESTIMO && !document.hidden;
                const novas = (e.MENSAGENS || []).filter(m => Number(m.IDMENSAGEM) > antes.get(id) && m.USUARIO_TIPO !== 'ADMINISTRADOR');
                if (novas.length && !vendo) stoktechToast(`Nova mensagem de ${e.ALUNO_NOME || 'aluno'}`, 'aviso');
            });

            if (secaoAtual === 'chats') {
                const aberto = currentChatId == null ? null : waBuscarEmp(currentChatId);
                if (aberto && !document.hidden) waMarcarVisto(aberto);
                renderListaChats();
                if (currentChatId != null) renderConversa(opts);
            }
            atualizarBadgeChats();
        }

        function waAjustarTextarea(el) { el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 130) + 'px'; }
        function waConfigurar() {
            const campo = document.getElementById('chatInputAdmin');
            document.getElementById('sendMessageAdmin').addEventListener('click', sendAdminMessage);
            campo.addEventListener('keydown', e => {
                if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendAdminMessage(); }
            });
            campo.addEventListener('input', () => waAjustarTextarea(campo));
            document.getElementById('waSearch').addEventListener('input', e => { waBusca = e.target.value.trim().toLowerCase(); renderListaChats(); });
            document.querySelectorAll('#waFilters .wa-chip').forEach(chip => chip.addEventListener('click', () => {
                document.querySelectorAll('#waFilters .wa-chip').forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                waFiltro = chip.dataset.filtro;
                renderListaChats();
            }));
            document.getElementById('waBack').addEventListener('click', waVoltarLista);
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) return;
                if (secaoAtual === 'chats' && currentChatId != null) {
                    const e = waBuscarEmp(currentChatId);
                    if (e) { waMarcarVisto(e); renderListaChats(); atualizarBadgeChats(); }
                }
                sincronizarChats();
            });
            setInterval(() => sincronizarChats(), WA_INTERVALO_MS);
        }

        function escapeHtml(text) {
    return String(text ?? '').replace(/[&<>"']/g, function(char) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        }[char];
    });
}
        async function sendAdminMessage() {
            if (currentChatId === null || currentChatId === undefined || waEnviando) return;

            const input = document.getElementById('chatInputAdmin');
            const btn = document.getElementById('sendMessageAdmin');
            const msg = input.value.trim();
            if (!msg) return;

            const fd = new FormData();
            fd.append('acao', 'enviar_mensagem');
            fd.append('idemprestimo', currentChatId);
            fd.append('mensagem', msg);

            waEnviando = true;
            btn.disabled = true;
            try {
                const res = await fetch('gerenciar_emprestimos.php', { method: 'POST', body: fd });
                const texto = await res.text();

                let data;
                try {
                    data = JSON.parse(texto);
                } catch (erroJson) {
                    stoktechToast('O PHP não retornou JSON. Resposta: ' + texto.substring(0, 300), 'erro');
                    console.error(texto);
                    return;
                }

                if (!data.sucesso) {
                    stoktechToast(data.mensagem || 'Erro ao enviar mensagem.', 'erro');
                    await sincronizarChats(true);
                    return;
                }

                input.value = '';
                waAjustarTextarea(input);
                await sincronizarChats(true, { irParaFim: true });
            } catch (e) {
                stoktechToast('Erro de conexão ao enviar mensagem: ' + e.message, 'erro');
                console.error(e);
            } finally {
                waEnviando = false;
                btn.disabled = false;
                input.focus();
            }
        }
       async function atualizarStatusEmprestimo(status, extras = {}) {

    if (
        currentChatId === null ||
        currentChatId === undefined
    ) return;


    const fd = new FormData();

    fd.append(
        'acao',
        'atualizar_status'
    );

    fd.append(
        'idemprestimo',
        currentChatId
    );

    fd.append(
        'status',
        status
    );


    Object.keys(extras).forEach(chave => {

        fd.append(
            chave,
            extras[chave]
        );

    });


    try {

        const res = await fetch(
            'gerenciar_emprestimos.php',
            {
                method: 'POST',
                body: fd
            }
        );


        const texto = await res.text();

        let data;


        try {

            data = JSON.parse(texto);

        } catch (erroJson) {

            stoktechToast(
                'O PHP não retornou JSON. Resposta: ' +
                texto.substring(0, 300),
                'erro'
            );

            console.error(texto);

            return;
        }


        if (!data.sucesso) {

            stoktechToast(
                data.mensagem,
                'erro'
            );

            return;
        }


        showNotification(
            data.mensagem
        );


        /*
         * IMPORTANTE:
         * busca novamente os dados no banco
         */
        await sincronizarChats(true, { irParaFim: true });


    } catch(e) {

        stoktechToast(
            'Erro de conexão: ' + e.message,
            'erro'
        );

        console.error(e);

    }
}
async function responderRenovacao(idRenovacao, status) {
    const comentario = prompt(
        status === 'APROVADA'
            ? 'Comentário obrigatório para aprovar a renovação:'
            : 'Comentário obrigatório para recusar a renovação:'
    );

    if (comentario === null) return;

    if (comentario.trim() === '') {
        alert('O comentário do administrador é obrigatório.');
        return;
    }

    const confirmar = confirm(
        status === 'APROVADA'
            ? 'Confirmar aprovação da renovação? O prazo de devolução será atualizado.'
            : 'Confirmar recusa da renovação? O prazo atual será mantido.'
    );

    if (!confirmar) return;

    const fd = new FormData();
    fd.append('acao', 'responder_renovacao');
    fd.append('idrenovacao', idRenovacao);
    fd.append('status', status);
    fd.append('comentario_admin', comentario.trim());

    try {
        const res = await fetch('gerenciar_emprestimos.php', {
            method: 'POST',
            body: fd
        });

        const texto = await res.text();

        let data;

        try {
            data = JSON.parse(texto);
        } catch (erroJson) {
            alert('O PHP não retornou JSON. Resposta: ' + texto.substring(0, 300));
            console.error(texto);
            return;
        }

        if (!data.sucesso) {
            alert(data.mensagem);
            return;
        }

        showNotification(data.mensagem);

        await sincronizarChats(true);

    } catch (e) {
        alert('Erro de conexão ao responder renovação: ' + e.message);
        console.error(e);
    }
}
        async function approveLoan() {
            if (!(await stoktechConfirm({ titulo: 'Aprovar empréstimo', mensagem: 'Aprovar esta solicitação de empréstimo?', textoConfirmar: 'Aprovar', neutro: true }))) return;
            atualizarStatusEmprestimo('APROVADO');
        }
        async function rejectLoan() {
            if (!(await stoktechConfirm({ titulo: 'Recusar empréstimo', mensagem: 'Recusar esta solicitação de empréstimo?', textoConfirmar: 'Recusar' }))) return;
            atualizarStatusEmprestimo('RECUSADO');
        }
        async function markWithdrawn() {
    const hoje = new Date();
    hoje.setDate(hoje.getDate() + 7);

    const ano = hoje.getFullYear();
    const mes = String(hoje.getMonth() + 1).padStart(2, '0');
    const dia = String(hoje.getDate()).padStart(2, '0');

    const sugestao = `${ano}-${mes}-${dia}`;

    const prazo = prompt('Informe o prazo de devolução no formato AAAA-MM-DD:', sugestao);

    if (!prazo) return;

    if (!/^\d{4}-\d{2}-\d{2}$/.test(prazo)) {
        stoktechToast('Data inválida. Use o formato AAAA-MM-DD.', 'erro');
        return;
    }

    if (!(await stoktechConfirm({ titulo: 'Confirmar retirada', mensagem: 'Confirmar retirada com prazo de devolução em ' + prazo + '?', textoConfirmar: 'Confirmar', neutro: true }))) {
        return;
    }

    atualizarStatusEmprestimo('RETIRADO', {
        prazo_devolucao: prazo
    });
}
        async function markReturned() {
    if (!(await stoktechConfirm({
        titulo: 'Devolução',
        mensagem: 'Iniciar checklist de devolução?',
        textoConfirmar: 'Iniciar',
        neutro: true
    }))) return;

    const houveDanoTxt = prompt('Houve dano no item? Digite SIM ou NAO:', 'NAO');

    if (houveDanoTxt === null) return;

    const houveDanoNormalizado = houveDanoTxt.trim().toUpperCase();
    const houveDano = houveDanoNormalizado === 'SIM' ? 1 : 0;

    let tipoDano = '';
    let gravidade = '';
    let laudo = '';

    if (houveDano === 1) {
        tipoDano = prompt('Tipo do dano. Ex: cabo quebrado, placa queimada, peça ausente:', '');

        if (tipoDano === null || tipoDano.trim() === '') {
            stoktechToast('Tipo do dano é obrigatório quando há dano.', 'erro');
            return;
        }

        gravidade = prompt('Gravidade do dano. Ex: leve, media ou grave:', 'leve');

        if (gravidade === null || gravidade.trim() === '') {
            stoktechToast('Gravidade é obrigatória quando há dano.', 'erro');
            return;
        }

        laudo = prompt('Laudo/observação da devolução:', '');

        if (laudo === null || laudo.trim() === '') {
            stoktechToast('Laudo é obrigatório quando há dano.', 'erro');
            return;
        }
    } else {
        laudo = prompt('Observação da devolução. Ex: item devolvido em bom estado:', 'Item devolvido em bom estado.');

        if (laudo === null) return;
    }

    if (!(await stoktechConfirm({
        titulo: 'Confirmar devolução',
        mensagem: 'Confirmar devolução e registrar checklist? O estoque será devolvido.',
        textoConfirmar: 'Confirmar',
        neutro: true
    }))) {
        return;
    }

    atualizarStatusEmprestimo('DEVOLVIDO', {
        houve_dano: houveDano,
        tipo_dano: tipoDano.trim(),
        gravidade: gravidade.trim(),
        laudo: laudo.trim()
    });
}
        function saveChat() {
            if (currentChatId === null || currentChatId === undefined) return;
            const emp = emprestimos.find(e => e.IDEMPRESTIMO == currentChatId);
            if (!emp) return;
            const now = new Date();
            const filename = `emprestimo_${emp.IDEMPRESTIMO}_${now.toLocaleDateString('pt-BR').replace(/\//g,'-')}.txt`;
            let content = `STOKTECH — LOG DE EMPRÉSTIMO\n${'='.repeat(40)}\nAluno: ${emp.ALUNO_NOME || ''}\nEmail: ${emp.ALUNO_EMAIL || ''}\nStatus: ${emp.STATUS || 'PENDENTE'}\nData: ${formatarData(emp.DATA_EMPRESTIMO)}\n${'='.repeat(40)}\n\nItens:\n`;
            emp.ITENS.forEach(item => { content += `- ${item.COMPONENTE_NOME} — Quantidade: ${item.QUANTIDADE}\n`; });
            content += `\nChecklist de Devolução:\n`;

            if (emp.FEEDBACK_DEVOLUCAO) {
                const f = emp.FEEDBACK_DEVOLUCAO;

                content += `Houve dano: ${Number(f.HOUVE_DANO) === 1 ? 'Sim' : 'Não'}\n`;
                content += `Tipo do dano: ${f.TIPO_DANO || '—'}\n`;
                content += `Gravidade: ${f.GRAVIDADE || '—'}\n`;
                content += `Laudo: ${f.LAUDO || '—'}\n`;
                content += `Registrado por: ${f.ADM_NOME || 'Administrador'}\n`;
                content += `Data do registro: ${f.DATA_REGISTRO || '—'}\n`;
            } else {
                content += `Nenhum checklist de devolução registrado.\n`;
            }
            content += `\nMensagens:\n`;
            if (emp.MENSAGENS && emp.MENSAGENS.length > 0) {
                emp.MENSAGENS.forEach(m => {
                    content += `[${m.DATA_ENVIO}] ${m.USUARIO_NOME || (m.USUARIO_TIPO === 'ADMINISTRADOR' ? 'Gerenciador' : 'Aluno')}: ${m.MENSAGEM}\n`;
                });
            } else {
                content += `Nenhuma mensagem registrada.\n`;
            }
            logs.push({ filename, userName: emp.ALUNO_NOME || 'Aluno', date: now.toLocaleString('pt-BR'), content });
            const blob = new Blob([content], { type: 'text/plain' });
            const url = URL.createObjectURL(blob); const a = document.createElement('a');
            a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
            showNotification('Log salvo com sucesso');
        }
        function downloadLog(i) {
            const log = logs[i];
            const blob = new Blob([log.content], { type: 'text/plain' });
            const url = URL.createObjectURL(blob); const a = document.createElement('a');
            a.href = url; a.download = log.filename; a.click(); URL.revokeObjectURL(url);
        }
        async function deleteLog(i) {
            if (!(await stoktechConfirm({ titulo: 'Excluir log', mensagem: 'Excluir este log?', textoConfirmar: 'Excluir' }))) return;
            logs.splice(i, 1); showNotification('Log excluído'); loadSection('logs');
        }

        // Profile
        // ══════════════════════════════════════════════════════
        // MEU PERFIL (agora dentro do painel, não um modal — os
        // dados são realmente salvos via atualizar_perfil.php)
        // ══════════════════════════════════════════════════════
        function formatarCpfAdmin(cpf) {
            const d = String(cpf).replace(/\D/g, '');
            return d.length === 11 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : cpf;
        }
        function carregarCamposPerfilAdmin() {
            document.getElementById('profileName').value = adminProfile.name;
            document.getElementById('profileEmail').value = adminProfile.email;
            document.getElementById('profilePassword').value = '';
            document.getElementById('profileConfirmPassword').value = '';
            document.getElementById('profCpf').textContent = DADOS_PESSOAIS_ADMIN.cpf ? formatarCpfAdmin(DADOS_PESSOAIS_ADMIN.cpf) : '—';
            const preview = document.getElementById('profilePreview');
            preview.innerHTML = adminProfile.foto ? `<img src="${adminProfile.foto}" style="width:100%;height:100%;object-fit:cover;">` : '&#9751;';
            document.getElementById('profileImageInput').value = '';
        }
        function handleProfileImageUploadAdmin(e) {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = ev => {
                document.getElementById('profilePreview').innerHTML = `<img src="${ev.target.result}" style="width:100%;height:100%;object-fit:cover;">`;
            };
            reader.readAsDataURL(file);
        }
        async function salvarPerfilAdmin() {
            const nome = document.getElementById('profileName').value.trim();
            const email = document.getElementById('profileEmail').value.trim();
            const senha = document.getElementById('profilePassword').value;
            const confirmar = document.getElementById('profileConfirmPassword').value;
            const btn = document.getElementById('saveProfileBtn');

            if (!nome || !email) { stoktechToast('Nome e email são obrigatórios.', 'aviso'); return; }
            if (senha && senha.length < 6) { stoktechToast('A senha precisa ter pelo menos 6 caracteres.', 'aviso'); return; }
            if (senha && senha !== confirmar) { stoktechToast('As senhas não coincidem.', 'aviso'); return; }

            const fd = new FormData();
            fd.append('nome', nome);
            fd.append('email', email);
            if (senha) fd.append('senha', senha);
            const fotoInput = document.getElementById('profileImageInput');
            if (fotoInput.files[0]) fd.append('foto', fotoInput.files[0]);

            btn.disabled = true; const textoOriginal = btn.textContent; btn.textContent = 'Salvando...';
            try {
                const res = await fetch('atualizar_perfil.php', { method: 'POST', body: fd });
                const texto = await res.text();

                let data;
                try {
                    data = JSON.parse(texto);
                } catch (erroJson) {
                    stoktechToast('O PHP não retornou JSON. Resposta: ' + texto.substring(0, 300), 'erro');
                    console.error(texto);
                    return;
                }

                if (!data.sucesso) { stoktechToast(data.mensagem || 'Erro ao salvar perfil.', 'erro'); return; }

                adminProfile.name = nome;
                if (!data.email_pendente) adminProfile.email = email;
                if (fotoInput.files[0]) {
                    const reader = new FileReader();
                    reader.onload = ev => { adminProfile.foto = ev.target.result; updateHeaderProfile(); };
                    reader.readAsDataURL(fotoInput.files[0]);
                }
                updateHeaderProfile();

                document.getElementById('profilePassword').value = '';
                document.getElementById('profileConfirmPassword').value = '';
                fotoInput.value = '';

                if (data.email_pendente) abrirModalConfirmarEmailAdmin();
                showNotification(data.mensagem);
            } catch (e) {
                stoktechToast('Erro de conexão ao salvar perfil.', 'erro');
            } finally {
                btn.disabled = false; btn.textContent = textoOriginal;
            }
        }

        function abrirModalConfirmarEmailAdmin() { document.getElementById('modalConfirmarEmail').style.display = 'flex'; }
        function fecharModalEmailAdmin() { document.getElementById('modalConfirmarEmail').style.display = 'none'; }
        async function confirmarEmailNovoAdmin() {
            const codigo = document.getElementById('codigoConfirmacaoEmail').value.trim();
            if (codigo.length !== 6) { alert('Digite o código de 6 números.'); return; }
            const fd = new FormData(); fd.append('codigo', codigo);
            try {
                const resposta = await fetch('confirmar_email.php', { method: 'POST', body: fd });
                const dados = await resposta.json();
                alert(dados.mensagem);
                if (dados.sucesso) location.reload();
            } catch (e) {
                alert('Erro ao confirmar email.');
            }
        }

        // ══════════════════════════════════════════════════════
        // PRAZOS — feriados, férias e datas importantes, com
        // total liberdade do gerenciador para criar/editar/excluir
        // ══════════════════════════════════════════════════════
        const ADM_MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
        const ADM_DOWS = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
        function admIso(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
        function tipoEventoLabel(t) { return t === 'FERIADO' ? 'Feriado' : t === 'FERIAS' ? 'Férias' : 'Data importante'; }
        function tipoEventoBadgeClass(t) { return t === 'FERIADO' ? 'badge-danger' : t === 'FERIAS' ? 'badge-warning' : 'badge-primary'; }

        async function renderPrazos() {
            const ca = document.getElementById('contentArea');
            ca.innerHTML = `<div class="section-header"><h1 class="section-title">Prazos</h1></div><div style="text-align:center;padding:3rem;color:var(--text-muted);font-size:0.88rem;">Carregando...</div>`;
            try {
                const fd = new FormData(); fd.append('acao', 'listar_eventos');
                const res = await fetch('gerenciar_emprestimos.php', { method: 'POST', body: fd, cache: 'no-store' });
                const data = await res.json();
                if (!data.sucesso) { ca.innerHTML = `<div class="section-header"><h1 class="section-title">Prazos</h1></div><div class="empty-state"><p>${escapeHtml(data.mensagem || 'Erro ao carregar eventos.')}</p></div>`; return; }
                eventosAdmin = data.eventos || [];
                ca.innerHTML = `
                    <div class="section-header">
                        <h1 class="section-title">Prazos</h1>
                        <button class="action-btn" onclick="openAddEvento()">+ Novo evento</button>
                    </div>
                    <p style="color:var(--text-muted);font-size:0.85rem;margin-top:-1.2rem;margin-bottom:1.5rem;">Marque feriados, períodos de férias ou qualquer outra data importante. Elas aparecem automaticamente no calendário de prazos de todos os alunos. Clique num dia do calendário abaixo para criar um evento nele.</p>

                    <div class="acc-cal-head">
                        <div class="acc-cal-month" id="admCalMes"></div>
                        <div class="acc-cal-nav">
                            <button type="button" onclick="admCalRef.setMonth(admCalRef.getMonth()-1); renderCalendarioAdmin();" title="Mês anterior">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
                            </button>
                            <button type="button" onclick="admCalRef = new Date(); renderCalendarioAdmin();" style="width:auto;padding:0 0.8rem;font-size:0.78rem;">Hoje</button>
                            <button type="button" onclick="admCalRef.setMonth(admCalRef.getMonth()+1); renderCalendarioAdmin();" title="Próximo mês">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
                            </button>
                        </div>
                    </div>
                    <div class="acc-cal-grid" id="admCalGrid"></div>
                    <div class="acc-cal-legend">
                        <span><i style="background:rgba(239,68,68,0.55);"></i>Feriado</span>
                        <span><i style="background:rgba(245,158,11,0.55);"></i>Férias</span>
                        <span><i style="background:var(--primary);"></i>Data importante</span>
                    </div>

                    <div class="table-container" style="margin-top:2rem;">
                        <table class="table">
                            <thead><tr><th>Tipo</th><th>Título</th><th>Início</th><th>Fim</th><th>Ações</th></tr></thead>
                            <tbody id="admEventosTbody"></tbody>
                        </table>
                    </div>`;
                renderCalendarioAdmin();
                renderEventosTabela();
            } catch { ca.innerHTML = `<div class="empty-state"><p>Erro de conexão.</p></div>`; }
        }

        function renderEventosTabela() {
            const tbody = document.getElementById('admEventosTbody');
            if (!tbody) return;
            if (!eventosAdmin.length) { tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:2rem;color:var(--text-muted);font-size:0.85rem;">Nenhum evento cadastrado ainda.</td></tr>`; return; }
            tbody.innerHTML = eventosAdmin.slice().sort((a, b) => a.DATA_INICIO.localeCompare(b.DATA_INICIO)).map(ev => `
                <tr>
                    <td><span class="badge ${tipoEventoBadgeClass(ev.TIPO)}">${tipoEventoLabel(ev.TIPO)}</span></td>
                    <td><strong style="font-size:0.88rem;">${escapeHtml(ev.TITULO)}</strong></td>
                    <td style="font-size:0.85rem;">${formatarData(ev.DATA_INICIO)}</td>
                    <td style="font-size:0.85rem;">${ev.DATA_FIM ? formatarData(ev.DATA_FIM) : '—'}</td>
                    <td class="table-actions">
                        <button class="btn-icon btn-edit" onclick="editEvento(${ev.IDEVENTO})" title="Editar">&#9998;</button>
                        <button class="btn-icon btn-delete" onclick="deleteEvento(${ev.IDEVENTO})" title="Excluir">&#128465;</button>
                    </td>
                </tr>`).join('');
        }

        function renderCalendarioAdmin() {
            const mesEl = document.getElementById('admCalMes');
            const gridEl = document.getElementById('admCalGrid');
            if (!mesEl || !gridEl) return;
            const ano = admCalRef.getFullYear(), mes = admCalRef.getMonth();
            mesEl.textContent = `${ADM_MESES[mes]} de ${ano}`;

            const primeiroDia = new Date(ano, mes, 1);
            const inicioGrade = new Date(primeiroDia); inicioGrade.setDate(1 - primeiroDia.getDay());
            const hojeIso = admIso(new Date());

            let html = ADM_DOWS.map(d => `<div class="acc-cal-dow">${d}</div>`).join('');
            for (let i = 0; i < 42; i++) {
                const dia = new Date(inicioGrade); dia.setDate(inicioGrade.getDate() + i);
                const iso = admIso(dia);
                const marcas = eventosAdmin.filter(ev => iso >= ev.DATA_INICIO && iso <= (ev.DATA_FIM || ev.DATA_INICIO));
                const classes = ['acc-cal-day'];
                if (dia.getMonth() !== mes) classes.push('outro-mes');
                if (iso === hojeIso) classes.push('hoje');
                if (marcas.some(m => m.TIPO === 'FERIADO')) classes.push('feriado');
                if (marcas.some(m => m.TIPO === 'FERIAS')) classes.push('ferias');
                const titulo = marcas.map(m => escapeHtml(m.TITULO)).join(', ');
                const dots = marcas.length
                    ? `<div class="acc-cal-dots">${marcas.map(m => `<span style="background:${m.TIPO === 'FERIADO' ? 'var(--danger)' : m.TIPO === 'FERIAS' ? 'var(--warning)' : 'var(--primary)'}"></span>`).join('')}</div>`
                    : '';
                html += `<div class="${classes.join(' ')}" title="${titulo}" onclick="prefillEventoData('${iso}')">${dia.getDate()}${dots}</div>`;
            }
            gridEl.innerHTML = html;
        }
        function prefillEventoData(iso) {
            openAddEvento();
            document.getElementById('eventoDataInicio').value = iso;
        }

        function openAddEvento() {
            document.getElementById('eventoModalTitle').textContent = 'Novo evento';
            document.getElementById('eventoForm').reset();
            document.getElementById('eventoId').value = '';
            document.getElementById('eventoTipo').value = 'FERIADO';
            document.getElementById('eventoModal').classList.add('active');
        }
        function editEvento(id) {
            const ev = eventosAdmin.find(e => e.IDEVENTO == id);
            if (!ev) return;
            document.getElementById('eventoModalTitle').textContent = 'Editar evento';
            document.getElementById('eventoId').value = ev.IDEVENTO;
            document.getElementById('eventoTipo').value = ev.TIPO;
            document.getElementById('eventoTitulo').value = ev.TITULO;
            document.getElementById('eventoDataInicio').value = ev.DATA_INICIO;
            document.getElementById('eventoDataFim').value = ev.DATA_FIM || '';
            document.getElementById('eventoModal').classList.add('active');
        }
        function closeEventoModal() { document.getElementById('eventoModal').classList.remove('active'); }

        async function saveEvento(e) {
            e.preventDefault();
            const btn = e.target.querySelector('[type="submit"]');
            btn.disabled = true; const textoOriginal = btn.textContent; btn.textContent = 'Salvando...';

            const id = document.getElementById('eventoId').value;
            const fd = new FormData();
            fd.append('acao', id ? 'editar_evento' : 'criar_evento');
            if (id) fd.append('id', id);
            fd.append('tipo', document.getElementById('eventoTipo').value);
            fd.append('titulo', document.getElementById('eventoTitulo').value.trim());
            fd.append('data_inicio', document.getElementById('eventoDataInicio').value);
            fd.append('data_fim', document.getElementById('eventoDataFim').value);

            try {
                const res = await fetch('gerenciar_emprestimos.php', { method: 'POST', body: fd });
                const texto = await res.text();

                let data;
                try {
                    data = JSON.parse(texto);
                } catch (erroJson) {
                    stoktechToast('O PHP não retornou JSON. Resposta: ' + texto.substring(0, 300), 'erro');
                    console.error(texto);
                    return;
                }

                if (!data.sucesso) { stoktechToast(data.mensagem || 'Erro ao salvar evento.', 'erro'); return; }
                showNotification(data.mensagem);
                closeEventoModal();
                renderPrazos();
            } catch (err) {
                stoktechToast('Erro de conexão.', 'erro');
            } finally {
                btn.disabled = false; btn.textContent = textoOriginal;
            }
        }

        async function deleteEvento(id) {
            const ev = eventosAdmin.find(e => e.IDEVENTO == id);
            if (!ev) return;
            if (!(await stoktechConfirm({ titulo: 'Excluir evento', mensagem: `Você tem certeza que deseja excluir "${ev.TITULO}"?`, textoConfirmar: 'Excluir' }))) return;
            const fd = new FormData(); fd.append('acao', 'excluir_evento'); fd.append('id', id);
            try {
                const res = await fetch('gerenciar_emprestimos.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (data.sucesso) { showNotification(data.mensagem); renderPrazos(); } else { stoktechToast(data.mensagem, 'erro'); }
            } catch { stoktechToast('Erro de conexão.', 'erro'); }
        }

        function showNotification(msg) {
            stoktechToast(msg, 'sucesso');
        }
    </script>
    <script src="js/protecao.js"></script>
</body>
</html>