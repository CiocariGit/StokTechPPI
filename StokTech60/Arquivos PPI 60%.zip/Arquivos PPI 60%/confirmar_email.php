<?php

session_start();

require_once 'conexao.php';

header('Content-Type: application/json; charset=utf-8');


if (!isset($_SESSION['idusuario'])) {

    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Sessão expirada.'
    ]);

    exit;
}


$idUsuario = $_SESSION['idusuario'];

$codigo = trim($_POST['codigo'] ?? '');



if ($codigo === '') {

    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Digite o código recebido.'
    ]);

    exit;
}



$stmt = $pdo->prepare("
    SELECT *
    FROM CONFIRMACAO_EMAIL
    WHERE IDUSUARIO = ?
    AND CODIGO = ?
    AND CONFIRMADO = 0
    AND EXPIRA > NOW()
    ORDER BY ID DESC
    LIMIT 1
");


$stmt->execute([
    $idUsuario,
    $codigo
]);


$dados = $stmt->fetch(PDO::FETCH_ASSOC);



if (!$dados) {

    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Código inválido ou expirado.'
    ]);

    exit;
}



$stmt = $pdo->prepare("
    UPDATE USUARIO
    SET EMAIL = ?
    WHERE IDUSUARIO = ?
");


$stmt->execute([
    $dados['NOVO_EMAIL'],
    $idUsuario
]);



$stmt = $pdo->prepare("
    UPDATE CONFIRMACAO_EMAIL
    SET CONFIRMADO = 1
    WHERE ID = ?
");


$stmt->execute([
    $dados['ID']
]);



$_SESSION['email'] = $dados['NOVO_EMAIL'];



echo json_encode([

    'sucesso' => true,

    'mensagem' => 'Email alterado com sucesso!'

]);