<?php

require_once 'conexao.php';
require_once 'email_helper.php';
require_once 'notificacoes_helper.php';


$stmt=$pdo->query("

SELECT 
e.IDEMPRESTIMO,
e.IDALUNO,
e.PRAZO_DEVOLUCAO,
u.EMAIL,
u.NOME

FROM EMPRESTIMO e

INNER JOIN USUARIO u
ON u.IDUSUARIO=e.IDALUNO

WHERE 
e.STATUS='RETIRADO'

AND DATEDIFF(
e.PRAZO_DEVOLUCAO,
CURDATE()
)=3

");


foreach($stmt as $emp){


enviarEmail(

$emp['EMAIL'],

'Devolução próxima - StokTech',

"

<h3>
Olá {$emp['NOME']}
</h3>

<p>
Seu empréstimo vence em 3 dias.
</p>

<p>
Data:
{$emp['PRAZO_DEVOLUCAO']}
</p>

"

);

criarNotificacao(
    $pdo,
    (int)$emp['IDALUNO'],
    'Devolução se aproxima',
    "Seu empréstimo #{$emp['IDEMPRESTIMO']} vence em 3 dias, no dia {$emp['PRAZO_DEVOLUCAO']}.",
    'ALERTA',
    (int)$emp['IDEMPRESTIMO']
);

}