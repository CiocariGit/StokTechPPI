<?php
require_once 'auth.php';
require_once 'conexao.php';
require_once 'notificacoes_helper.php';
verificar_admin();

header('Content-Type: application/json; charset=utf-8');

function calcular_status_emprestimo($emp) {
    if (!empty($emp['STATUS'])) {
        return strtoupper($emp['STATUS']);
    }

    if (!empty($emp['DATA_DEVOLUCAO'])) {
        return 'DEVOLVIDO';
    }

    if (!empty($emp['DATA_RETIRADA'])) {
        return 'RETIRADO';
    }

    if (!empty($emp['IDADM'])) {
        return 'RECUSADO';
    }

    return 'PENDENTE';
}

function formatarDataBr(?string $data): string {
    if (!$data) return '—';
    $t = strtotime($data);
    return $t ? date('d/m/Y', $t) : $data;
}

function responder(bool $sucesso, string $mensagem = '', array $extra = []): void {
    echo json_encode(array_merge([
        'sucesso' => $sucesso,
        'mensagem' => $mensagem
    ], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

function cancelar_emprestimos_vencidos($pdo) {
    $stmt = $pdo->query("
        SELECT IDEMPRESTIMO, IDALUNO
        FROM EMPRESTIMO
        WHERE STATUS = 'APROVADO'
        AND DATA_RETIRADA IS NULL
        AND DATA_LIMITE_RETIRADA < CURDATE()
    ");

    $emprestimos = $stmt->fetchAll();

    foreach ($emprestimos as $emp) {
        $idEmprestimo = $emp['IDEMPRESTIMO'];

        $stmtItens = $pdo->prepare("
            SELECT IDCOMPONENTE, QUANTIDADE
            FROM CARRINHO
            WHERE IDEMPRESTIMO = ?
        ");
        $stmtItens->execute([$idEmprestimo]);
        $itens = $stmtItens->fetchAll();

        $stmtDevolver = $pdo->prepare("
            UPDATE COMPONENTE
            SET QUANTIDADE = QUANTIDADE + ?
            WHERE IDCOMPONENTE = ?
        ");

        foreach ($itens as $item) {
            $stmtDevolver->execute([
                (int)$item['QUANTIDADE'],
                (int)$item['IDCOMPONENTE']
            ]);
        }

        $stmtCancelar = $pdo->prepare("
            UPDATE EMPRESTIMO
            SET STATUS = 'CANCELADO'
            WHERE IDEMPRESTIMO = ?
        ");

        $stmtCancelar->execute([$idEmprestimo]);

        criarNotificacao(
            $pdo,
            (int)$emp['IDALUNO'],
            'Empréstimo cancelado',
            "Seu empréstimo #{$idEmprestimo} foi cancelado automaticamente por falta de retirada dentro do prazo.",
            'ERRO',
            $idEmprestimo
        );
    }
}

$acao = $_POST['acao'] ?? $_GET['acao'] ?? '';

try {
    // ------------------------------------------------------------
    // RESUMO — consulta leve usada pelo painel para detectar novidades
    // (novas mensagens, novos pedidos, mudanças de status/renovação)
    // sem precisar recarregar tudo. É chamada a cada poucos segundos.
    // ------------------------------------------------------------
    if ($acao === 'resumo') {
        session_write_close(); // não trava outras requisições da mesma sessão

        $stmt = $pdo->query("
            SELECT
                e.IDEMPRESTIMO,
                e.STATUS,
                e.PRAZO_DEVOLUCAO,
                (SELECT COALESCE(MAX(m.IDMENSAGEM), 0)
                   FROM MENSAGEM_EMPRESTIMO m
                  WHERE m.IDEMPRESTIMO = e.IDEMPRESTIMO) AS ULT_MSG,
                (SELECT COALESCE(MAX(r.IDRENOVACAO), 0)
                   FROM RENOVACAO_EMPRESTIMO r
                  WHERE r.IDEMPRESTIMO = e.IDEMPRESTIMO) AS ULT_RENOV,
                (SELECT COUNT(*)
                   FROM RENOVACAO_EMPRESTIMO r
                  WHERE r.IDEMPRESTIMO = e.IDEMPRESTIMO
                    AND r.STATUS = 'PENDENTE') AS RENOV_PEND
            FROM EMPRESTIMO e
            ORDER BY e.IDEMPRESTIMO
        ");

        responder(true, '', ['resumo' => $stmt->fetchAll()]);
    }

    // ------------------------------------------------------------
    // PRAZOS — feriados, férias e datas importantes definidos
    // livremente pelo gerenciador (aba "Prazos" do painel admin).
    // ------------------------------------------------------------
    if ($acao === 'listar_eventos') {
        try {
            $stmt = $pdo->query("
                SELECT IDEVENTO, TITULO, DATA_INICIO, DATA_FIM, TIPO
                FROM EVENTO_CALENDARIO
                ORDER BY DATA_INICIO
            ");
            responder(true, '', ['eventos' => $stmt->fetchAll()]);
        } catch (Throwable $e) {
            responder(false, 'A tabela de eventos ainda não foi criada. Execute o script SQL indicado na documentação.');
        }
    }

    if ($acao === 'criar_evento' || $acao === 'editar_evento') {
        $id        = (int)($_POST['id'] ?? 0);
        $titulo    = trim($_POST['titulo'] ?? '');
        $tipo      = strtoupper(trim($_POST['tipo'] ?? ''));
        $dataInicio = trim($_POST['data_inicio'] ?? '');
        $dataFim    = trim($_POST['data_fim'] ?? '');

        if ($titulo === '') {
            responder(false, 'Informe um título para o evento.');
        }
        if (!in_array($tipo, ['FERIADO', 'FERIAS', 'IMPORTANTE'], true)) {
            responder(false, 'Tipo de evento inválido.');
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dataInicio)) {
            responder(false, 'Informe uma data de início válida.');
        }
        if ($dataFim !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dataFim)) {
            responder(false, 'Data final inválida.');
        }
        if ($dataFim !== '' && $dataFim < $dataInicio) {
            responder(false, 'A data final não pode ser anterior à data inicial.');
        }

        $dataFimParam = $dataFim !== '' ? $dataFim : null;

        try {
            if ($acao === 'editar_evento') {
                if ($id <= 0) {
                    responder(false, 'Evento inválido.');
                }
                $pdo->prepare("
                    UPDATE EVENTO_CALENDARIO
                    SET TITULO = ?, TIPO = ?, DATA_INICIO = ?, DATA_FIM = ?
                    WHERE IDEVENTO = ?
                ")->execute([$titulo, $tipo, $dataInicio, $dataFimParam, $id]);

                responder(true, 'Evento atualizado com sucesso!');
            } else {
                $pdo->prepare("
                    INSERT INTO EVENTO_CALENDARIO (TITULO, TIPO, DATA_INICIO, DATA_FIM)
                    VALUES (?, ?, ?, ?)
                ")->execute([$titulo, $tipo, $dataInicio, $dataFimParam]);

                responder(true, 'Evento criado com sucesso!');
            }
        } catch (Throwable $e) {
            responder(false, 'A tabela de eventos ainda não foi criada. Execute o script SQL indicado na documentação.');
        }
    }

    if ($acao === 'excluir_evento') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            responder(false, 'Evento inválido.');
        }
        try {
            $pdo->prepare("DELETE FROM EVENTO_CALENDARIO WHERE IDEVENTO = ?")->execute([$id]);
            responder(true, 'Evento excluído com sucesso!');
        } catch (Throwable $e) {
            responder(false, 'A tabela de eventos ainda não foi criada. Execute o script SQL indicado na documentação.');
        }
    }

    cancelar_emprestimos_vencidos($pdo);

    if ($acao === 'listar') {
        $stmt = $pdo->query("
        SELECT 
            e.IDEMPRESTIMO,
            e.IDALUNO,
            e.IDADM,
            e.STATUS,
            e.DATA_EMPRESTIMO,
            e.DATA_APROVACAO,
            e.DATA_LIMITE_RETIRADA,
            e.DATA_RETIRADA,
            e.PRAZO_DEVOLUCAO,
            e.DATA_DEVOLUCAO,
            aluno.NOME AS ALUNO_NOME,
            aluno.EMAIL AS ALUNO_EMAIL,
            aluno.FOTO_PERFIL AS ALUNO_FOTO,
            adm.NOME AS ADM_NOME
        FROM EMPRESTIMO e
        LEFT JOIN USUARIO aluno ON aluno.IDUSUARIO = e.IDALUNO
        LEFT JOIN USUARIO adm ON adm.IDUSUARIO = e.IDADM
        ORDER BY e.IDEMPRESTIMO DESC
        ");
        $emprestimos = $stmt->fetchAll();

        $stmtItens = $pdo->prepare("
            SELECT car.IDEMPRESTIMO, car.IDCOMPONENTE, car.QUANTIDADE,
                   comp.NOME AS COMPONENTE_NOME
            FROM CARRINHO car
            INNER JOIN COMPONENTE comp ON comp.IDCOMPONENTE = car.IDCOMPONENTE
            WHERE car.IDEMPRESTIMO = ?
            ORDER BY comp.NOME
        ");

        $stmtMensagens = $pdo->prepare("
        SELECT 
            m.IDMENSAGEM,
            m.IDEMPRESTIMO,
            m.IDUSUARIO,
            m.MENSAGEM,
            m.DATA_ENVIO,
            u.NOME AS USUARIO_NOME,
            u.TIPO AS USUARIO_TIPO
        FROM MENSAGEM_EMPRESTIMO m
        INNER JOIN USUARIO u ON u.IDUSUARIO = m.IDUSUARIO
        WHERE m.IDEMPRESTIMO = ?
        ORDER BY m.DATA_ENVIO ASC, m.IDMENSAGEM ASC
    ");
        $stmtFeedback = $pdo->prepare("
            SELECT 
                f.IDFEEDBACK,
                f.IDEMPRESTIMO,
                f.IDADM,
                f.HOUVE_DANO,
                f.TIPO_DANO,
                f.GRAVIDADE,
                f.LAUDO,
                f.DATA_REGISTRO,
                adm.NOME AS ADM_NOME
            FROM DEVOLUCAO_FEEDBACK f
            LEFT JOIN USUARIO adm ON adm.IDUSUARIO = f.IDADM
            WHERE f.IDEMPRESTIMO = ?
            ORDER BY f.DATA_REGISTRO DESC
            LIMIT 1
        ");
        $stmtRenovacoes = $pdo->prepare("
            SELECT 
                r.IDRENOVACAO,
                r.IDEMPRESTIMO,
                r.IDALUNO,
                r.IDADM,
                r.DATA_SOLICITACAO,
                r.NOVA_DATA_SOLICITADA,
                r.MOTIVO,
                r.STATUS,
                r.COMENTARIO_ADMIN,
                r.DATA_RESPOSTA,
                adm.NOME AS ADM_NOME
            FROM RENOVACAO_EMPRESTIMO r
            LEFT JOIN USUARIO adm ON adm.IDUSUARIO = r.IDADM
            WHERE r.IDEMPRESTIMO = ?
            ORDER BY r.DATA_SOLICITACAO DESC
        ");

        foreach ($emprestimos as &$emp) {
            $emp['STATUS'] = calcular_status_emprestimo($emp);

            $stmtItens->execute([$emp['IDEMPRESTIMO']]);
            $emp['ITENS'] = $stmtItens->fetchAll();

            $stmtMensagens->execute([$emp['IDEMPRESTIMO']]);
            $emp['MENSAGENS'] = $stmtMensagens->fetchAll();

            $stmtFeedback->execute([$emp['IDEMPRESTIMO']]);
            $emp['FEEDBACK_DEVOLUCAO'] = $stmtFeedback->fetch();

            $stmtRenovacoes->execute([$emp['IDEMPRESTIMO']]);
            $emp['RENOVACOES'] = $stmtRenovacoes->fetchAll();
        }
        unset($emp);

        responder(true, '', ['emprestimos' => $emprestimos]);
    }

if ($acao === 'atualizar_status') {
    $idEmprestimo = isset($_POST['idemprestimo']) ? (int)$_POST['idemprestimo'] : -1;
    $novoStatus = strtoupper(trim($_POST['status'] ?? ''));

    $prazoDevolucao = trim($_POST['prazo_devolucao'] ?? '');

    $houveDano = isset($_POST['houve_dano']) ? (int)$_POST['houve_dano'] : 0;
    $tipoDano = trim($_POST['tipo_dano'] ?? '');
    $gravidade = trim($_POST['gravidade'] ?? '');
    $laudo = trim($_POST['laudo'] ?? '');
    

    $permitidos = ['PENDENTE', 'APROVADO', 'RECUSADO', 'DEVOLVIDO', 'RETIRADO', 'CANCELADO'];

    if ($idEmprestimo < 0 || !in_array($novoStatus, $permitidos, true)) {
        responder(false, 'Dados inválidos para atualizar o empréstimo.');
    }


    $pdo->beginTransaction();

    $stmtEmp = $pdo->prepare("
        SELECT *
        FROM EMPRESTIMO
        WHERE IDEMPRESTIMO = ?
        FOR UPDATE
    ");
    $stmtEmp->execute([$idEmprestimo]);
    $emprestimo = $stmtEmp->fetch();

    if (!$emprestimo) {
        throw new Exception('Empréstimo não encontrado.');
    }

    $statusAntigo = calcular_status_emprestimo($emprestimo);

    $stmtItens = $pdo->prepare("
        SELECT IDCOMPONENTE, QUANTIDADE
        FROM CARRINHO
        WHERE IDEMPRESTIMO = ?
    ");
    $stmtItens->execute([$idEmprestimo]);
    $itens = $stmtItens->fetchAll();

    if ($novoStatus === 'APROVADO') {
        if ($statusAntigo !== 'PENDENTE') {
            throw new Exception('Só é possível aprovar um empréstimo pendente.');
        }

        $stmtStock = $pdo->prepare("
            SELECT NOME, QUANTIDADE
            FROM COMPONENTE
            WHERE IDCOMPONENTE = ?
            FOR UPDATE
        ");

        foreach ($itens as $item) {
            $stmtStock->execute([$item['IDCOMPONENTE']]);
            $comp = $stmtStock->fetch();

            if (!$comp) {
                throw new Exception('Um componente do empréstimo não existe mais.');
            }

            if ((int)$item['QUANTIDADE'] > (int)$comp['QUANTIDADE']) {
                throw new Exception("Estoque insuficiente para aprovar {$comp['NOME']}.");
            }
        }

        $stmtBaixar = $pdo->prepare("
            UPDATE COMPONENTE
            SET QUANTIDADE = QUANTIDADE - ?
            WHERE IDCOMPONENTE = ?
        ");

        foreach ($itens as $item) {
            $stmtBaixar->execute([
                (int)$item['QUANTIDADE'],
                (int)$item['IDCOMPONENTE']
            ]);
        }

        $stmtUpdate = $pdo->prepare("
            UPDATE EMPRESTIMO
            SET 
                STATUS = 'APROVADO',
                IDADM = ?,
                DATA_APROVACAO = CURDATE(),
                DATA_LIMITE_RETIRADA = DATE_ADD(CURDATE(), INTERVAL 7 DAY),
                DATA_RETIRADA = NULL,
                DATA_DEVOLUCAO = NULL,
                PRAZO_DEVOLUCAO = NULL
            WHERE IDEMPRESTIMO = ?
        ");

        $stmtUpdate->execute([
            $_SESSION['idusuario'],
            $idEmprestimo
        ]);
        require_once 'email_helper.php';


            $stmt = $pdo->prepare("
            SELECT NOME, EMAIL
            FROM USUARIO
            WHERE IDUSUARIO = ?
            ");

            $stmt->execute([
            $emprestimo['IDALUNO']
            ]);

            $aluno = $stmt->fetch();


            enviarEmail(
            $aluno['EMAIL'],
            'Empréstimo aprovado - StokTech',

            "

            <h3>
            Seu empréstimo foi aprovado!
            </h3>

            <p>
            Você já pode retirar os componentes.
            </p>

            <p>
            Código:
            #$idEmprestimo
            </p>

            "
            );
    }

    if ($novoStatus === 'RECUSADO') {
        if ($statusAntigo === 'APROVADO' || $statusAntigo === 'RETIRADO') {
            $stmtDevolver = $pdo->prepare("
                UPDATE COMPONENTE
                SET QUANTIDADE = QUANTIDADE + ?
                WHERE IDCOMPONENTE = ?
            ");

            foreach ($itens as $item) {
                $stmtDevolver->execute([
                    (int)$item['QUANTIDADE'],
                    (int)$item['IDCOMPONENTE']
                ]);
            }
        }

        $stmtUpdate = $pdo->prepare("
            UPDATE EMPRESTIMO
            SET 
                STATUS = 'RECUSADO',
                IDADM = ?,
                DATA_RETIRADA = NULL,
                DATA_DEVOLUCAO = NULL,
                PRAZO_DEVOLUCAO = NULL
            WHERE IDEMPRESTIMO = ?
        ");

        $stmtUpdate->execute([
            $_SESSION['idusuario'],
            $idEmprestimo
        ]);

        $stmt = $pdo->prepare("
            SELECT NOME, EMAIL
            FROM USUARIO
            WHERE IDUSUARIO = ?
            ");

            $stmt->execute([
            $emprestimo['IDALUNO']
            ]);

            $aluno = $stmt->fetch();


            enviarEmail(
            $aluno['EMAIL'],
            'Empréstimo recusado - StokTech',

            "

            <h3>
            Seu pedido foi recusado.
            </h3>

            <p>
            Entre no sistema para verificar detalhes.
            </p>

            "
            );
    }

    if ($novoStatus === 'RETIRADO') {
        if ($statusAntigo !== 'APROVADO') {
            throw new Exception('Só é possível marcar como retirado um empréstimo aprovado.');
        }

        if ($prazoDevolucao === '') {
            throw new Exception('Informe o prazo de devolução.');
        }

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $prazoDevolucao)) {
            throw new Exception('Prazo de devolução inválido. Use o formato AAAA-MM-DD.');
        }

        $stmtUpdate = $pdo->prepare("
            UPDATE EMPRESTIMO
            SET 
                STATUS = 'RETIRADO',
                DATA_RETIRADA = CURDATE(),
                PRAZO_DEVOLUCAO = ?
            WHERE IDEMPRESTIMO = ?
        ");

        $stmtUpdate->execute([
            $prazoDevolucao,
            $idEmprestimo
        ]);
    }

    if ($novoStatus === 'DEVOLVIDO') {
        if ($statusAntigo !== 'RETIRADO') {
            throw new Exception('Só é possível marcar como devolvido um empréstimo retirado.');
        }

        if ($houveDano !== 0 && $houveDano !== 1) {
            throw new Exception('Valor inválido para dano.');
        }

        if ($houveDano === 1) {
            if ($tipoDano === '') {
                throw new Exception('Informe o tipo do dano.');
            }

            if ($gravidade === '') {
                throw new Exception('Informe a gravidade do dano.');
            }

            if ($laudo === '') {
                throw new Exception('Informe o laudo da devolução.');
            }
        } else {
            $tipoDano = '';
            $gravidade = '';
        }

        $stmtExisteFeedback = $pdo->prepare("
            SELECT IDFEEDBACK
            FROM DEVOLUCAO_FEEDBACK
            WHERE IDEMPRESTIMO = ?
            LIMIT 1
        ");
        $stmtExisteFeedback->execute([$idEmprestimo]);

        if ($stmtExisteFeedback->fetch()) {
            throw new Exception('Este empréstimo já possui feedback de devolução.');
        }

        $stmtDevolver = $pdo->prepare("
            UPDATE COMPONENTE
            SET QUANTIDADE = QUANTIDADE + ?
            WHERE IDCOMPONENTE = ?
        ");

        foreach ($itens as $item) {
            $stmtDevolver->execute([
                (int)$item['QUANTIDADE'],
                (int)$item['IDCOMPONENTE']
            ]);
        }

        $stmtFeedback = $pdo->prepare("
            INSERT INTO DEVOLUCAO_FEEDBACK
            (
                IDEMPRESTIMO,
                IDADM,
                HOUVE_DANO,
                TIPO_DANO,
                GRAVIDADE,
                LAUDO
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmtFeedback->execute([
            $idEmprestimo,
            $_SESSION['idusuario'],
            $houveDano,
            $tipoDano,
            $gravidade,
            $laudo
        ]);

        $stmtUpdate = $pdo->prepare("
            UPDATE EMPRESTIMO
            SET 
                STATUS = 'DEVOLVIDO',
                DATA_DEVOLUCAO = CURDATE()
            WHERE IDEMPRESTIMO = ?
        ");

        $stmtUpdate->execute([
            $idEmprestimo
        ]);
    }

    if ($novoStatus === 'CANCELADO') {
        if ($statusAntigo === 'APROVADO' || $statusAntigo === 'RETIRADO') {
            $stmtDevolver = $pdo->prepare("
                UPDATE COMPONENTE
                SET QUANTIDADE = QUANTIDADE + ?
                WHERE IDCOMPONENTE = ?
            ");

            foreach ($itens as $item) {
                $stmtDevolver->execute([
                    (int)$item['QUANTIDADE'],
                    (int)$item['IDCOMPONENTE']
                ]);
            }
        }

        $stmtUpdate = $pdo->prepare("
            UPDATE EMPRESTIMO
            SET 
                STATUS = 'CANCELADO',
                IDADM = ?
            WHERE IDEMPRESTIMO = ?
        ");

        $stmtUpdate->execute([
            $_SESSION['idusuario'],
            $idEmprestimo
        ]);

        // Encerra qualquer renovação que ainda tenha ficado pendente
        $stmtEncerrarRenovacoes = $pdo->prepare("
            UPDATE RENOVACAO_EMPRESTIMO
            SET
                STATUS = 'RECUSADA',
                IDADM = ?,
                COMENTARIO_ADMIN = 'Empréstimo encerrado após a devolução dos itens.',
                DATA_RESPOSTA = NOW()
            WHERE IDEMPRESTIMO = ?
            AND STATUS = 'PENDENTE'
        ");

        $stmtEncerrarRenovacoes->execute([
            $_SESSION['idusuario'],
            $idEmprestimo
        ]);
    }

        if ($statusAntigo === 'DEVOLVIDO') {
    throw new Exception('Este empréstimo já foi devolvido e está encerrado.');
}

    $mensagensNotificacao = [
        'APROVADO'  => ['Pedido aprovado', "Seu empréstimo #{$idEmprestimo} foi aprovado. Retire os itens no laboratório.", 'SUCESSO'],
        'RECUSADO'  => ['Pedido recusado', "Seu empréstimo #{$idEmprestimo} foi recusado pelo gerenciador.", 'ERRO'],
        'RETIRADO'  => ['Itens retirados', "A retirada do empréstimo #{$idEmprestimo} foi confirmada. Devolução até " . formatarDataBr($prazoDevolucao) . ".", 'INFO'],
        'DEVOLVIDO' => ['Devolução confirmada', "A devolução do empréstimo #{$idEmprestimo} foi confirmada. Obrigado!", 'SUCESSO'],
        'CANCELADO' => ['Pedido cancelado', "Seu empréstimo #{$idEmprestimo} foi cancelado pelo gerenciador.", 'ERRO'],
    ];
    if (isset($mensagensNotificacao[$novoStatus])) {
        [$tituloNotif, $msgNotif, $tipoNotif] = $mensagensNotificacao[$novoStatus];
        criarNotificacao($pdo, (int)$emprestimo['IDALUNO'], $tituloNotif, $msgNotif, $tipoNotif, $idEmprestimo);
    }

    $pdo->commit();

    responder(true, 'Status atualizado com sucesso.');
}   if ($acao === 'responder_renovacao') {
    $idRenovacao = isset($_POST['idrenovacao']) ? (int)$_POST['idrenovacao'] : -1;
    $decisao = strtoupper(trim($_POST['status'] ?? ''));
    $comentario = trim($_POST['comentario_admin'] ?? '');

    if ($idRenovacao < 0 || !in_array($decisao, ['APROVADA', 'RECUSADA'], true)) {
        responder(false, 'Dados inválidos para responder renovação.');
    }

    if ($comentario === '') {
        responder(false, 'O comentário do administrador é obrigatório.');
    }

    $pdo->beginTransaction();

    $stmtRen = $pdo->prepare("
        SELECT *
        FROM RENOVACAO_EMPRESTIMO
        WHERE IDRENOVACAO = ?
        FOR UPDATE
    ");
    $stmtRen->execute([$idRenovacao]);
    $renovacao = $stmtRen->fetch();

    if (!$renovacao) {
        throw new Exception('Solicitação de renovação não encontrada.');
    }

    if (strtoupper($renovacao['STATUS']) !== 'PENDENTE') {
        throw new Exception('Esta solicitação de renovação já foi respondida.');
    }

    $stmtEmp = $pdo->prepare("
        SELECT *
        FROM EMPRESTIMO
        WHERE IDEMPRESTIMO = ?
        FOR UPDATE
    ");
    $stmtEmp->execute([$renovacao['IDEMPRESTIMO']]);
    $emprestimo = $stmtEmp->fetch();

    if (!$emprestimo) {
        throw new Exception('Empréstimo não encontrado.');
    }

    if (strtoupper($emprestimo['STATUS']) !== 'RETIRADO') {
        throw new Exception('Só é possível renovar empréstimos que estão retirados.');
    }

    $stmtUpdateRen = $pdo->prepare("
        UPDATE RENOVACAO_EMPRESTIMO
        SET 
            STATUS = ?,
            IDADM = ?,
            COMENTARIO_ADMIN = ?,
            DATA_RESPOSTA = NOW()
        WHERE IDRENOVACAO = ?
    ");

    $stmtUpdateRen->execute([
        $decisao,
        $_SESSION['idusuario'],
        $comentario,
        $idRenovacao
    ]);

    require_once 'email_helper.php';


        $stmt = $pdo->prepare("
        SELECT EMAIL,NOME
        FROM USUARIO
        WHERE IDUSUARIO = ?
        ");

        $stmt->execute([
        $renovacao['IDALUNO']
        ]);

        $aluno=$stmt->fetch();


        $statusTexto =
        $decisao === 'APROVADA'
        ?
        "foi aprovada"
        :
        "foi recusada";


        enviarEmail(
        $aluno['EMAIL'],
        "Renovação $statusTexto - StokTech",

        "

        <h3>
        Sua renovação $statusTexto.
        </h3>

        <p>
        Comentário:
        $comentario
        </p>

        "
        );

    if ($decisao === 'APROVADA') {
        $stmtUpdateEmp = $pdo->prepare("
            UPDATE EMPRESTIMO
            SET PRAZO_DEVOLUCAO = ?
            WHERE IDEMPRESTIMO = ?
        ");

        $stmtUpdateEmp->execute([
            $renovacao['NOVA_DATA_SOLICITADA'],
            $renovacao['IDEMPRESTIMO']
        ]);
    }

    criarNotificacao(
        $pdo,
        (int)$renovacao['IDALUNO'],
        $decisao === 'APROVADA' ? 'Renovação aprovada' : 'Renovação recusada',
        "Sua solicitação de renovação do empréstimo #{$renovacao['IDEMPRESTIMO']} foi " . ($decisao === 'APROVADA' ? 'aprovada.' : 'recusada.') . ($comentario !== '' ? " Comentário: {$comentario}" : ''),
        $decisao === 'APROVADA' ? 'SUCESSO' : 'ERRO',
        (int)$renovacao['IDEMPRESTIMO']
    );

    $pdo->commit();

    responder(true, 'Solicitação de renovação respondida com sucesso.');
}
if ($acao === 'enviar_mensagem') {

    $idEmprestimo = isset($_POST['idemprestimo'])
        ? (int)$_POST['idemprestimo']
        : -1;

    $mensagem = trim($_POST['mensagem'] ?? '');

    if ($idEmprestimo < 0 || $mensagem === '') {
        responder(false, 'Dados inválidos para enviar mensagem.');
    }

    $stmtVerifica = $pdo->prepare("
        SELECT IDEMPRESTIMO, STATUS
        FROM EMPRESTIMO
        WHERE IDEMPRESTIMO = ?
    ");

    $stmtVerifica->execute([
        $idEmprestimo
    ]);

    $emprestimoMensagem = $stmtVerifica->fetch();

    if (!$emprestimoMensagem) {
        responder(false, 'Empréstimo não encontrado.');
    }

    $status = strtoupper(
        $emprestimoMensagem['STATUS'] ?? ''
    );

    if (in_array($status, [
        'DEVOLVIDO',
        'RECUSADO',
        'CANCELADO'
    ], true)) {

        responder(
            false,
            'Este empréstimo está encerrado e não aceita mais mensagens.'
        );
    }

    $stmt = $pdo->prepare("
        INSERT INTO MENSAGEM_EMPRESTIMO
        (
            IDEMPRESTIMO,
            IDUSUARIO,
            MENSAGEM
        )
        VALUES (?, ?, ?)
    ");

    $stmt->execute([
        $idEmprestimo,
        $_SESSION['idusuario'],
        $mensagem
    ]);

    responder(
        true,
        'Mensagem enviada com sucesso.'
    );
}

    responder(false, 'Ação inválida.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    responder(false, $e->getMessage());
}