<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Permite visualizar o catálogo sem estar logado. As ações de escrita
// (solicitar empréstimo, listar meus empréstimos, enviar mensagem) já
// verificam $_SESSION['idusuario'] individualmente e recusam convidados.
$modoConvidado = empty($_SESSION['idusuario']);

if (!$modoConvidado) {
    require_once 'auth.php';
}
require_once 'conexao.php';

$acao = $_GET['acao'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $acao === 'teste_ajax') {
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'sucesso' => true,
        'mensagem' => 'Conexão com menu_principal.php funcionando.'
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $acao === 'listar_meus_emprestimos') {
    header('Content-Type: application/json; charset=utf-8');

    try {
        if (!isset($_SESSION['idusuario'])) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Sessão expirada. Faça login novamente.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $stmt = $pdo->prepare("
        SELECT 
            e.IDEMPRESTIMO,
            e.IDALUNO,
            e.IDADM,
            e.STATUS,
            e.DATA_EMPRESTIMO,
            e.DATA_APROVACAO,
            e.DATA_LIMITE_RETIRADA,
            e.DATA_RETIRADA,
            e.PRAZO_DEVOLUCAO,
            e.DATA_DEVOLUCAO
        FROM EMPRESTIMO e
        WHERE e.IDALUNO = ?
        ORDER BY e.IDEMPRESTIMO DESC
    ");

        $stmt->execute([$_SESSION['idusuario']]);
        $emprestimos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmtItens = $pdo->prepare("
            SELECT 
                c.IDEMPRESTIMO,
                c.IDCOMPONENTE,
                c.QUANTIDADE,
                comp.NOME AS COMPONENTE_NOME
            FROM CARRINHO c
            LEFT JOIN COMPONENTE comp ON comp.IDCOMPONENTE = c.IDCOMPONENTE
            WHERE c.IDEMPRESTIMO = ?
        ");
        $stmtMensagens = $pdo->prepare("
        SELECT 
            m.IDMENSAGEM,
            m.IDEMPRESTIMO,
            m.IDUSUARIO,
            m.MENSAGEM,
            m.DATA_ENVIO,
            u.NOME AS USUARIO_NOME,
            u.TIPO AS USUARIO_TIPO
        FROM MENSAGEM_EMPRESTIMO m
        INNER JOIN USUARIO u ON u.IDUSUARIO = m.IDUSUARIO
        WHERE m.IDEMPRESTIMO = ?
        ORDER BY m.DATA_ENVIO ASC, m.IDMENSAGEM ASC
    ");

        $stmtRenovacoes = $pdo->prepare("
        SELECT 
            r.IDRENOVACAO,
            r.IDEMPRESTIMO,
            r.IDALUNO,
            r.IDADM,
            r.DATA_SOLICITACAO,
            r.NOVA_DATA_SOLICITADA,
            r.MOTIVO,
            r.STATUS,
            r.COMENTARIO_ADMIN,
            r.DATA_RESPOSTA,
            adm.NOME AS ADM_NOME
        FROM RENOVACAO_EMPRESTIMO r
        LEFT JOIN USUARIO adm ON adm.IDUSUARIO = r.IDADM
        WHERE r.IDEMPRESTIMO = ?
        ORDER BY r.DATA_SOLICITACAO DESC
    ");

        foreach ($emprestimos as &$emp) {
    if (!empty($emp['STATUS'])) {
        $emp['STATUS'] = strtoupper($emp['STATUS']);
    } else if (!empty($emp['DATA_DEVOLUCAO'])) {
        $emp['STATUS'] = 'DEVOLVIDO';
    } else if (!empty($emp['DATA_RETIRADA'])) {
        $emp['STATUS'] = 'RETIRADO';
    } else if (!empty($emp['IDADM'])) {
        $emp['STATUS'] = 'RECUSADO';
    } else {
        $emp['STATUS'] = 'PENDENTE';
    }

    $stmtItens->execute([$emp['IDEMPRESTIMO']]);
    $emp['ITENS'] = $stmtItens->fetchAll(PDO::FETCH_ASSOC);

    $stmtMensagens->execute([$emp['IDEMPRESTIMO']]);
    $emp['MENSAGENS'] = $stmtMensagens->fetchAll(PDO::FETCH_ASSOC);

    $stmtRenovacoes->execute([$emp['IDEMPRESTIMO']]);
    $emp['RENOVACOES'] = $stmtRenovacoes->fetchAll(PDO::FETCH_ASSOC);
}

        unset($emp);

        echo json_encode([
            'sucesso' => true,
            'emprestimos' => $emprestimos
        ], JSON_UNESCAPED_UNICODE);

        exit;

    } catch (Exception $e) {
        echo json_encode([
            'sucesso' => false,
            'mensagem' => $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);

        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $acao === 'resumo_meus_emprestimos') {
    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION['idusuario'])) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Sessão expirada.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $idUsuarioResumo = $_SESSION['idusuario'];
    session_write_close(); // não trava outras requisições da mesma sessão

    try {
        $stmt = $pdo->prepare("
            SELECT
                e.IDEMPRESTIMO,
                e.STATUS,
                e.PRAZO_DEVOLUCAO,
                (SELECT COALESCE(MAX(m.IDMENSAGEM), 0)
                   FROM MENSAGEM_EMPRESTIMO m
                  WHERE m.IDEMPRESTIMO = e.IDEMPRESTIMO) AS ULT_MSG,
                (SELECT COALESCE(MAX(r.IDRENOVACAO), 0)
                   FROM RENOVACAO_EMPRESTIMO r
                  WHERE r.IDEMPRESTIMO = e.IDEMPRESTIMO) AS ULT_RENOV,
                (SELECT COUNT(*)
                   FROM RENOVACAO_EMPRESTIMO r
                  WHERE r.IDEMPRESTIMO = e.IDEMPRESTIMO
                    AND r.STATUS <> 'PENDENTE') AS RENOV_RESP
            FROM EMPRESTIMO e
            WHERE e.IDALUNO = ?
            ORDER BY e.IDEMPRESTIMO
        ");
        $stmt->execute([$idUsuarioResumo]);

        echo json_encode(['sucesso' => true, 'resumo' => $stmt->fetchAll(PDO::FETCH_ASSOC)], JSON_UNESCAPED_UNICODE);
    } catch (Exception $e) {
        echo json_encode(['sucesso' => false, 'mensagem' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $acao === 'listar_notificacoes') {
    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION['idusuario'])) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Sessão expirada.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $ordem = ($_GET['ordem'] ?? 'recentes') === 'antigas' ? 'ASC' : 'DESC';

    try {
        $stmt = $pdo->prepare("
            SELECT IDNOTIFICACAO, TITULO, MENSAGEM, TIPO, IDEMPRESTIMO, LIDA, CRIADA_EM
            FROM NOTIFICACAO
            WHERE IDUSUARIO = ?
            ORDER BY CRIADA_EM $ordem, IDNOTIFICACAO $ordem
        ");
        $stmt->execute([$_SESSION['idusuario']]);

        echo json_encode(['sucesso' => true, 'notificacoes' => $stmt->fetchAll(PDO::FETCH_ASSOC)], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'A área de notificações ainda não foi configurada no banco de dados.'], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $acao === 'marcar_notificacao_lida') {
    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION['idusuario'])) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Sessão expirada.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $dados = json_decode(file_get_contents('php://input'), true);
    $todas = !empty($dados['todas']);
    $id = isset($dados['idnotificacao']) ? (int)$dados['idnotificacao'] : -1;

    try {
        if ($todas) {
            $pdo->prepare("UPDATE NOTIFICACAO SET LIDA = 1 WHERE IDUSUARIO = ? AND LIDA = 0")
                ->execute([$_SESSION['idusuario']]);
        } elseif ($id >= 0) {
            $pdo->prepare("UPDATE NOTIFICACAO SET LIDA = 1 WHERE IDNOTIFICACAO = ? AND IDUSUARIO = ?")
                ->execute([$id, $_SESSION['idusuario']]);
        }
        echo json_encode(['sucesso' => true], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['sucesso' => false, 'mensagem' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $acao === 'listar_eventos_calendario') {
    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION['idusuario'])) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Sessão expirada.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    try {
        $stmt = $pdo->query("SELECT IDEVENTO, TITULO, DATA_INICIO, DATA_FIM, TIPO FROM EVENTO_CALENDARIO ORDER BY DATA_INICIO");
        echo json_encode(['sucesso' => true, 'eventos' => $stmt->fetchAll(PDO::FETCH_ASSOC)], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        // Calendário de feriados/férias é opcional: se a tabela ainda não existe,
        // o painel continua funcionando só com "hoje" e os prazos de devolução.
        echo json_encode(['sucesso' => true, 'eventos' => []], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $acao === 'enviar_doacao') {
    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION['idusuario'])) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Sessão expirada.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $descricao  = trim($_POST['descricao'] ?? '');
    $danificado = isset($_POST['danificado']) && $_POST['danificado'] == '1' ? 1 : 0;

    if ($descricao === '') {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Descreva o componente que deseja doar.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (empty($_FILES['imagem']['name'])) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Anexe uma foto do componente.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $ext = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
    $permitidos = ['jpg', 'jpeg', 'png', 'webp'];

    if (!in_array($ext, $permitidos, true)) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Formato de imagem inválido. Use JPG, PNG ou WEBP.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($_FILES['imagem']['size'] > 8 * 1024 * 1024) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'A imagem deve ter no máximo 8MB.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    try {
        $pasta = 'img/doacoes/';
        if (!is_dir($pasta)) {
            mkdir($pasta, 0755, true);
        }

        $nomeArquivo = 'doacao_' . $_SESSION['idusuario'] . '_' . time() . '_' . uniqid() . '.' . $ext;

        if (!move_uploaded_file($_FILES['imagem']['tmp_name'], $pasta . $nomeArquivo)) {
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao salvar a imagem.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO DOACAO (IDUSUARIO, DESCRICAO, DANIFICADO, IMAGEM, STATUS, CRIADA_EM)
            VALUES (?, ?, ?, ?, 'PENDENTE', NOW())
        ");
        $stmt->execute([$_SESSION['idusuario'], $descricao, $danificado, $pasta . $nomeArquivo]);

        echo json_encode(['sucesso' => true, 'mensagem' => 'Proposta de doação enviada! O gerenciador vai analisar em breve.'], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'A área de doações ainda não foi configurada no banco de dados.'], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $acao === 'listar_minhas_doacoes') {
    header('Content-Type: application/json; charset=utf-8');

    if (!isset($_SESSION['idusuario'])) {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Sessão expirada.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT IDDOACAO, DESCRICAO, DANIFICADO, IMAGEM, STATUS, RESPOSTA_ADMIN, CRIADA_EM, RESPONDIDA_EM
            FROM DOACAO
            WHERE IDUSUARIO = ?
            ORDER BY CRIADA_EM DESC
        ");
        $stmt->execute([$_SESSION['idusuario']]);

        echo json_encode(['sucesso' => true, 'doacoes' => $stmt->fetchAll(PDO::FETCH_ASSOC)], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['sucesso' => true, 'doacoes' => []], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $acao === 'solicitar_emprestimo') {
    header('Content-Type: application/json; charset=utf-8');

    try {
        $dados = json_decode(file_get_contents('php://input'), true);

        if (!$dados || !isset($dados['itens']) || count($dados['itens']) === 0) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Carrinho vazio.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if (!isset($_SESSION['idusuario'])) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Sessão expirada. Faça login novamente.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $pdo->beginTransaction();

        $stmtProximoId = $pdo->query("SELECT COALESCE(MAX(IDEMPRESTIMO), -1) + 1 AS PROXIMO_ID FROM EMPRESTIMO");
        $proximoId = (int)$stmtProximoId->fetch(PDO::FETCH_ASSOC)['PROXIMO_ID'];

        $stmtEmprestimo = $pdo->prepare("
            INSERT INTO EMPRESTIMO 
            (IDEMPRESTIMO, IDALUNO, IDADM, DATA_EMPRESTIMO, DATA_RETIRADA, DATA_DEVOLUCAO)
            VALUES (?, ?, NULL, CURDATE(), NULL, NULL)
        ");

        $stmtEmprestimo->execute([
            $proximoId,
            $_SESSION['idusuario']
        ]);

        $stmtCarrinho = $pdo->prepare("
            INSERT INTO CARRINHO 
            (IDEMPRESTIMO, IDCOMPONENTE, QUANTIDADE)
            VALUES (?, ?, ?)
        ");

        foreach ($dados['itens'] as $item) {
            $idComponente = (int)($item['id'] ?? -1);
            $quantidade = (int)($item['quantidade'] ?? 0);

            if ($idComponente < 0) {
                throw new Exception('Componente inválido.');
            }

            if ($quantidade <= 0) {
                $quantidade = 1;
            }

            $stmtCarrinho->execute([
                $proximoId,
                $idComponente,
                $quantidade
            ]);
        }

        $pdo->commit();

        require_once 'email_helper.php';


        $stmt = $pdo->prepare("
        SELECT NOME, EMAIL 
        FROM USUARIO 
        WHERE IDUSUARIO = ?
        ");

        $stmt->execute([
        $_SESSION['idusuario']
        ]);

        $aluno = $stmt->fetch();


        enviarEmail(
        'stoktech.2026@gmail.com',
        'Novo pedido de empréstimo - StokTech',
        "

        <h3>Novo pedido recebido</h3>

        <p>
        Aluno:
        <b>{$aluno['NOME']}</b>
        </p>

        <p>
        Email:
        {$aluno['EMAIL']}
        </p>

        <p>
        Código do empréstimo:
        #$proximoId
        </p>

        <p>
        Acesse o painel administrativo para analisar.
        </p>

        "
        );

        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Solicitação enviada com sucesso.',
            'idemprestimo' => $proximoId
        ], JSON_UNESCAPED_UNICODE);

        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        echo json_encode([
            'sucesso' => false,
            'mensagem' => 'Erro ao salvar empréstimo: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);

        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $acao === 'solicitar_renovacao') {
    header('Content-Type: application/json; charset=utf-8');

    try {
        if (!isset($_SESSION['idusuario'])) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Sessão expirada. Faça login novamente.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $dados = json_decode(file_get_contents('php://input'), true);

        $idEmprestimo = isset($dados['idemprestimo']) ? (int)$dados['idemprestimo'] : -1;
        $novaData = trim($dados['nova_data'] ?? '');
        $motivo = trim($dados['motivo'] ?? '');

        if ($idEmprestimo < 0 || $novaData === '' || $motivo === '') {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Preencha a nova data e o motivo da renovação.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $novaData)) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Data inválida. Use o formato AAAA-MM-DD.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $stmtEmp = $pdo->prepare("
            SELECT IDEMPRESTIMO, STATUS, PRAZO_DEVOLUCAO
            FROM EMPRESTIMO
            WHERE IDEMPRESTIMO = ? AND IDALUNO = ?
        ");
        $stmtEmp->execute([
            $idEmprestimo,
            $_SESSION['idusuario']
        ]);

        $emprestimo = $stmtEmp->fetch(PDO::FETCH_ASSOC);

        if (!$emprestimo) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Empréstimo não encontrado para este usuário.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if (strtoupper($emprestimo['STATUS']) !== 'RETIRADO') {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Só é possível pedir renovação de empréstimos retirados.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if (!empty($emprestimo['PRAZO_DEVOLUCAO']) && $novaData <= $emprestimo['PRAZO_DEVOLUCAO']) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'A nova data precisa ser maior que o prazo atual.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $stmtPendente = $pdo->prepare("
            SELECT IDRENOVACAO
            FROM RENOVACAO_EMPRESTIMO
            WHERE IDEMPRESTIMO = ? AND STATUS = 'PENDENTE'
            LIMIT 1
        ");
        $stmtPendente->execute([$idEmprestimo]);

        if ($stmtPendente->fetch()) {
            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Este empréstimo já possui uma solicitação de renovação pendente.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO RENOVACAO_EMPRESTIMO
            (
                IDEMPRESTIMO,
                IDALUNO,
                NOVA_DATA_SOLICITADA,
                MOTIVO,
                STATUS
            )
            VALUES (?, ?, ?, ?, 'PENDENTE')
        ");

        $stmt->execute([
            $idEmprestimo,
            $_SESSION['idusuario'],
            $novaData,
            $motivo
        ]);

        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Solicitação de renovação enviada com sucesso.'
        ], JSON_UNESCAPED_UNICODE);
        exit;

    } catch (Exception $e) {
        echo json_encode([
            'sucesso' => false,
            'mensagem' => 'Erro ao solicitar renovação: ' . $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $acao === 'enviar_mensagem_emprestimo') {

    header('Content-Type: application/json; charset=utf-8');

    try {

        if (!isset($_SESSION['idusuario'])) {

            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Sessão expirada. Faça login novamente.'
            ], JSON_UNESCAPED_UNICODE);

            exit;
        }


        $dados = json_decode(
            file_get_contents('php://input'),
            true
        );


        $idEmprestimo = isset($dados['idemprestimo'])
            ? (int)$dados['idemprestimo']
            : -1;

        $mensagem = trim(
            $dados['mensagem'] ?? ''
        );


        if ($idEmprestimo < 0 || $mensagem === '') {

            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Dados inválidos para enviar mensagem.'
            ], JSON_UNESCAPED_UNICODE);

            exit;
        }


        $stmtVerifica = $pdo->prepare("
            SELECT
                IDEMPRESTIMO,
                STATUS
            FROM EMPRESTIMO
            WHERE IDEMPRESTIMO = ?
            AND IDALUNO = ?
        ");


        $stmtVerifica->execute([
            $idEmprestimo,
            $_SESSION['idusuario']
        ]);


        $emprestimoMensagem =
            $stmtVerifica->fetch(PDO::FETCH_ASSOC);


        if (!$emprestimoMensagem) {

            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Empréstimo não encontrado para este usuário.'
            ], JSON_UNESCAPED_UNICODE);

            exit;
        }


        $status = strtoupper(
            $emprestimoMensagem['STATUS'] ?? ''
        );


        if (in_array($status, [
            'DEVOLVIDO',
            'RECUSADO',
            'CANCELADO'
        ], true)) {

            echo json_encode([
                'sucesso' => false,
                'mensagem' => 'Este empréstimo está encerrado e não aceita mais mensagens.'
            ], JSON_UNESCAPED_UNICODE);

            exit;
        }


        $stmt = $pdo->prepare("
            INSERT INTO MENSAGEM_EMPRESTIMO
            (
                IDEMPRESTIMO,
                IDUSUARIO,
                MENSAGEM
            )
            VALUES (?, ?, ?)
        ");


        $stmt->execute([
            $idEmprestimo,
            $_SESSION['idusuario'],
            $mensagem
        ]);


        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Mensagem enviada com sucesso.'
        ], JSON_UNESCAPED_UNICODE);

        exit;


    } catch (Exception $e) {

        echo json_encode([
            'sucesso' => false,
            'mensagem' => $e->getMessage()
        ], JSON_UNESCAPED_UNICODE);

        exit;
    }
}


if (!$modoConvidado && (empty($_SESSION['email']) || !isset($_SESSION['foto_perfil']))) {
    $stmt = $pdo->prepare("SELECT EMAIL, FOTO_PERFIL FROM USUARIO WHERE IDUSUARIO = ?");
    $stmt->execute([$_SESSION['idusuario']]);
    $row = $stmt->fetch();
    if ($row) {
        $_SESSION['email']       = $row['EMAIL'];
        $_SESSION['foto_perfil'] = $row['FOTO_PERFIL'];
    }
}

// CPF/TIPO só para exibição em "Dados Pessoais" — não fica em sessão porque
// não muda com frequência e evita dado desatualizado após troca de tipo pelo admin.
$dadosPessoaisAluno = ['cpf' => '', 'tipo' => 'ALUNO'];
if (!$modoConvidado) {
    $stmt = $pdo->prepare("SELECT CPF, TIPO FROM USUARIO WHERE IDUSUARIO = ?");
    $stmt->execute([$_SESSION['idusuario']]);
    if ($row = $stmt->fetch()) {
        $dadosPessoaisAluno = ['cpf' => $row['CPF'] ?? '', 'tipo' => $row['TIPO'] ?? 'ALUNO'];
    }
}

$categoriasAluno = [];
$produtosAluno   = [];

try {
    $stmtCategorias = $pdo->query("SELECT IDCATEGORIA, NOME, ICONE FROM CATEGORIA ORDER BY NOME");
    $categoriasAluno = $stmtCategorias->fetchAll();

    $stmtComponentes = $pdo->query("
    SELECT c.IDCOMPONENTE, c.NOME, c.IMAGEM, c.DESCRICAO_CURTA,
           c.DESCRICAO_COMPLETA, c.ESPECIFICACOES, c.QUANTIDADE,
           c.IDCATEGORIA, cat.NOME AS CATEGORIA_NOME, cat.ICONE AS CATEGORIA_ICONE
    FROM COMPONENTE c
    LEFT JOIN CATEGORIA cat ON c.IDCATEGORIA = cat.IDCATEGORIA
    WHERE c.ATIVO = 1
    ORDER BY c.NOME
");

    foreach ($stmtComponentes->fetchAll() as $comp) {
        $specs = [];
        if (!empty($comp['ESPECIFICACOES'])) {
            $json = json_decode($comp['ESPECIFICACOES'], true);
            if (is_array($json)) {
                $specs = $json;
            }
        }

        $produtosAluno[] = [
            'id'              => (int)$comp['IDCOMPONENTE'],
            'name'            => $comp['NOME'] ?? 'Componente',
            'category'        => (string)($comp['IDCATEGORIA'] ?? ''),
            'categoryName'    => $comp['CATEGORIA_NOME'] ?? 'Sem categoria',
            'icon'            => $comp['CATEGORIA_ICONE'] ?: '📦',
            'image'           => $comp['IMAGEM'] ?: '',
            'description'     => $comp['DESCRICAO_CURTA'] ?? '',
            'fullDescription' => $comp['DESCRICAO_COMPLETA'] ?? '',
            'stock'           => (int)($comp['QUANTIDADE'] ?? 0),
            'specs'           => $specs
        ];
    }
} catch (Throwable $e) {
    $categoriasAluno = [];
    $produtosAluno   = [];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StokTech — Componentes</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="css/protecao.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
:root {
    --primary: #6b1fad;
    --primary-light: #b662ff;
    --primary-subtle: rgba(107,31,173,0.12);
    --bg: #0d0d0f;
    --surface: #131316;
    --surface-2: #1a1a1f;
    --surface-3: #202028;
    --border: #252530;
    --text: #f0f0f4;
    --text-muted: #7a7a90;
    --text-subtle: #4a4a60;
    --success: #22c55e;
    --warning: #f59e0b;
    --danger: #ef4444;
    --radius: 4px;
    --sidebar-w: 280px;
    --header-h: 64px;
}
body.light-mode {
    --bg: #f0f0f5;
    --surface: #ffffff;
    --surface-2: #f6f6fb;
    --surface-3: #ebebf5;
    --border: #dcdce8;
    --text: #0d0d1a;
    --text-muted: #55556a;
    --text-subtle: #aaaabc;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: 'IBM Plex Sans', sans-serif;
    background: var(--bg);
    color: var(--text);
    transition: background 0.3s, color 0.3s;
    overflow-x: hidden;
}

/* ── HEADER ── */
.header {
    height: var(--header-h);
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    padding: 0 1.25rem;
    gap: 1rem;
    position: sticky;
    top: 0;
    z-index: 200;
}
.sidebar-toggle {
    width: 42px;
    height: 42px;
    background: transparent;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    flex-shrink: 0;
    transition: border-color 0.2s, background 0.2s;
}
.sidebar-toggle:hover { border-color: var(--primary); background: var(--primary-subtle); }
.sidebar-toggle span {
    display: block;
    width: 16px;
    height: 1.5px;
    background: var(--text-muted);
    transition: all 0.3s;
    border-radius: 1px;
}
.logo-img { height: 32px; object-fit: contain; flex-shrink: 0; }
.search-bar {
    flex: 1;
    max-width: 420px;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 0 0.75rem;
    transition: border-color 0.2s;
}
.search-bar:focus-within { border-color: var(--primary); }
.search-icon { color: var(--text-subtle); font-size: 0.85rem; flex-shrink: 0; }
.search-bar input {
    flex: 1;
    background: transparent;
    border: none;
    outline: none;
    color: var(--text);
    font-size: 0.95rem;
    font-family: 'IBM Plex Sans', sans-serif;
    padding: 0.6rem 0;
}
.search-bar input::placeholder { color: var(--text-subtle); }
.header-actions { margin-left: auto; display: flex; align-items: center; gap: 0.5rem; }
.hdr-btn {
    width: 42px;
    height: 42px;
    background: transparent;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.15rem;
    color: var(--text-muted);
    transition: all 0.2s;
    position: relative;
}
.hdr-btn svg { width: 20px; height: 20px; }
.hdr-btn:hover { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }
.cart-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background: var(--primary);
    color: white;
    font-size: 0.65rem;
    font-weight: 700;
    font-family: 'IBM Plex Mono', monospace;
    width: 17px;
    height: 17px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}
.logout-form { margin: 0; }

/* User info in header */
.hdr-user {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    cursor: pointer;
    padding: 0.3rem 0.6rem;
    border-radius: var(--radius);
    border: 1px solid transparent;
    transition: all 0.2s;
    position: relative;
}
.hdr-user:hover { border-color: var(--border); background: var(--surface-2); }
.hdr-user:hover .edit-pencil { opacity: 1; }
.hdr-avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: var(--primary-subtle);
    border: 2px solid var(--primary);
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    font-size: 1rem;
    color: var(--primary-light);
}
.hdr-avatar img { width: 100%; height: 100%; object-fit: cover; }
.hdr-user-info { display: flex; flex-direction: column; line-height: 1.2; }
.hdr-user-name {
    font-size: 0.92rem;
    font-weight: 600;
    color: var(--text);
    white-space: nowrap;
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
}
.hdr-user-email {
    font-size: 0.78rem;
    color: var(--text-muted);
    white-space: nowrap;
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
}
.edit-pencil {
    opacity: 0;
    transition: opacity 0.2s;
    font-size: 0.75rem;
    color: var(--primary-light);
    margin-left: 0.2rem;
}

/* ── LAYOUT ── */
.main-container { display: flex; }

/* ── SIDEBAR ── */
.sidebar {
    width: var(--sidebar-w);
    background: var(--surface);
    border-right: 1px solid var(--border);
    min-height: calc(100vh - var(--header-h));
    display: flex;
    flex-direction: column;
    transition: width 0.3s ease, transform 0.3s ease;
    overflow-x: hidden;
    overflow-y: auto;
    flex-shrink: 0;
    position: sticky;
    top: var(--header-h);
    height: calc(100vh - var(--header-h));
    align-self: flex-start;
}
.sidebar.collapsed { width: 0; border-right: none; }
.sidebar-inner { width: var(--sidebar-w); padding: 1.5rem 0; overflow: hidden; }
.sidebar-section-label {
    padding: 0 1.25rem 0.6rem;
    font-size: 0.76rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--text-subtle);
    font-family: 'IBM Plex Mono', monospace;
}
.category-list { list-style: none; padding: 0; margin: 0 0 1.5rem 0; }
.category-item {
    display: flex;
    align-items: center;
    gap: 0.85rem;
    padding: 0.8rem 1.25rem;
    cursor: pointer;
    color: var(--text-muted);
    font-size: 1.02rem;
    font-weight: 400;
    transition: all 0.15s;
    border-left: 2px solid transparent;
    white-space: nowrap;
}
.category-item svg { flex-shrink: 0; opacity: 0.6; width: 19px; height: 19px; }
.category-item:hover { background: var(--surface-2); color: var(--text); border-left-color: var(--border); }
.category-item:hover svg { opacity: 1; }
.category-item.active {
    background: var(--primary-subtle);
    color: var(--primary-light);
    border-left-color: var(--primary);
    font-weight: 500;
}
.category-item.active svg { opacity: 1; color: var(--primary-light); }

/* ── CONTENT ── */
.content-area { flex: 1; padding: 2rem; min-width: 0; }
.section-header {
    display: flex;
    align-items: baseline;
    gap: 0.75rem;
    margin-bottom: 1.75rem;
}
.section-title { font-size: 1.4rem; font-weight: 600; letter-spacing: -0.02em; }
.section-count {
    font-size: 0.8rem;
    color: var(--text-muted);
    font-family: 'IBM Plex Mono', monospace;
    background: var(--surface-2);
    border: 1px solid var(--border);
    padding: 0.2rem 0.5rem;
    border-radius: 2px;
}

/* ── PRODUCTS GRID ── */
.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: 1.25rem;
}
.product-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
    transition: border-color 0.2s, box-shadow 0.2s, transform 0.15s;
}
.product-card:hover {
    border-color: var(--primary);
    box-shadow: 0 4px 20px rgba(107,31,173,0.15);
    transform: translateY(-2px);
}
.product-image {
    width: 100%;
    height: 160px;
    background: var(--surface-2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3.5rem;
    border-bottom: 1px solid var(--border);
    overflow: hidden;
}
.product-image img,
.cart-item-icon img,
.details-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}
.product-info { padding: 1.25rem; }
.product-name { font-size: 0.95rem; font-weight: 600; margin-bottom: 0.35rem; }
.product-description { color: var(--text-muted); font-size: 0.82rem; margin-bottom: 0.85rem; line-height: 1.5; }
.product-stock {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 0.85rem;
    font-size: 0.8rem;
    color: var(--text-muted);
}
.stock-ok { color: var(--success); font-weight: 600; font-family: 'IBM Plex Mono', monospace; }
.stock-low { color: var(--warning); font-weight: 600; font-family: 'IBM Plex Mono', monospace; }
.stock-out { color: var(--danger); font-weight: 600; font-family: 'IBM Plex Mono', monospace; }
.product-actions { display: flex; flex-direction: column; gap: 0.5rem; }
.quantity-control {
    display: flex;
    align-items: center;
    gap: 0.4rem;
    background: var(--surface-2);
    padding: 0.35rem;
    border-radius: var(--radius);
    border: 1px solid var(--border);
}
.qty-btn {
    width: 28px;
    height: 28px;
    background: var(--surface-3);
    border: 1px solid var(--border);
    border-radius: 2px;
    cursor: pointer;
    font-size: 1rem;
    color: var(--text);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.15s;
}
.qty-btn:hover:not(:disabled) { background: var(--primary); border-color: var(--primary); color: white; }
.qty-btn:disabled { opacity: 0.3; cursor: not-allowed; }
.cart-item-remove { margin-left: 0.4rem; color: var(--text-muted); }
.cart-item-remove:hover { background: #ef4444; border-color: #ef4444; color: #fff; }
.qty-input {
    flex: 1;
    text-align: center;
    font-weight: 600;
    font-size: 0.9rem;
    font-family: 'IBM Plex Mono', monospace;
    background: transparent;
    border: none;
    color: var(--text);
    outline: none;
    min-width: 0;
}
.details-btn {
    width: 100%;
    padding: 0.6rem;
    background: transparent;
    color: var(--text-muted);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    font-size: 0.82rem;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    letter-spacing: 0.02em;
}
.details-btn:hover { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }

/* ── MODALS ── */
.modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    backdrop-filter: blur(4px);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: 1rem;
}
.modal.active { display: flex; animation: fadeModal 0.2s ease; }
@keyframes fadeModal { from { opacity: 0; } to { opacity: 1; } }
.modal-content {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    width: 100%;
    max-width: 580px;
    max-height: 85vh;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    animation: slideModal 0.25s ease;
}
.modal-large { max-width: 760px; }
.modal-chat { max-width: 480px; max-height: 560px; }
@keyframes slideModal {
    from { transform: translateY(16px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
.modal-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--border);
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    flex-shrink: 0;
}
.modal-header h2 { font-size: 1.05rem; font-weight: 600; }
.close-modal {
    background: transparent;
    border: none;
    font-size: 1.3rem;
    cursor: pointer;
    color: var(--text-muted);
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 2px;
    transition: all 0.15s;
    line-height: 1;
    padding: 0;
}
.close-modal:hover { color: var(--danger); background: rgba(239,68,68,0.1); }

/* Cart */
.cart-items { padding: 1.25rem 1.5rem; overflow-y: auto; flex: 1; }
.cart-item {
    display: flex;
    gap: 0.85rem;
    padding: 0.85rem;
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    margin-bottom: 0.75rem;
    align-items: center;
}
.cart-item-icon { font-size: 2rem; flex-shrink: 0; width: 42px; height: 42px; display: flex; align-items: center; justify-content: center; overflow: hidden; border-radius: var(--radius); }
.cart-item-icon img { width: 100%; height: 100%; object-fit: cover; }
.cart-item-info { flex: 1; min-width: 0; }
.cart-item-name { font-weight: 600; font-size: 0.88rem; margin-bottom: 0.2rem; }
.cart-item-quantity { color: var(--text-muted); font-size: 0.8rem; font-family: 'IBM Plex Mono', monospace; }
.cart-item-controls { display: flex; align-items: center; gap: 0.4rem; }
.empty-cart {
    text-align: center;
    padding: 3rem;
    color: var(--text-muted);
    font-size: 0.9rem;
}
.cart-footer {
    padding: 1.25rem 1.5rem;
    border-top: 1px solid var(--border);
    display: flex;
    gap: 0.75rem;
    flex-shrink: 0;
}
.cart-footer button {
    flex: 1;
    padding: 0.75rem;
    border-radius: var(--radius);
    font-weight: 600;
    cursor: pointer;
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.88rem;
    transition: all 0.2s;
}
.clear-cart-btn {
    background: transparent;
    color: var(--text-muted);
    border: 1px solid var(--border);
}
.clear-cart-btn:hover { border-color: var(--danger); color: var(--danger); background: rgba(239,68,68,0.08); }
.request-btn { background: var(--primary); color: white; border: none; }
.request-btn:hover { background: var(--primary-light); }

/* Details */
.details-content { padding: 1.5rem; overflow-y: auto; flex: 1; }
.details-header { display: flex; gap: 1.5rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
.details-image {
    font-size: 5rem;
    background: var(--surface-2);
    padding: 1.5rem;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}
.details-image img { width: 130px; height: 130px; object-fit: cover; border-radius: var(--radius); }
.details-info { flex: 1; min-width: 200px; }
.details-info h2 { font-size: 1.3rem; margin-bottom: 0.75rem; }
.details-info p { color: var(--text-muted); line-height: 1.7; font-size: 0.88rem; }
.details-specs { margin-top: 1.5rem; }
.details-specs h3 { font-size: 0.85rem; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); margin-bottom: 0.75rem; }
.spec-item {
    display: flex;
    justify-content: space-between;
    padding: 0.65rem 0.75rem;
    background: var(--surface-2);
    border: 1px solid var(--border);
    margin-bottom: 2px;
    font-size: 0.85rem;
}
.spec-item strong { color: var(--text-muted); font-weight: 500; }
.spec-item span { font-family: 'IBM Plex Mono', monospace; font-size: 0.82rem; }

/* Chat */
.chat-messages { padding: 1.25rem; overflow-y: auto; flex: 1; background: var(--bg); }
.chat-message { padding: 0.75rem 1rem; margin-bottom: 0.6rem; border-radius: var(--radius); font-size: 0.85rem; line-height: 1.6; }
.chat-message.system { background: var(--primary-subtle); border: 1px solid rgba(107,31,173,0.2); color: var(--text); }
.chat-message.user { background: var(--surface); border: 1px solid var(--border); margin-left: 15%; }
.chat-message.manager { background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.2); margin-right: 15%; }
.renew-btn {
    margin-top: 12px;
    padding: 9px 14px;
    background: var(--primary);
    color: #ffffff;
    border: 1px solid var(--primary);
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    font-family: 'IBM Plex Sans', sans-serif;
    cursor: pointer;
    transition: 0.2s ease;
}

.renew-btn:hover {
    background: var(--primary-light);
    border-color: var(--primary-light);
    transform: translateY(-1px);
}

.renew-btn:active {
    transform: translateY(0);
}
.chat-input-container {
    padding: 1rem;
    border-top: 1px solid var(--border);
    display: flex;
    gap: 0.5rem;
    flex-shrink: 0;
}
.chat-input-container input {
    flex: 1;
    padding: 0.65rem 0.85rem;
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    color: var(--text);
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.88rem;
    outline: none;
    transition: border-color 0.2s;
}
.chat-input-container input:focus { border-color: var(--primary); }
.chat-input-container button {
    padding: 0.65rem 1.25rem;
    background: var(--primary);
    color: white;
    border: none;
    border-radius: var(--radius);
    cursor: pointer;
    font-weight: 600;
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.85rem;
    transition: background 0.2s;
}
.chat-input-container button:hover { background: var(--primary-light); }

/* Chat list */
.chat-list { padding: 1.25rem; overflow-y: auto; flex: 1; }
.chat-list-item {
    background: var(--surface-2);
    padding: 1rem;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    margin-bottom: 0.6rem;
    cursor: pointer;
    transition: all 0.15s;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.chat-list-item:hover { border-color: var(--primary); background: var(--primary-subtle); }
.chat-list-title { font-weight: 600; font-size: 0.88rem; margin-bottom: 0.25rem; }
.chat-list-preview { color: var(--text-muted); font-size: 0.8rem; }
.chat-status {
    padding: 0.25rem 0.6rem;
    border-radius: 2px;
    font-size: 0.75rem;
    font-weight: 600;
    font-family: 'IBM Plex Mono', monospace;
    text-transform: uppercase;
    letter-spacing: 0.04em;
}
.status-pendente { background: rgba(245,158,11,0.15); color: var(--warning); }
.status-aceito { background: rgba(34,197,94,0.12); color: var(--success); }
.status-recusado { background: rgba(239,68,68,0.12); color: var(--danger); }
.status-finalizado { background: var(--surface-3); color: var(--text-muted); }
.empty-chat-list { text-align: center; padding: 3rem; color: var(--text-muted); font-size: 0.88rem; }
.back-btn {
    background: transparent;
    color: var(--text-muted);
    border: 1px solid var(--border);
    padding: 0.4rem 0.75rem;
    border-radius: var(--radius);
    cursor: pointer;
    font-size: 0.82rem;
    font-family: 'IBM Plex Sans', sans-serif;
    transition: all 0.2s;
}
.back-btn:hover { border-color: var(--primary); color: var(--primary-light); }

/* Edit Profile Modal */
.edit-profile-content { padding: 1.5rem; overflow-y: auto; }
.profile-image-edit { display: flex; flex-direction: column; align-items: center; margin-bottom: 1.75rem; gap: 0.75rem; }
.profile-preview {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: var(--surface-2);
    border: 2px solid var(--primary);
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    color: var(--primary-light);
}
.upload-btn {
    background: transparent;
    border: 1px solid var(--border);
    color: var(--text-muted);
    padding: 0.55rem 1.25rem;
    border-radius: var(--radius);
    cursor: pointer;
    font-size: 0.82rem;
    font-family: 'IBM Plex Sans', sans-serif;
    transition: all 0.2s;
    display: inline-block;
    white-space: nowrap;
}
.upload-btn:hover { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }
.form-group { margin-bottom: 1.25rem; }
.form-group label {
    display: block;
    font-size: 0.78rem;
    font-weight: 500;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin-bottom: 0.45rem;
}
.form-input {
    width: 100%;
    padding: 0.75rem 0.85rem;
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    color: var(--text);
    font-size: 0.9rem;
    font-family: 'IBM Plex Sans', sans-serif;
    outline: none;
    transition: border-color 0.2s;
}
.form-input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(107,31,173,0.12); }
.profile-actions { display: flex; gap: 0.75rem; margin-top: 1.5rem; }
.profile-actions button {
    flex: 1;
    padding: 0.8rem;
    border-radius: var(--radius);
    font-weight: 600;
    cursor: pointer;
    font-family: 'IBM Plex Sans', sans-serif;
    font-size: 0.88rem;
    transition: all 0.2s;
}
.cancel-btn {
    background: transparent;
    color: var(--text-muted);
    border: 1px solid var(--border);
}
.cancel-btn:hover { border-color: var(--danger); color: var(--danger); background: rgba(239,68,68,0.08); }
.save-btn { background: var(--primary); color: white; border: none; }
.save-btn:hover { background: var(--primary-light); }

/* Notification */
.notification-toast {
    position: fixed;
    top: 72px;
    right: 1.25rem;
    background: var(--surface);
    border: 1px solid var(--primary);
    border-left: 3px solid var(--primary);
    color: var(--text);
    padding: 0.75rem 1rem;
    border-radius: var(--radius);
    font-size: 0.85rem;
    font-weight: 500;
    z-index: 9999;
    max-width: 280px;
    animation: toastIn 0.2s ease;
    box-shadow: 0 4px 16px rgba(0,0,0,0.2);
}
.status-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 6px 12px;
    border-radius: 8px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-badge.pendente {
    color: #f59e0b;
    background: rgba(245, 158, 11, 0.12);
    border: 1px solid rgba(245, 158, 11, 0.35);
}

.status-badge.aprovado {
    color: #22c55e;
    background: rgba(34, 197, 94, 0.12);
    border: 1px solid rgba(34, 197, 94, 0.35);
}

.status-badge.recusado {
    color: #ef4444;
    background: rgba(239, 68, 68, 0.12);
    border: 1px solid rgba(239, 68, 68, 0.35);
}

.status-badge.devolvido {
    color: #22c55e;
    background: rgba(34, 197, 94, 0.12);
    border: 1px solid rgba(34, 197, 94, 0.35);
}
.status-badge.retirado {
    color: #22c55e;
    background: rgba(34, 197, 94, 0.12);
    border: 1px solid rgba(34, 197, 94, 0.35);
}

.status-badge.cancelado {
    color: #9ca3af;
    background: rgba(156, 163, 175, 0.12);
    border: 1px solid rgba(156, 163, 175, 0.35);
}
.chat-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding: 18px;
    border: 1px solid var(--border);
    border-radius: 8px;
    background: var(--bg-card);
    cursor: pointer;
    transition: 0.2s ease;
}

.chat-item:hover {
    border-color: var(--primary);
    background: rgba(139, 92, 246, 0.08);
}

.chat-info strong {
    display: block;
    color: var(--text);
    font-size: 15px;
    margin-bottom: 4px;
}

.chat-info p {
    margin: 0;
    color: var(--text-secondary);
    font-size: 13px;
}
.modal-email {

    display:none;

    position:fixed;

    inset:0;

    background:rgba(0,0,0,0.65);

    align-items:center;

    justify-content:center;

    z-index:9999;

}



.modal-email-box {

    background:#131316;

    border:1px solid #6b1fad;

    border-radius:10px;

    padding:30px;

    width:380px;

    text-align:center;

    color:#f0f0f4;

    font-family:'IBM Plex Sans',sans-serif;

}



.modal-email-box h2 {

    color:#ffffff;

    margin-bottom:15px;

}



.modal-email-box p {

    color:#7a7a90;

    margin-bottom:20px;

}



.modal-email-box input {

    width:100%;

    padding:12px;

    background:#1a1a1f;

    border:1px solid #252530;

    color:white;

    border-radius:4px;

    text-align:center;

    font-size:20px;

    letter-spacing:5px;

    margin-bottom:20px;

}



.modal-email-box button {

    padding:10px 20px;

    margin:5px;

    background:#6b1fad;

    color:white;

    border:none;

    border-radius:4px;

    cursor:pointer;

    font-weight:600;

}



.modal-email-box button:hover {

    background:#b662ff;

}

@keyframes toastIn { from { opacity: 0; transform: translateX(10px); } to { opacity: 1; transform: translateX(0); } }

/* Mobile overlay */
.sidebar-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.5);
    z-index: 150;
}
.sidebar-overlay.active { display: block; }

/* Responsive */
@media (max-width: 768px) {
    :root { --sidebar-w: 240px; }
    .sidebar {
        position: fixed;
        left: 0;
        top: var(--header-h);
        height: calc(100vh - var(--header-h));
        z-index: 160;
        transform: translateX(-100%);
        transition: transform 0.3s ease;
        width: var(--sidebar-w) !important;
    }
    .sidebar.mobile-open { transform: translateX(0); }
    .sidebar.collapsed { transform: translateX(-100%); width: var(--sidebar-w) !important; border-right: 1px solid var(--border); }
    .content-area { padding: 1.25rem; }
    .products-grid { grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 0.85rem; }
    .hdr-user-info { display: none; }
    .search-bar { max-width: 200px; }
}
@media (max-width: 480px) {
    .products-grid { grid-template-columns: 1fr; }
    .search-bar { max-width: 140px; }
}

/* ══════════════════════════════════════════════════════════
   CHAT DE EMPRÉSTIMOS — layout estilo WhatsApp Web
   (2ª sidebar com as conversas + painel de chat em tela cheia)
   ══════════════════════════════════════════════════════════ */
body.wa-mode { overflow: hidden; }
.wa-layout {
    display: none; flex: 1; min-width: 0;
    height: calc(100vh - var(--header-h));
    height: calc(100dvh - var(--header-h));
    position: sticky; top: var(--header-h);
    background: var(--bg);
}
.wa-layout.active { display: flex; }

/* ── 2ª sidebar: lista de conversas ── */
.wa-list {
    width: 360px; flex-shrink: 0; min-height: 0;
    display: flex; flex-direction: column;
    background: var(--surface); border-right: 1px solid var(--border);
}
.wa-list-head { padding: 1.1rem 1.1rem 0.8rem; border-bottom: 1px solid var(--border); flex-shrink: 0; }
.wa-list-title {
    display: flex; align-items: center; justify-content: space-between;
    font-size: 1.2rem; font-weight: 600; letter-spacing: -0.01em; margin-bottom: 0.8rem;
}
.wa-live {
    display: inline-flex; align-items: center; gap: 0.4rem;
    font-size: 0.68rem; font-weight: 500; color: var(--text-muted);
    font-family: 'IBM Plex Mono', monospace; letter-spacing: 0.02em;
}
.wa-live i {
    width: 7px; height: 7px; border-radius: 50%; background: var(--success);
    box-shadow: 0 0 0 0 rgba(34,197,94,0.5); animation: waPulse 2s infinite;
}
@keyframes waPulse {
    0% { box-shadow: 0 0 0 0 rgba(34,197,94,0.5); }
    70% { box-shadow: 0 0 0 7px rgba(34,197,94,0); }
    100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); }
}
.wa-search {
    width: 100%; padding: 0.65rem 0.85rem;
    background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--radius);
    color: var(--text); font-size: 0.9rem; font-family: 'IBM Plex Sans', sans-serif; outline: none;
    transition: border-color 0.2s;
}
.wa-search:focus { border-color: var(--primary); }
.wa-search::placeholder { color: var(--text-subtle); }
.wa-filters { display: flex; gap: 0.4rem; margin-top: 0.7rem; flex-wrap: wrap; }
.wa-chip {
    padding: 0.32rem 0.75rem; border-radius: 999px; cursor: pointer;
    background: transparent; border: 1px solid var(--border); color: var(--text-muted);
    font-size: 0.78rem; font-family: 'IBM Plex Sans', sans-serif; font-weight: 500;
    transition: all 0.15s;
}
.wa-chip:hover { border-color: var(--primary); color: var(--text); }
.wa-chip.active { background: var(--primary-subtle); border-color: var(--primary); color: var(--primary-light); }
.wa-list-body { flex: 1; overflow-y: auto; min-height: 0; }
.wa-list-empty { padding: 2.5rem 1.5rem; text-align: center; color: var(--text-muted); font-size: 0.9rem; }

.wa-item {
    display: flex; gap: 0.85rem; align-items: center;
    padding: 0.9rem 1.1rem; cursor: pointer;
    border-bottom: 1px solid var(--border); border-left: 3px solid transparent;
    transition: background 0.15s;
}
.wa-item:hover { background: var(--surface-2); }
.wa-item.active { background: var(--primary-subtle); border-left-color: var(--primary); }
.wa-avatar {
    position: relative; width: 50px; height: 50px; border-radius: 50%; flex-shrink: 0;
    overflow: hidden; display: flex; align-items: center; justify-content: center;
    background: var(--primary-subtle); border: 1px solid var(--border);
    color: var(--primary-light); font-weight: 700; font-size: 1.05rem;
}
.wa-avatar img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
.wa-avatar svg { width: 24px; height: 24px; }
.wa-item-main { flex: 1; min-width: 0; }
.wa-item-top { display: flex; justify-content: space-between; align-items: baseline; gap: 0.5rem; }
.wa-item-name { font-weight: 600; font-size: 0.98rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wa-item-time { font-size: 0.72rem; color: var(--text-subtle); font-family: 'IBM Plex Mono', monospace; flex-shrink: 0; }
.wa-item.unread .wa-item-time { color: var(--primary-light); }
.wa-item-mid { display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; margin-top: 0.25rem; }
.wa-item-preview { font-size: 0.85rem; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; }
.wa-item.unread .wa-item-preview { color: var(--text); font-weight: 500; }
.wa-item-preview.alerta { color: var(--warning); font-weight: 500; }
.wa-item-bot { display: flex; align-items: center; gap: 0.45rem; margin-top: 0.4rem; }
.wa-item-id { font-size: 0.72rem; color: var(--text-subtle); font-family: 'IBM Plex Mono', monospace; }
.wa-unread {
    min-width: 21px; height: 21px; padding: 0 6px; border-radius: 999px; flex-shrink: 0;
    background: var(--primary); color: #fff; font-size: 0.72rem; font-weight: 700;
    font-family: 'IBM Plex Mono', monospace; display: flex; align-items: center; justify-content: center;
}

.wa-status {
    display: inline-block; padding: 0.12rem 0.5rem; border-radius: 2px;
    font-size: 0.68rem; font-weight: 600; letter-spacing: 0.04em; text-transform: uppercase;
    font-family: 'IBM Plex Mono', monospace; white-space: nowrap;
}
.wa-status.st-pendente { background: rgba(245,158,11,0.15); color: var(--warning); }
.wa-status.st-aprovado, .wa-status.st-retirado { background: rgba(34,197,94,0.14); color: var(--success); }
.wa-status.st-devolvido { background: rgba(107,31,173,0.16); color: var(--primary-light); }
.wa-status.st-recusado { background: rgba(239,68,68,0.14); color: var(--danger); }
.wa-status.st-cancelado { background: rgba(156,163,175,0.16); color: #9ca3af; }

/* ── Painel do chat ── */
.wa-chat {
    flex: 1; min-width: 0; min-height: 0; display: flex; flex-direction: column; position: relative;
    background-color: var(--bg);
    background-image: radial-gradient(rgba(182,98,255,0.07) 1px, transparent 1px);
    background-size: 22px 22px;
}
.wa-empty {
    flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
    gap: 0.6rem; padding: 2rem; text-align: center; color: var(--text-muted);
}
.wa-empty svg { width: 64px; height: 64px; opacity: 0.35; margin-bottom: 0.5rem; }
.wa-empty h2 { font-size: 1.25rem; font-weight: 600; color: var(--text); }
.wa-empty p { font-size: 0.92rem; max-width: 340px; line-height: 1.6; }
.wa-conversa { display: none; flex: 1; flex-direction: column; min-height: 0; }

.wa-chat-head {
    display: flex; align-items: center; gap: 0.9rem; flex-shrink: 0;
    padding: 0.75rem 1.25rem; background: var(--surface); border-bottom: 1px solid var(--border);
}
.wa-back {
    display: none; width: 38px; height: 38px; flex-shrink: 0; cursor: pointer;
    align-items: center; justify-content: center; background: transparent;
    border: 1px solid var(--border); border-radius: var(--radius); color: var(--text-muted);
}
.wa-back:hover { border-color: var(--primary); color: var(--primary-light); }
.wa-head-info { flex: 1; min-width: 0; }
.wa-head-name { font-weight: 600; font-size: 1.05rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.wa-head-sub {
    font-size: 0.76rem; color: var(--text-muted); margin-top: 0.15rem;
    font-family: 'IBM Plex Mono', monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.wa-head-actions { display: flex; align-items: center; gap: 0.6rem; flex-shrink: 0; }
.wa-head-btn {
    padding: 0.5rem 0.9rem; background: transparent; border: 1px solid var(--border);
    border-radius: var(--radius); color: var(--text-muted); cursor: pointer;
    font-size: 0.8rem; font-weight: 600; font-family: 'IBM Plex Sans', sans-serif; transition: all 0.15s;
}
.wa-head-btn:hover { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }

.wa-actionbar {
    display: none; align-items: center; justify-content: space-between; gap: 0.75rem 1rem; flex-wrap: wrap;
    padding: 0.7rem 1.25rem; flex-shrink: 0; font-size: 0.86rem; line-height: 1.5;
    background: var(--surface-2); border-bottom: 1px solid var(--border);
}
.wa-actionbar.warn { background: rgba(245,158,11,0.09); }
.wa-act-btns { display: flex; gap: 0.5rem; }
.wa-actionbar button {
    padding: 0.5rem 1.05rem; border: none; border-radius: var(--radius); cursor: pointer;
    font-size: 0.82rem; font-weight: 600; font-family: 'IBM Plex Sans', sans-serif; transition: all 0.15s;
}
.wa-actionbar .primary-btn { background: var(--primary); color: #fff; }
.wa-actionbar .primary-btn:hover { background: var(--primary-light); }

.wa-messages {
    flex: 1; min-height: 0; overflow-y: auto; display: flex; flex-direction: column; gap: 0.3rem;
    padding: 1.25rem clamp(1rem, 7%, 7rem);
}
.wa-day { align-self: center; margin: 0.9rem 0 0.5rem; }
.wa-day span {
    display: inline-block; padding: 0.25rem 0.8rem; border-radius: 999px;
    background: var(--surface); border: 1px solid var(--border);
    font-size: 0.72rem; color: var(--text-muted); font-family: 'IBM Plex Mono', monospace;
}
.wa-msg {
    max-width: min(640px, 78%); padding: 0.5rem 0.8rem 0.3rem; border-radius: 10px;
    font-size: 0.95rem; line-height: 1.5; overflow-wrap: anywhere;
    box-shadow: 0 1px 2px rgba(0,0,0,0.12);
}
.wa-msg.theirs { align-self: flex-start; background: var(--surface); border: 1px solid var(--border); border-top-left-radius: 2px; }
.wa-msg.mine { align-self: flex-end; background: var(--primary); color: #fff; border-top-right-radius: 2px; }
.wa-msg-author { font-size: 0.74rem; font-weight: 600; color: var(--primary-light); margin-bottom: 0.15rem; }
.wa-msg.mine .wa-msg-author { color: rgba(255,255,255,0.75); }
.wa-text { white-space: pre-wrap; }
.wa-msg-time { display: block; text-align: right; margin-top: 0.15rem; font-size: 0.68rem; opacity: 0.6; font-family: 'IBM Plex Mono', monospace; }

.wa-card {
    align-self: center; width: min(580px, 94%); margin: 0.45rem 0;
    padding: 0.9rem 1.1rem; border-radius: 8px; font-size: 0.87rem; line-height: 1.65;
    background: var(--primary-subtle); border: 1px solid rgba(107,31,173,0.28); color: var(--text);
}
.wa-card.warn { background: rgba(245,158,11,0.1); border-color: rgba(245,158,11,0.3); }
.wa-card.ok { background: rgba(34,197,94,0.09); border-color: rgba(34,197,94,0.28); }
.wa-card.bad { background: rgba(239,68,68,0.09); border-color: rgba(239,68,68,0.28); }
.wa-card-title { font-weight: 600; font-size: 0.92rem; margin-bottom: 0.4rem; }
.wa-card .wa-msg-time { margin-top: 0.4rem; }
.wa-card-actions { display: flex; gap: 0.5rem; margin-top: 0.75rem; }
.wa-card-actions button {
    flex: 1; padding: 0.55rem; border: none; border-radius: var(--radius); cursor: pointer;
    font-weight: 600; font-family: 'IBM Plex Sans', sans-serif; font-size: 0.82rem;
}
.wa-notice {
    align-self: center; margin: 0.3rem 0; padding: 0.3rem 0.85rem; border-radius: 999px;
    background: var(--surface); border: 1px solid var(--border);
    font-size: 0.76rem; color: var(--text-muted); text-align: center;
}

.wa-input {
    display: flex; align-items: flex-end; gap: 0.6rem; flex-shrink: 0;
    padding: 0.8rem 1.25rem; background: var(--surface); border-top: 1px solid var(--border);
}
.wa-input textarea {
    flex: 1; resize: none; max-height: 130px; min-height: 46px; padding: 0.8rem 1.1rem;
    background: var(--surface-2); border: 1px solid var(--border); border-radius: 23px;
    color: var(--text); font-size: 0.95rem; line-height: 1.4; font-family: 'IBM Plex Sans', sans-serif;
    outline: none; transition: border-color 0.2s;
}
.wa-input textarea:focus { border-color: var(--primary); }
.wa-input textarea::placeholder { color: var(--text-subtle); }
.wa-send {
    width: 46px; height: 46px; flex-shrink: 0; border: none; border-radius: 50%; cursor: pointer;
    background: var(--primary); color: #fff; display: flex; align-items: center; justify-content: center;
    transition: background 0.2s, transform 0.15s;
}
.wa-send:hover { background: var(--primary-light); transform: scale(1.05); }
.wa-send:disabled { opacity: 0.55; cursor: not-allowed; transform: none; }
.wa-send svg { width: 20px; height: 20px; }
.wa-closed {
    display: none; flex-shrink: 0; padding: 1rem 1.25rem; text-align: center;
    background: var(--surface); border-top: 1px solid var(--border);
    font-size: 0.86rem; color: var(--text-muted);
}

@media (max-width: 860px) {
    .wa-list { width: 100%; border-right: none; }
    .wa-chat { display: none; }
    .wa-layout.chat-active .wa-list { display: none; }
    .wa-layout.chat-active .wa-chat { display: flex; }
    .wa-back { display: flex; }
    .wa-messages { padding: 1rem; }
    .wa-msg { max-width: 88%; }
    .wa-chat-head, .wa-input, .wa-actionbar { padding-left: 0.9rem; padding-right: 0.9rem; }
}

/* ══════════════════════════════════════════════════════════
   MINHA CONTA — painel do usuário (Dados, Pedidos, Notificações,
   Prazos, Doação, Regulamento)
   ══════════════════════════════════════════════════════════ */
.acc-nav {
    width: 250px; flex-shrink: 0; min-height: 0; overflow-y: auto;
    background: var(--surface); border-right: 1px solid var(--border);
    padding: 1.1rem 0.9rem;
}
.acc-nav-title { font-size: 1.15rem; font-weight: 600; padding: 0 0.5rem 1rem; letter-spacing: -0.01em; }
.acc-tab {
    display: flex; align-items: center; gap: 0.8rem; width: 100%;
    padding: 0.75rem 0.9rem; margin-bottom: 0.2rem; border-radius: var(--radius);
    background: transparent; border: none; cursor: pointer; text-align: left;
    color: var(--text-muted); font-size: 0.92rem; font-family: 'IBM Plex Sans', sans-serif;
    transition: all 0.15s; position: relative;
}
.acc-tab svg { width: 19px; height: 19px; flex-shrink: 0; opacity: 0.75; }
.acc-tab:hover { background: var(--surface-2); color: var(--text); }
.acc-tab.active { background: var(--primary-subtle); color: var(--primary-light); font-weight: 600; }
.acc-tab.active svg { opacity: 1; }
.acc-tab .acc-dot {
    position: absolute; right: 0.9rem; width: 8px; height: 8px; border-radius: 50%;
    background: var(--danger); display: none;
}
.acc-tab .acc-dot.show { display: block; }

.acc-content { flex: 1; min-width: 0; overflow-y: auto; padding: 1.75rem clamp(1.25rem, 4%, 3rem); }
.acc-section { display: none; max-width: 880px; }
.acc-section.active { display: block; animation: fadeModal 0.15s ease; }
.acc-head { margin-bottom: 1.5rem; }
.acc-head h2 { font-size: 1.4rem; font-weight: 600; letter-spacing: -0.01em; margin-bottom: 0.3rem; }
.acc-head p { color: var(--text-muted); font-size: 0.9rem; }
.acc-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap; margin-bottom: 1.25rem; }
.acc-selects { display: flex; gap: 0.6rem; flex-wrap: wrap; }
.acc-select {
    padding: 0.55rem 0.8rem; background: var(--surface-2); border: 1px solid var(--border);
    border-radius: var(--radius); color: var(--text); font-size: 0.84rem;
    font-family: 'IBM Plex Sans', sans-serif; cursor: pointer; outline: none;
}
.acc-select:focus { border-color: var(--primary); }
.acc-empty { padding: 2.5rem 1rem; text-align: center; color: var(--text-muted); font-size: 0.92rem; }

/* Dados pessoais */
.acc-profile-photo { display: flex; align-items: center; gap: 1.25rem; margin-bottom: 1.75rem; }
.acc-photo-preview {
    width: 84px; height: 84px; border-radius: 50%; overflow: hidden; flex-shrink: 0;
    background: var(--primary-subtle); border: 2px solid var(--primary);
    display: flex; align-items: center; justify-content: center; font-size: 2rem;
}
.acc-photo-preview img { width: 100%; height: 100%; object-fit: cover; }
.acc-readonly-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
.acc-static { padding: 0.75rem 0.85rem; background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--radius); color: var(--text-muted); font-size: 0.9rem; }

/* Meus pedidos */
.acc-order {
    border: 1px solid var(--border); border-radius: 6px; background: var(--surface);
    margin-bottom: 1rem; overflow: hidden;
}
.acc-order-head { display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; padding: 0.9rem 1.1rem; flex-wrap: wrap; border-bottom: 1px solid var(--border); }
.acc-order-title { font-weight: 600; font-size: 0.98rem; }
.acc-order-date { font-size: 0.78rem; color: var(--text-muted); font-family: 'IBM Plex Mono', monospace; margin-top: 0.15rem; }
.acc-order-body { padding: 0.9rem 1.1rem; }
.acc-order-item { display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; padding: 0.45rem 0; font-size: 0.88rem; border-bottom: 1px dashed var(--border); }
.acc-order-item:last-child { border-bottom: none; }
.acc-order-item-qtd { color: var(--text-muted); font-family: 'IBM Plex Mono', monospace; font-size: 0.8rem; }
.acc-order-foot { display: flex; align-items: center; justify-content: flex-end; gap: 0.6rem; padding: 0.8rem 1.1rem; border-top: 1px solid var(--border); background: var(--surface-2); flex-wrap: wrap; }
.acc-btn {
    padding: 0.5rem 1rem; border-radius: var(--radius); cursor: pointer; font-weight: 600;
    font-family: 'IBM Plex Sans', sans-serif; font-size: 0.82rem; transition: all 0.15s; border: 1px solid var(--border);
    background: transparent; color: var(--text-muted);
}
.acc-btn:hover:not(:disabled) { border-color: var(--primary); color: var(--primary-light); background: var(--primary-subtle); }
.acc-btn.solid { background: var(--primary); color: #fff; border-color: var(--primary); }
.acc-btn.solid:hover:not(:disabled) { background: var(--primary-light); color: #fff; }
.acc-btn:disabled { opacity: 0.45; cursor: not-allowed; }
.acc-btn-mini { padding: 0.3rem 0.6rem; font-size: 0.72rem; }

/* Notificações */
.acc-notif { display: flex; gap: 0.85rem; align-items: flex-start; padding: 0.95rem 0; border-bottom: 1px solid var(--border); cursor: pointer; }
.acc-notif:last-child { border-bottom: none; }
.acc-notif:hover { background: var(--surface-2); margin: 0 -0.75rem; padding-left: 0.75rem; padding-right: 0.75rem; border-radius: var(--radius); }
.acc-notif-icon { width: 38px; height: 38px; border-radius: 50%; flex-shrink: 0; display: flex; align-items: center; justify-content: center; background: var(--primary-subtle); color: var(--primary-light); }
.acc-notif-icon svg { width: 18px; height: 18px; }
.acc-notif.tipo-sucesso .acc-notif-icon { background: rgba(34,197,94,0.13); color: var(--success); }
.acc-notif.tipo-alerta .acc-notif-icon { background: rgba(245,158,11,0.14); color: var(--warning); }
.acc-notif.tipo-erro .acc-notif-icon { background: rgba(239,68,68,0.12); color: var(--danger); }
.acc-notif-main { flex: 1; min-width: 0; }
.acc-notif-top { display: flex; justify-content: space-between; gap: 0.6rem; }
.acc-notif-title { font-weight: 600; font-size: 0.92rem; }
.acc-notif.unread .acc-notif-title::before { content: ''; display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: var(--primary); margin-right: 0.4rem; }
.acc-notif-time { font-size: 0.74rem; color: var(--text-subtle); font-family: 'IBM Plex Mono', monospace; white-space: nowrap; }
.acc-notif-msg { font-size: 0.86rem; color: var(--text-muted); margin-top: 0.2rem; line-height: 1.5; }

/* Prazos / calendário */
.acc-cal-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
.acc-cal-nav { display: flex; align-items: center; gap: 0.6rem; }
.acc-cal-nav button {
    width: 34px; height: 34px; border-radius: var(--radius); border: 1px solid var(--border); background: transparent;
    color: var(--text-muted); cursor: pointer; display: flex; align-items: center; justify-content: center;
}
.acc-cal-nav button:hover { border-color: var(--primary); color: var(--primary-light); }
.acc-cal-month { font-weight: 600; font-size: 1.05rem; min-width: 170px; text-align: center; text-transform: capitalize; }
.acc-cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 0.35rem; }
.acc-cal-dow { text-align: center; font-size: 0.72rem; color: var(--text-subtle); font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; padding-bottom: 0.4rem; }
.acc-cal-day {
    aspect-ratio: 1; border-radius: 6px; border: 1px solid var(--border); background: var(--surface);
    display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.2rem;
    font-size: 0.85rem; color: var(--text); position: relative;
}
.acc-cal-day.outro-mes { opacity: 0.3; }
.acc-cal-day.hoje { border-color: var(--primary); border-width: 2px; font-weight: 700; color: var(--primary-light); }
.acc-cal-day.feriado { background: rgba(239,68,68,0.09); }
.acc-cal-day.ferias { background: rgba(245,158,11,0.1); }
.acc-cal-day.devolucao { background: rgba(107,31,173,0.12); }
.acc-cal-day.importante { background: rgba(107,31,173,0.07); }
.acc-cal-dots { display: flex; gap: 3px; }
.acc-cal-dots span { width: 5px; height: 5px; border-radius: 50%; }
.acc-cal-legend { display: flex; gap: 1.1rem; flex-wrap: wrap; margin-top: 1.1rem; font-size: 0.8rem; color: var(--text-muted); }
.acc-cal-legend span { display: inline-flex; align-items: center; gap: 0.4rem; }
.acc-cal-legend i { width: 11px; height: 11px; border-radius: 3px; display: inline-block; }
.acc-cal-list { margin-top: 1.5rem; }
.acc-cal-item { display: flex; align-items: center; gap: 0.75rem; padding: 0.7rem 0; border-bottom: 1px solid var(--border); font-size: 0.88rem; }
.acc-cal-item:last-child { border-bottom: none; }
.acc-cal-item i { width: 10px; height: 10px; border-radius: 3px; flex-shrink: 0; }
.acc-cal-item-date { font-family: 'IBM Plex Mono', monospace; color: var(--text-muted); font-size: 0.78rem; min-width: 88px; }

/* Doação */
.acc-donation-form { border: 1px solid var(--border); border-radius: 6px; padding: 1.25rem; background: var(--surface); margin-bottom: 2rem; }
.acc-photo-upload {
    width: 100%; min-height: 180px; border: 2px dashed var(--border); border-radius: 6px;
    display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.6rem;
    cursor: pointer; color: var(--text-muted); font-size: 0.85rem; margin-bottom: 1.25rem; overflow: hidden;
    background: var(--surface-2); position: relative; text-align: center; padding: 1rem;
}
.acc-photo-upload:hover { border-color: var(--primary); color: var(--primary-light); }
.acc-photo-upload img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
.acc-photo-upload svg { width: 32px; height: 32px; opacity: 0.6; }
.acc-toggle-row { display: flex; align-items: center; justify-content: space-between; padding: 0.85rem 0; border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); margin-bottom: 1.25rem; }
.acc-toggle-label { font-size: 0.9rem; }
.acc-toggle-label small { display: block; color: var(--text-muted); font-size: 0.78rem; margin-top: 0.15rem; }
.acc-switch { position: relative; width: 44px; height: 24px; flex-shrink: 0; }
.acc-switch input { opacity: 0; width: 0; height: 0; }
.acc-switch-track { position: absolute; inset: 0; background: var(--border); border-radius: 999px; cursor: pointer; transition: background 0.2s; }
.acc-switch-track::before { content: ''; position: absolute; width: 18px; height: 18px; left: 3px; top: 3px; background: #fff; border-radius: 50%; transition: transform 0.2s; }
.acc-switch input:checked + .acc-switch-track { background: var(--danger); }
.acc-switch input:checked + .acc-switch-track::before { transform: translateX(20px); }
.acc-donation-hist { border: 1px solid var(--border); border-radius: 6px; overflow: hidden; }
.acc-donation-item { display: flex; gap: 0.9rem; padding: 0.9rem 1.1rem; border-bottom: 1px solid var(--border); align-items: center; }
.acc-donation-item:last-child { border-bottom: none; }
.acc-donation-thumb { width: 56px; height: 56px; border-radius: var(--radius); object-fit: cover; flex-shrink: 0; background: var(--surface-2); border: 1px solid var(--border); }
.acc-donation-main { flex: 1; min-width: 0; }
.acc-donation-desc { font-size: 0.88rem; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
.acc-donation-meta { font-size: 0.76rem; color: var(--text-muted); margin-top: 0.3rem; font-family: 'IBM Plex Mono', monospace; }

/* Regulamento */
.acc-reg { line-height: 1.85; font-size: 0.94rem; color: var(--text); }
.acc-reg h3 { font-size: 1.02rem; margin: 1.4rem 0 0.5rem; color: var(--primary-light); }
.acc-reg h3:first-child { margin-top: 0; }
.acc-reg ol, .acc-reg ul { padding-left: 1.4rem; margin-bottom: 0.5rem; }
.acc-reg li { margin-bottom: 0.35rem; }
.acc-reg p { margin-bottom: 0.5rem; color: var(--text-muted); }

@media (max-width: 860px) {
    #accountLayout { flex-direction: column; }
    .acc-nav {
        width: 100%; display: flex; gap: 0.4rem; padding: 0.7rem 0.9rem;
        overflow-x: auto; overflow-y: hidden; border-right: none; border-bottom: 1px solid var(--border);
        flex-shrink: 0;
    }
    .acc-nav-title { display: none; }
    .acc-tab { flex-direction: column; gap: 0.3rem; padding: 0.55rem 0.8rem; white-space: nowrap; margin-bottom: 0; font-size: 0.74rem; }
    .acc-tab .acc-dot { top: 0.4rem; right: 0.5rem; }
    .acc-content { padding: 1.25rem 1rem; }
    .acc-readonly-row { grid-template-columns: 1fr; }
}
    </style>
</head>
<body>
    <!-- HEADER -->
    <header class="header">
        <button class="sidebar-toggle" id="sidebarToggle" title="Menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <img class="logo-img" src="img/logo_stoktech.png" alt="StokTech">
        <div class="search-bar">
            <span class="search-icon">&#9906;</span>
            <input type="text" id="searchInput" placeholder="Buscar componentes...">
        </div>
        <div class="header-actions">
            <?php if ($modoConvidado): ?>
            <span class="hdr-btn" style="width:auto; padding:0 0.75rem; font-size:0.78rem; color:var(--text-muted); cursor:default;">Modo visitante</span>
            <button class="hdr-btn" id="themeToggle" title="Alternar tema">&#9790;</button>
            <a class="hdr-btn" href="index.php" title="Fazer login" style="width:auto; padding:0 0.9rem; text-decoration:none; font-size:0.82rem; font-weight:600; color:var(--primary-light);">Entrar</a>
            <?php else: ?>
            <?php if (($_SESSION['tipo'] ?? '') === 'ADMINISTRADOR'): ?>
            <a class="hdr-btn" href="stoktech_admin.php" title="Voltar para visão de administrador" style="text-decoration:none; display:flex; align-items:center; justify-content:center;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 3 7v6c0 5 3.8 8.7 9 9 5.2-.3 9-4 9-9V7l-9-5Z"/><path d="M9.5 12.5 11 14l3.5-3.5"/></svg>
            </a>
            <?php endif; ?>
            <button class="hdr-btn" id="themeToggle" title="Alternar tema">&#9790;</button>
            <button class="hdr-btn" id="chatBtn" title="Meus empréstimos (chat)">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                <span class="cart-badge" id="chatBadgeUser" style="display:none;">0</span>
            </button>
            <button class="hdr-btn" id="cartBtn" title="Carrinho">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                <span class="cart-badge" id="cartCount">0</span>
            </button>
            <div class="hdr-user" id="hdrUser" title="Minha conta">
                <div class="hdr-avatar" id="headerAvatar">&#9751;</div>
                <div class="hdr-user-info">
                    <span class="hdr-user-name" id="headerUserName">Usuário</span>
                    <span class="hdr-user-email" id="headerUserEmail"><?= htmlspecialchars($_SESSION['email'] ?? '') ?></span>
                </div>
                <span class="edit-pencil">&#9998;</span>
            </div>
            <form class="logout-form" action="sairdacontasuperlegal.php" method="post">
                <button class="hdr-btn" title="Sair">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                </button>
            </form>
            <?php endif; ?>
        </div>
    </header>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="main-container">
        <!-- SIDEBAR -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-inner">
                <div class="sidebar-section-label">Categorias</div>
                <ul class="category-list">
                    <li class="category-item active" data-category="todos">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="7" height="7"></rect><rect x="15" y="3" width="7" height="7"></rect><rect x="2" y="14" width="7" height="7"></rect><rect x="15" y="14" width="7" height="7"></rect></svg>
                        Todos os Itens
                    </li>
                    <?php foreach ($categoriasAluno as $cat): ?>
                        <li class="category-item" data-category="<?= htmlspecialchars((string)$cat['IDCATEGORIA']) ?>">
                            <span style="width:20px;height:20px;display:flex;align-items:center;justify-content:center;opacity:0.85;font-size:1.15rem;">
                                <?= htmlspecialchars($cat['ICONE'] ?: '📦') ?>
                            </span>
                            <?= htmlspecialchars($cat['NOME'] ?? 'Categoria') ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="content-area">
            <div class="section-header">
                <h2 class="section-title">Componentes</h2>
                <span class="section-count" id="productCount">0 itens</span>
            </div>
            <div class="products-grid" id="productsGrid"></div>
        </main>

        <!-- CHAT DE EMPRÉSTIMOS: 2ª sidebar (meus empréstimos) + chat em tela cheia, estilo WhatsApp Web -->
        <div class="wa-layout" id="waLayout">
            <aside class="wa-list">
                <div class="wa-list-head" style="padding-bottom:1rem;">
                    <div class="wa-list-title" style="margin-bottom:0;">
                        <span>Meus empréstimos</span>
                        <span class="wa-live" title="Esta lista atualiza sozinha"><i></i>ao vivo</span>
                    </div>
                </div>
                <div class="wa-list-body" id="waListBody"></div>
            </aside>

            <section class="wa-chat">
                <div class="wa-empty" id="waEmpty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                    <h2>Seus empréstimos</h2>
                    <p>Escolha um empréstimo na lista ao lado para conversar com o gerenciador do laboratório.</p>
                </div>

                <div class="wa-conversa" id="waConversa">
                    <div class="wa-chat-head">
                        <button type="button" class="wa-back" id="waBack" title="Voltar para a lista">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                        </button>
                        <div class="wa-avatar" id="waHeadAvatar"></div>
                        <div class="wa-head-info">
                            <div class="wa-head-name">Gerenciador do laboratório</div>
                            <div class="wa-head-sub" id="waHeadSub"></div>
                        </div>
                        <div class="wa-head-actions"><span id="waHeadStatus"></span></div>
                    </div>
                    <div class="wa-actionbar" id="waActionBar"></div>
                    <div class="wa-messages" id="waMessages"></div>
                    <div class="wa-input" id="waInputArea">
                        <textarea id="waInput" rows="1" placeholder="Digite uma mensagem"></textarea>
                        <button type="button" class="wa-send" id="waSend" title="Enviar">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                        </button>
                    </div>
                    <div class="wa-closed" id="waClosed"></div>
                </div>
            </section>
        </div>

        <!-- MINHA CONTA: Dados Pessoais, Meus Pedidos, Notificações, Prazos, Doação, Regulamento -->
        <div class="wa-layout" id="accountLayout">
            <aside class="acc-nav">
                <div class="acc-nav-title" style="display:flex;align-items:center;justify-content:space-between;">
                    Minha conta
                    <button type="button" onclick="fecharConta()" title="Voltar" style="background:transparent;border:1px solid var(--border);border-radius:var(--radius);width:30px;height:30px;color:var(--text-muted);cursor:pointer;display:flex;align-items:center;justify-content:center;">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                    </button>
                </div>
                <button type="button" class="acc-tab active" data-aba="dados">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    Dados Pessoais
                </button>
                <button type="button" class="acc-tab" data-aba="pedidos">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8l-9-5-9 5 9 5 9-5Z"></path><path d="M3 8v8l9 5 9-5V8"></path><path d="M12 13v8"></path></svg>
                    Meus Pedidos
                </button>
                <button type="button" class="acc-tab" data-aba="notificacoes">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                    Notificações
                    <span class="acc-dot" id="accDotNotif"></span>
                </button>
                <button type="button" class="acc-tab" data-aba="prazos">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"></rect><path d="M16 2v4M8 2v4M3 10h18"></path></svg>
                    Prazos
                </button>
                <button type="button" class="acc-tab" data-aba="doacao">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12v9H4v-9"></path><path d="M2 7h20v5H2z"></path><path d="M12 22V7"></path><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7Z"></path><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7Z"></path></svg>
                    Propor Doação
                </button>
                <button type="button" class="acc-tab" data-aba="regulamento">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"></path><path d="M14 2v6h6"></path><path d="M9 13h6M9 17h6M9 9h1"></path></svg>
                    Regulamento
                </button>
            </aside>

            <div class="acc-content">
                <!-- DADOS PESSOAIS -->
                <section class="acc-section active" id="accDados">
                    <div class="acc-head"><h2>Dados pessoais</h2><p>Suas informações de cadastro no StokTech.</p></div>

                    <div class="acc-profile-photo">
                        <div class="acc-photo-preview" id="profilePreview">&#9751;</div>
                        <div>
                            <label for="profileImageInput" class="upload-btn" style="cursor:pointer;">Alterar foto</label>
                            <input type="file" id="profileImageInput" accept="image/*" style="display:none;">
                        </div>
                    </div>

                    <div class="acc-readonly-row" style="margin-bottom:1.25rem;">
                        <div class="form-group" style="margin-bottom:0;">
                            <label>CPF</label>
                            <div class="acc-static" id="accCpf">—</div>
                        </div>
                        <div class="form-group" style="margin-bottom:0;">
                            <label>Tipo de conta</label>
                            <div class="acc-static" id="accTipo">Aluno</div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Nome</label>
                        <input type="text" id="editName" class="form-input" placeholder="Seu nome">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="editEmail" class="form-input" placeholder="seu@email.com" value="<?= htmlspecialchars($_SESSION['email'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>Nova senha (deixe em branco para manter)</label>
                        <input type="password" id="editPassword" class="form-input" placeholder="••••••••">
                    </div>
                    <div class="form-group">
                        <label>Confirmar nova senha</label>
                        <input type="password" id="confirmPassword" class="form-input" placeholder="••••••••">
                    </div>
                    <div class="profile-actions" style="max-width:420px;">
                        <button class="cancel-btn" id="cancelEditAcc">Desfazer alterações</button>
                        <button class="save-btn" id="saveProfile">Salvar alterações</button>
                    </div>
                </section>

                <!-- MEUS PEDIDOS -->
                <section class="acc-section" id="accPedidos">
                    <div class="acc-head"><h2>Meus pedidos</h2><p>Histórico de todos os empréstimos que você solicitou.</p></div>
                    <div class="acc-toolbar">
                        <div class="acc-selects">
                            <select class="acc-select" id="accPedidosFiltro">
                                <option value="todos">Todos os pedidos</option>
                                <option value="ativo">Pedido ativo</option>
                                <option value="devolvido">Pedido devolvido</option>
                                <option value="negado">Pedido negado</option>
                            </select>
                            <select class="acc-select" id="accPedidosOrdem">
                                <option value="recentes">Mais recente</option>
                                <option value="antigas">Menos recente</option>
                            </select>
                        </div>
                    </div>
                    <div id="accPedidosLista"><div class="acc-empty">Carregando...</div></div>
                </section>

                <!-- NOTIFICAÇÕES -->
                <section class="acc-section" id="accNotificacoes">
                    <div class="acc-head"><h2>Notificações</h2><p>Avisos sobre seus pedidos, renovações e prazos.</p></div>
                    <div class="acc-toolbar">
                        <div class="acc-selects">
                            <select class="acc-select" id="accNotifOrdem">
                                <option value="recentes">Mais recente</option>
                                <option value="antigas">Menos recente</option>
                            </select>
                        </div>
                        <button type="button" class="acc-btn" id="accNotifMarcarTodas">Marcar todas como lidas</button>
                    </div>
                    <div id="accNotifLista"><div class="acc-empty">Carregando...</div></div>
                </section>

                <!-- PRAZOS / CALENDÁRIO -->
                <section class="acc-section" id="accPrazos">
                    <div class="acc-head"><h2>Prazos</h2><p>Hoje, feriados, férias e as datas de devolução dos seus empréstimos.</p></div>
                    <div class="acc-cal-head">
                        <div class="acc-cal-month" id="accCalMes"></div>
                        <div class="acc-cal-nav">
                            <button type="button" id="accCalPrev" title="Mês anterior">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
                            </button>
                            <button type="button" id="accCalHoje" title="Ir para hoje" style="width:auto;padding:0 0.8rem;font-size:0.78rem;">Hoje</button>
                            <button type="button" id="accCalNext" title="Próximo mês">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
                            </button>
                        </div>
                    </div>
                    <div class="acc-cal-grid" id="accCalGrid"></div>
                    <div class="acc-cal-legend">
                        <span><i style="border:2px solid var(--primary);background:transparent;"></i>Hoje</span>
                        <span><i style="background:rgba(107,31,173,0.5);"></i>Devolução</span>
                        <span><i style="background:rgba(239,68,68,0.55);"></i>Feriado</span>
                        <span><i style="background:rgba(245,158,11,0.55);"></i>Férias</span>
                        <span><i style="background:rgba(107,31,173,0.3);"></i>Data importante</span>
                    </div>
                    <div class="acc-cal-list" id="accCalLista"></div>
                </section>

                <!-- PROPOR DOAÇÃO -->
                <section class="acc-section" id="accDoacao">
                    <div class="acc-head"><h2>Propor doação</h2><p>Tem componentes ou dispositivos em casa? Ofereça para o laboratório.</p></div>

                    <div class="acc-donation-form">
                        <label class="acc-photo-upload" id="accDoacaoFotoLabel">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2Z"></path><circle cx="12" cy="13" r="4"></circle></svg>
                            <span id="accDoacaoFotoTexto">Toque para tirar uma foto ou escolher da galeria</span>
                            <input type="file" id="accDoacaoFoto" accept="image/*" capture="environment" style="display:none;">
                        </label>

                        <div class="form-group">
                            <label>Descrição do componente</label>
                            <textarea id="accDoacaoDescricao" class="form-input" rows="3" placeholder="Ex.: Arduino Uno R3, funcionando, sem a caixa original..."></textarea>
                        </div>

                        <div class="acc-toggle-row">
                            <div class="acc-toggle-label">
                                Está danificado?
                                <small>Marque se o componente apresenta algum defeito ou avaria.</small>
                            </div>
                            <label class="acc-switch">
                                <input type="checkbox" id="accDoacaoDanificado">
                                <span class="acc-switch-track"></span>
                            </label>
                        </div>

                        <button type="button" class="save-btn" id="accDoacaoEnviar" style="width:100%;">Enviar proposta de doação</button>
                    </div>

                    <h3 style="font-size:1.02rem;font-weight:600;margin-bottom:0.8rem;">Histórico de doações</h3>
                    <div class="acc-donation-hist" id="accDoacoesLista"><div class="acc-empty">Carregando...</div></div>
                </section>

                <!-- REGULAMENTO -->
                <section class="acc-section" id="accRegulamento">
                    <div class="acc-head"><h2>Regulamento</h2><p>Regras de uso do laboratório de hardware.</p></div>
                    <div class="acc-reg">
                        <h3>1. Do empréstimo de componentes</h3>
                        <p>O empréstimo de componentes e dispositivos do laboratório é destinado exclusivamente a alunos e professores regularmente cadastrados no sistema StokTech.</p>
                        <ol>
                            <li>Cada solicitação de empréstimo deve ser feita pelo próprio sistema, informando os componentes e as quantidades desejadas.</li>
                            <li>O pedido fica com status <strong>Pendente</strong> até ser analisado pelo gerenciador do laboratório.</li>
                            <li>Após a aprovação, o aluno tem um prazo limite para retirar os itens presencialmente no laboratório.</li>
                            <li>Pedidos aprovados e não retirados dentro do prazo são cancelados automaticamente.</li>
                        </ol>

                        <h3>2. Da devolução</h3>
                        <ol>
                            <li>Os componentes devem ser devolvidos até a data de prazo informada no momento da retirada.</li>
                            <li>É possível solicitar a renovação do prazo antes do vencimento, pelo chat do empréstimo, desde que a nova data seja aprovada pelo gerenciador.</li>
                            <li>Ao devolver os itens, o gerenciador registra se houve algum dano, sua gravidade e um laudo descritivo.</li>
                            <li>Danos causados por mau uso poderão ser cobrados do aluno responsável, conforme avaliação da coordenação.</li>
                        </ol>

                        <h3>3. Da comunicação</h3>
                        <p>Toda comunicação referente a um empréstimo específico deve ser feita pelo chat daquele pedido, disponível no ícone de mensagens do cabeçalho. Isso garante o registro de todo o histórico da solicitação.</p>

                        <h3>4. Das doações</h3>
                        <p>Alunos podem propor a doação de componentes ou dispositivos próprios para o laboratório, pela aba "Propor Doação". Cada proposta deve conter uma foto real do item, uma descrição e a indicação de eventuais danos. A doação só é efetivada após a análise e aceite do gerenciador.</p>

                        <h3>5. Disposições gerais</h3>
                        <ol>
                            <li>O uso do sistema implica na aceitação integral deste regulamento.</li>
                            <li>Casos omissos serão resolvidos pela coordenação do laboratório.</li>
                            <li>Este regulamento pode ser atualizado a qualquer momento; a versão vigente é sempre a exibida nesta página.</li>
                        </ol>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <!-- CART MODAL -->
    <div class="modal" id="cartModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Carrinho de Empréstimo</h2>
                <button class="close-modal" id="closeCart">&times;</button>
            </div>
            <div class="cart-items" id="cartItems"></div>
            <div class="cart-footer">
                <button class="clear-cart-btn" id="clearCart">Limpar</button>
                <button class="request-btn" id="requestItems">Solicitar Empréstimo</button>
            </div>
        </div>
    </div>

    <!-- DETAILS MODAL -->
    <div class="modal" id="detailsModal">
        <div class="modal-content modal-large">
            <div class="modal-header">
                <h2>Detalhes do Componente</h2>
                <button class="close-modal" id="closeDetails">&times;</button>
            </div>
            <div class="details-content" id="detailsContent"></div>
        </div>
    </div>

<script>
const products = <?= json_encode($produtosAluno, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

let cart = [];
let currentCategory = 'todos';
let productQuantities = {};
let currentChatId = null;
let userProfile = {
    name: <?= json_encode($_SESSION['nome'] ?? 'Usuário') ?>,
    email: <?= json_encode($_SESSION['email'] ?? '') ?>,
    profileImage: <?= json_encode($_SESSION['foto_perfil'] ?? null) ?>
};
const CART_STORAGE_KEY = 'stokCart_' + <?= json_encode($_SESSION['idusuario'] ?? 0) ?>;
const MODO_CONVIDADO = <?= json_encode($modoConvidado) ?>;
products.forEach(p => productQuantities[p.id] = 0);

// ── INIT ──
document.addEventListener('DOMContentLoaded', () => {
    loadTheme();
    updateProfileDisplay();
    loadCart();
    renderProducts();
    setupEventListeners();
});

function setupEventListeners() {
    document.getElementById('sidebarToggle').addEventListener('click', toggleSidebar);
    document.getElementById('sidebarOverlay').addEventListener('click', closeSidebarMobile);
    document.getElementById('themeToggle').addEventListener('click', toggleTheme);
    document.querySelectorAll('.category-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('.category-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            voltarAoCatalogo();
            currentCategory = this.dataset.category;
            renderProducts();
            if (window.innerWidth <= 768) closeSidebarMobile();
        });
    });
    document.getElementById('cartBtn')?.addEventListener('click', openCart);
    document.getElementById('closeCart').addEventListener('click', closeCart);
    document.getElementById('clearCart').addEventListener('click', clearCart);
    document.getElementById('requestItems').addEventListener('click', requestItems);
    document.getElementById('chatBtn')?.addEventListener('click', alternarChatView);
    waConfigurar();
    accConfigurar();
    document.getElementById('saveProfile').addEventListener('click', saveProfile);
    document.getElementById('profileImageInput').addEventListener('change', handleProfileImageUpload);
    document.getElementById('closeDetails').addEventListener('click', closeDetails);
    document.getElementById('searchInput').addEventListener('input', e => { voltarAoCatalogo(); filterProducts(e.target.value); });
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) { if(e.target === this) this.classList.remove('active'); });
    });

    // Trava o scroll da página de fundo enquanto qualquer painel/modal estiver aberto
    const observadorModais = new MutationObserver(function () {
        const algumAberto = !!document.querySelector('.modal.active');
        document.body.classList.toggle('stoktech-sem-scroll', algumAberto);
    });
    document.querySelectorAll('.modal').forEach(modal => {
        observadorModais.observe(modal, { attributes: true, attributeFilter: ['class'] });
    });

    // Impede que o scroll do mouse sobre a sidebar role a página
    const sidebarEl = document.getElementById('sidebar');
    if (sidebarEl) {
        // só bloqueia se a lista de categorias couber inteira (senão ela precisa rolar)
        const cabeTudo = () => sidebarEl.scrollHeight <= sidebarEl.clientHeight;
        sidebarEl.addEventListener('wheel', function (e) { if (cabeTudo()) e.preventDefault(); }, { passive: false });
        sidebarEl.addEventListener('touchmove', function (e) { if (cabeTudo()) e.preventDefault(); }, { passive: false });
    }
}

// ── SIDEBAR ──
function toggleSidebar() {
    if (window.innerWidth <= 768) {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        sidebar.classList.toggle('mobile-open');
        overlay.classList.toggle('active');
    } else {
        document.getElementById('sidebar').classList.toggle('collapsed');
    }
}
function closeSidebarMobile() {
    document.getElementById('sidebar').classList.remove('mobile-open');
    document.getElementById('sidebarOverlay').classList.remove('active');
}

// ── THEME ──
function loadTheme() {
    const t = localStorage.getItem('theme');
    if (t === 'light') {
        document.body.classList.add('light-mode');
        document.getElementById('themeToggle').innerHTML = '&#9728;';
    }
}
function toggleTheme() {
    document.body.classList.toggle('light-mode');
    const isLight = document.body.classList.contains('light-mode');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
    document.getElementById('themeToggle').innerHTML = isLight ? '&#9728;' : '&#9790;';
}

// ── PRODUCTS ──
// ══════════════════════════════════════════════════════
// MINHA CONTA — Dados Pessoais, Meus Pedidos, Notificações,
// Prazos, Propor Doação, Regulamento
// ══════════════════════════════════════════════════════
const DADOS_PESSOAIS = <?= json_encode($dadosPessoaisAluno, JSON_UNESCAPED_UNICODE) ?>;
let contaAberta = false;
let abaAtual = 'dados';
let telaAntesDoPerfil = null;
let notificacoes = [];
let notifOrdem = 'recentes';
let pedidosFiltro = 'todos';
let pedidosOrdem = 'recentes';
let doacoes = [];
let doacaoConfigurada = false;
let accCalRef = new Date();
let eventosCalendario = null;

// Única fonte de verdade pra visibilidade da sidebar de categorias:
// ela some SÓ enquanto "Minha conta" (accountLayout) está aberta.
// Chamada sempre que qualquer tela muda, pra nunca ficar "presa" escondida.
function atualizarVisibilidadeSidebarPrincipal() {
    const sidebarEl = document.getElementById('sidebar');
    if (sidebarEl) sidebarEl.style.display = contaAberta ? 'none' : '';
}
function mostrarTelaConta(sim) {
    contaAberta = sim;
    if (sim) { waChatAberto = false; document.getElementById('waLayout')?.classList.remove('active'); }
    document.querySelector('.content-area').style.display = sim ? 'none' : '';
    document.getElementById('accountLayout').classList.toggle('active', sim);
    document.body.classList.toggle('wa-mode', sim);
    atualizarVisibilidadeSidebarPrincipal();
}
// Clicar de novo no botão de perfil deve voltar exatamente para onde o
// usuário estava (catálogo ou a conversa de chat que estava aberta).
function abrirConta(aba) {
    if (MODO_CONVIDADO) return;
    if (contaAberta) { fecharConta(); return; }
    telaAntesDoPerfil = waChatAberto ? { tipo: 'chat', id: currentChatId } : { tipo: 'catalogo' };
    closeSidebarMobile();
    mostrarTelaConta(true);
    alternarAba(aba || abaAtual);
}
function fecharConta() {
    if (!contaAberta) return;
    mostrarTelaConta(false);
    const anterior = telaAntesDoPerfil;
    telaAntesDoPerfil = null;
    if (anterior && anterior.tipo === 'chat') abrirChatView(anterior.id);
}
// Usado quando o usuário navega deliberadamente para o catálogo
// (clicou numa categoria ou digitou na busca) — fecha tudo sem
// tentar reabrir o que estava aberto antes.
function voltarAoCatalogo() {
    waChatAberto = false; contaAberta = false; telaAntesDoPerfil = null;
    document.getElementById('waLayout')?.classList.remove('active');
    document.getElementById('accountLayout')?.classList.remove('active');
    document.querySelector('.content-area').style.display = '';
    document.body.classList.remove('wa-mode');
    atualizarVisibilidadeSidebarPrincipal();
}
function alternarAba(aba) {
    abaAtual = aba;
    document.querySelectorAll('.acc-tab').forEach(t => t.classList.toggle('active', t.dataset.aba === aba));
    document.querySelectorAll('.acc-section').forEach(s => s.classList.remove('active'));
    const mapa = { dados: 'accDados', pedidos: 'accPedidos', notificacoes: 'accNotificacoes', prazos: 'accPrazos', doacao: 'accDoacao', regulamento: 'accRegulamento' };
    document.getElementById(mapa[aba])?.classList.add('active');

    if (aba === 'dados') carregarCamposPerfil();
    else if (aba === 'pedidos') carregarAbaPedidos();
    else if (aba === 'notificacoes') carregarAbaNotificacoes();
    else if (aba === 'prazos') carregarAbaPrazos();
    else if (aba === 'doacao') carregarAbaDoacao();
}

// wa/chat já sincroniza meusEmprestimos, mas garantimos ao menos uma carga
// aqui também, para o caso de o usuário abrir "Minha conta" antes do chat.
async function garantirMeusEmprestimos() {
    if (typeof meusEmprestimos !== 'undefined' && meusEmprestimos.length) return meusEmprestimos;
    try { return await carregarMeusEmprestimos(); } catch (e) { return []; }
}

// ── DADOS PESSOAIS ──
function carregarCamposPerfil() {
    document.getElementById('editName').value = userProfile.name;
    document.getElementById('editEmail').value = userProfile.email;
    document.getElementById('editPassword').value = '';
    document.getElementById('confirmPassword').value = '';
    document.getElementById('accCpf').textContent = DADOS_PESSOAIS.cpf ? formatarCpf(DADOS_PESSOAIS.cpf) : '—';
    document.getElementById('accTipo').textContent = DADOS_PESSOAIS.tipo === 'ADMINISTRADOR' ? 'Administrador' : 'Aluno';
    const preview = document.getElementById('profilePreview');
    preview.innerHTML = userProfile.profileImage ? `<img src="${userProfile.profileImage}" style="width:100%;height:100%;object-fit:cover;">` : '&#9751;';
    document.getElementById('profileImageInput').value = '';
}
function formatarCpf(cpf) {
    const d = String(cpf).replace(/\D/g, '');
    return d.length === 11 ? d.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : cpf;
}

// ── MEUS PEDIDOS ──
function pedidoStatusGrupo(status) {
    const s = String(status).toUpperCase();
    if (s === 'DEVOLVIDO') return 'devolvido';
    if (s === 'RECUSADO' || s === 'CANCELADO') return 'negado';
    return 'ativo'; // PENDENTE, APROVADO, RETIRADO
}
async function carregarAbaPedidos() {
    const lista = document.getElementById('accPedidosLista');
    lista.innerHTML = '<div class="acc-empty">Carregando...</div>';
    await garantirMeusEmprestimos();
    renderAbaPedidos();
}
function renderAbaPedidos() {
    const lista = document.getElementById('accPedidosLista');
    let itens = meusEmprestimos.filter(e => pedidosFiltro === 'todos' || pedidoStatusGrupo(e.STATUS) === pedidosFiltro);
    itens = itens.slice().sort((a, b) => {
        const cmp = String(a.DATA_EMPRESTIMO).localeCompare(String(b.DATA_EMPRESTIMO)) || (a.IDEMPRESTIMO - b.IDEMPRESTIMO);
        return pedidosOrdem === 'antigas' ? cmp : -cmp;
    });

    if (!itens.length) { lista.innerHTML = '<div class="acc-empty">Nenhum pedido encontrado para este filtro.</div>'; return; }

    lista.innerHTML = itens.map(e => {
        const status = String(e.STATUS).toUpperCase();
        const devolvido = status === 'DEVOLVIDO';
        const motivoBloqueio = devolvido ? '' : 'Só é possível renovar um pedido depois que ele for devolvido.';
        const itensHtml = (e.ITENS || []).map(it => `
            <div class="acc-order-item">
                <span>${escapeHtml(it.COMPONENTE_NOME || 'Componente')} <span class="acc-order-item-qtd">x${it.QUANTIDADE}</span></span>
                <button type="button" class="acc-btn acc-btn-mini" ${devolvido ? '' : 'disabled title="' + motivoBloqueio + '"'} onclick="renovarComponente(${e.IDEMPRESTIMO}, ${it.IDCOMPONENTE}, this)">Renovar item</button>
            </div>`).join('') || '<div class="acc-empty" style="padding:0.75rem 0;">Nenhum item encontrado.</div>';

        return `
        <div class="acc-order">
            <div class="acc-order-head">
                <div>
                    <div class="acc-order-title">Pedido #${e.IDEMPRESTIMO}</div>
                    <div class="acc-order-date">Solicitado em ${formatarDataEmprestimo(String(e.DATA_EMPRESTIMO).slice(0, 10))}</div>
                </div>
                ${waStatus(status)}
            </div>
            <div class="acc-order-body">${itensHtml}</div>
            <div class="acc-order-foot">
                <button type="button" class="acc-btn" onclick="abrirChatView(${e.IDEMPRESTIMO})">Ver conversa</button>
                <button type="button" class="acc-btn solid" ${devolvido ? '' : 'disabled title="' + motivoBloqueio + '"'} onclick="renovarPedido(${e.IDEMPRESTIMO}, this)">Renovar pedido</button>
            </div>
        </div>`;
    }).join('');
}
document.addEventListener('change', e => {
    if (e.target.id === 'accPedidosFiltro') { pedidosFiltro = e.target.value; renderAbaPedidos(); }
    if (e.target.id === 'accPedidosOrdem') { pedidosOrdem = e.target.value; renderAbaPedidos(); }
});

async function renovarPedido(idEmprestimo, btn) {
    const emp = meusEmprestimos.find(e => e.IDEMPRESTIMO == idEmprestimo);
    if (!emp || String(emp.STATUS).toUpperCase() !== 'DEVOLVIDO') {
        stoktechToast('Este pedido ainda não foi devolvido.', 'aviso');
        return;
    }
    const itens = (emp.ITENS || []).map(it => ({ id: it.IDCOMPONENTE, quantidade: it.QUANTIDADE }));
    if (!itens.length) { stoktechToast('Este pedido não tem itens para renovar.', 'aviso'); return; }
    await enviarNovoPedido(itens, btn, `Pedido #${idEmprestimo} renovado! Acompanhe o novo pedido no chat.`);
}
async function renovarComponente(idEmprestimo, idComponente, btn) {
    const emp = meusEmprestimos.find(e => e.IDEMPRESTIMO == idEmprestimo);
    if (!emp || String(emp.STATUS).toUpperCase() !== 'DEVOLVIDO') {
        stoktechToast('Este pedido ainda não foi devolvido.', 'aviso');
        return;
    }
    const item = (emp.ITENS || []).find(it => it.IDCOMPONENTE == idComponente);
    if (!item) { stoktechToast('Item não encontrado neste pedido.', 'erro'); return; }
    await enviarNovoPedido([{ id: item.IDCOMPONENTE, quantidade: item.QUANTIDADE }], btn, `${item.COMPONENTE_NOME} renovado! Acompanhe o novo pedido no chat.`);
}
async function enviarNovoPedido(itens, btn, mensagemSucesso) {
    const textoOriginal = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Enviando...'; }
    try {
        const res = await fetch('menu_principal.php?acao=solicitar_emprestimo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ itens })
        });
        const data = await res.json();
        if (!data.sucesso) { stoktechToast(data.mensagem || 'Erro ao renovar.', 'erro'); return; }
        stoktechToast(mensagemSucesso, 'sucesso');
        await carregarMeusEmprestimos();
        renderAbaPedidos();
    } catch (e) {
        stoktechToast('Erro de conexão ao renovar.', 'erro');
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = textoOriginal; }
    }
}

// ── NOTIFICAÇÕES ──
function notifIcone(tipo) {
    const icones = {
        SUCESSO: '<path d="M20 6 9 17l-5-5"></path>',
        ALERTA: '<path d="M12 9v4M12 17h.01"></path><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"></path>',
        ERRO: '<circle cx="12" cy="12" r="10"></circle><path d="M15 9l-6 6M9 9l6 6"></path>',
        INFO: '<circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4M12 8h.01"></path>'
    };
    return icones[tipo] || icones.INFO;
}
async function carregarAbaNotificacoes() {
    const lista = document.getElementById('accNotifLista');
    lista.innerHTML = '<div class="acc-empty">Carregando...</div>';
    try {
        const res = await fetch(`menu_principal.php?acao=listar_notificacoes&ordem=${notifOrdem}`, { credentials: 'same-origin', cache: 'no-store' });
        const data = await res.json();
        if (!data.sucesso) { lista.innerHTML = `<div class="acc-empty">${escapeHtml(data.mensagem || 'Não foi possível carregar as notificações.')}</div>`; return; }
        notificacoes = data.notificacoes || [];
        renderAbaNotificacoes();
        atualizarBadgeContaGeral();
    } catch (e) {
        lista.innerHTML = '<div class="acc-empty">Erro de conexão.</div>';
    }
}
function renderAbaNotificacoes() {
    const lista = document.getElementById('accNotifLista');
    if (!notificacoes.length) { lista.innerHTML = '<div class="acc-empty">Você ainda não tem notificações.</div>'; return; }
    lista.innerHTML = notificacoes.map(n => `
        <div class="acc-notif tipo-${String(n.TIPO || 'INFO').toLowerCase()} ${Number(n.LIDA) === 0 ? 'unread' : ''}" onclick="clicarNotificacao(${n.IDNOTIFICACAO}, ${n.IDEMPRESTIMO ?? 'null'})">
            <div class="acc-notif-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${notifIcone(n.TIPO)}</svg></div>
            <div class="acc-notif-main">
                <div class="acc-notif-top">
                    <span class="acc-notif-title">${escapeHtml(n.TITULO)}</span>
                    <span class="acc-notif-time">${escapeHtml(waRotuloLista(n.CRIADA_EM))}</span>
                </div>
                <div class="acc-notif-msg">${escapeHtml(n.MENSAGEM)}</div>
            </div>
        </div>`).join('');
}
async function clicarNotificacao(id, idEmprestimo) {
    const n = notificacoes.find(x => x.IDNOTIFICACAO === id);
    if (n && Number(n.LIDA) === 0) {
        n.LIDA = 1;
        renderAbaNotificacoes();
        atualizarBadgeContaGeral();
        try {
            await fetch('menu_principal.php?acao=marcar_notificacao_lida', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin',
                body: JSON.stringify({ idnotificacao: id })
            });
        } catch (e) {}
    }
    if (idEmprestimo) abrirChatView(idEmprestimo);
}
document.addEventListener('change', e => { if (e.target.id === 'accNotifOrdem') { notifOrdem = e.target.value; carregarAbaNotificacoes(); } });
document.addEventListener('click', async e => {
    if (e.target.id !== 'accNotifMarcarTodas') return;
    notificacoes.forEach(n => n.LIDA = 1);
    renderAbaNotificacoes();
    atualizarBadgeContaGeral();
    try {
        await fetch('menu_principal.php?acao=marcar_notificacao_lida', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin',
            body: JSON.stringify({ todas: true })
        });
    } catch (err) {}
});
function atualizarBadgeContaGeral() {
    const badge = document.getElementById('accDotNotif');
    if (badge) badge.classList.toggle('show', notificacoes.some(n => Number(n.LIDA) === 0));
}

// ── PRAZOS / CALENDÁRIO ──
const ACC_MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const ACC_DOWS = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
function accIso(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function eventoTipoClasse(tipo) { return tipo === 'FERIAS' ? 'ferias' : tipo === 'IMPORTANTE' ? 'importante' : 'feriado'; }
async function carregarAbaPrazos() {
    await garantirMeusEmprestimos();
    if (eventosCalendario === null) {
        try {
            const res = await fetch('menu_principal.php?acao=listar_eventos_calendario', { credentials: 'same-origin', cache: 'no-store' });
            const data = await res.json();
            eventosCalendario = data.sucesso ? (data.eventos || []) : [];
        } catch (e) { eventosCalendario = []; }
    }
    renderCalendario();
}
function eventosDoDia(iso) {
    const marcas = [];
    (eventosCalendario || []).forEach(ev => {
        const ini = ev.DATA_INICIO, fim = ev.DATA_FIM || ev.DATA_INICIO;
        if (iso >= ini && iso <= fim) marcas.push({ tipo: eventoTipoClasse(ev.TIPO), titulo: ev.TITULO });
    });
    (meusEmprestimos || []).forEach(e => {
        const status = String(e.STATUS).toUpperCase();
        if (status === 'RETIRADO' && e.PRAZO_DEVOLUCAO && String(e.PRAZO_DEVOLUCAO).slice(0, 10) === iso) {
            marcas.push({ tipo: 'devolucao', titulo: `Devolução do pedido #${e.IDEMPRESTIMO}` });
        }
    });
    return marcas;
}
function renderCalendario() {
    const ano = accCalRef.getFullYear(), mes = accCalRef.getMonth();
    document.getElementById('accCalMes').textContent = `${ACC_MESES[mes]} de ${ano}`;

    const grid = document.getElementById('accCalGrid');
    const primeiroDia = new Date(ano, mes, 1);
    const inicioGrade = new Date(primeiroDia); inicioGrade.setDate(1 - primeiroDia.getDay());
    const hojeIso = accIso(new Date());

    let html = ACC_DOWS.map(d => `<div class="acc-cal-dow">${d}</div>`).join('');
    for (let i = 0; i < 42; i++) {
        const dia = new Date(inicioGrade); dia.setDate(inicioGrade.getDate() + i);
        const iso = accIso(dia);
        const marcas = eventosDoDia(iso);
        const classes = ['acc-cal-day'];
        if (dia.getMonth() !== mes) classes.push('outro-mes');
        if (iso === hojeIso) classes.push('hoje');
        if (marcas.some(m => m.tipo === 'feriado')) classes.push('feriado');
        if (marcas.some(m => m.tipo === 'ferias')) classes.push('ferias');
        if (marcas.some(m => m.tipo === 'importante')) classes.push('importante');
        if (marcas.some(m => m.tipo === 'devolucao')) classes.push('devolucao');
        const dots = marcas.length
            ? `<div class="acc-cal-dots">${marcas.map(m => `<span style="background:${m.tipo === 'feriado' ? 'var(--danger)' : m.tipo === 'ferias' ? 'var(--warning)' : 'var(--primary)'}"></span>`).join('')}</div>`
            : '';
        html += `<div class="${classes.join(' ')}" title="${marcas.map(m => escapeHtml(m.titulo)).join(', ')}">${dia.getDate()}${dots}</div>`;
    }
    grid.innerHTML = html;

    // lista dos próximos prazos (a partir de hoje)
    const proximos = [];
    (eventosCalendario || []).forEach(ev => { if ((ev.DATA_FIM || ev.DATA_INICIO) >= hojeIso) proximos.push({ iso: ev.DATA_INICIO, tipo: eventoTipoClasse(ev.TIPO), titulo: ev.TITULO }); });
    (meusEmprestimos || []).forEach(e => {
        if (String(e.STATUS).toUpperCase() === 'RETIRADO' && e.PRAZO_DEVOLUCAO && String(e.PRAZO_DEVOLUCAO).slice(0, 10) >= hojeIso) {
            proximos.push({ iso: String(e.PRAZO_DEVOLUCAO).slice(0, 10), tipo: 'devolucao', titulo: `Devolução do pedido #${e.IDEMPRESTIMO}` });
        }
    });
    proximos.sort((a, b) => a.iso.localeCompare(b.iso));
    const cores = { feriado: 'var(--danger)', ferias: 'var(--warning)', importante: 'var(--primary)', devolucao: 'var(--primary)' };
    document.getElementById('accCalLista').innerHTML = proximos.length
        ? proximos.slice(0, 12).map(p => `<div class="acc-cal-item"><i style="background:${cores[p.tipo]}"></i><span class="acc-cal-item-date">${formatarDataEmprestimo(p.iso)}</span><span>${escapeHtml(p.titulo)}</span></div>`).join('')
        : '<div class="acc-empty">Nenhum prazo próximo.</div>';
}
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('accCalPrev')?.addEventListener('click', () => { accCalRef.setMonth(accCalRef.getMonth() - 1); renderCalendario(); });
    document.getElementById('accCalNext')?.addEventListener('click', () => { accCalRef.setMonth(accCalRef.getMonth() + 1); renderCalendario(); });
    document.getElementById('accCalHoje')?.addEventListener('click', () => { accCalRef = new Date(); renderCalendario(); });
});

// ── PROPOR DOAÇÃO ──
function accConfigurarDoacao() {
    const input = document.getElementById('accDoacaoFoto');
    document.getElementById('accDoacaoFotoLabel')?.addEventListener('click', () => input.click());
    input?.addEventListener('change', () => {
        const label = document.getElementById('accDoacaoFotoLabel');
        const texto = document.getElementById('accDoacaoFotoTexto');
        const file = input.files[0];
        if (!file) return;
        label.querySelector('img')?.remove();
        const reader = new FileReader();
        reader.onload = ev => {
            const img = document.createElement('img');
            img.src = ev.target.result;
            label.prepend(img);
            texto.style.position = 'relative'; texto.style.zIndex = '1'; texto.style.color = '#fff'; texto.style.textShadow = '0 1px 4px rgba(0,0,0,0.7)';
            texto.textContent = 'Toque para trocar a foto';
        };
        reader.readAsDataURL(file);
    });
    document.getElementById('accDoacaoEnviar')?.addEventListener('click', enviarDoacao);
}
async function enviarDoacao() {
    const descricao = document.getElementById('accDoacaoDescricao').value.trim();
    const danificado = document.getElementById('accDoacaoDanificado').checked;
    const fotoInput = document.getElementById('accDoacaoFoto');
    const btn = document.getElementById('accDoacaoEnviar');

    if (!descricao) { stoktechToast('Descreva o componente que deseja doar.', 'aviso'); return; }
    if (!fotoInput.files[0]) { stoktechToast('Anexe uma foto do componente.', 'aviso'); return; }

    const fd = new FormData();
    fd.append('descricao', descricao);
    fd.append('danificado', danificado ? '1' : '0');
    fd.append('imagem', fotoInput.files[0]);

    btn.disabled = true; const textoOriginal = btn.textContent; btn.textContent = 'Enviando...';
    try {
        const res = await fetch('menu_principal.php?acao=enviar_doacao', { method: 'POST', body: fd, credentials: 'same-origin' });
        const data = await res.json();
        if (!data.sucesso) { stoktechToast(data.mensagem || 'Erro ao enviar doação.', 'erro'); return; }
        stoktechToast(data.mensagem, 'sucesso');
        document.getElementById('accDoacaoDescricao').value = '';
        document.getElementById('accDoacaoDanificado').checked = false;
        fotoInput.value = '';
        document.getElementById('accDoacaoFotoLabel').querySelector('img')?.remove();
        const texto = document.getElementById('accDoacaoFotoTexto');
        texto.style.color = ''; texto.style.textShadow = '';
        texto.textContent = 'Toque para tirar uma foto ou escolher da galeria';
        await carregarAbaDoacao();
    } catch (e) {
        stoktechToast('Erro de conexão ao enviar doação.', 'erro');
    } finally {
        btn.disabled = false; btn.textContent = textoOriginal;
    }
}
function doacaoStatusLabel(s) {
    const m = { PENDENTE: 'Em análise', ACEITA: 'Aceita', RECUSADA: 'Recusada' };
    return m[String(s).toUpperCase()] || s;
}
async function carregarAbaDoacao() {
    if (!doacaoConfigurada) { accConfigurarDoacao(); doacaoConfigurada = true; }
    const lista = document.getElementById('accDoacoesLista');
    lista.innerHTML = '<div class="acc-empty">Carregando...</div>';
    try {
        const res = await fetch('menu_principal.php?acao=listar_minhas_doacoes', { credentials: 'same-origin', cache: 'no-store' });
        const data = await res.json();
        doacoes = data.sucesso ? (data.doacoes || []) : [];
        lista.innerHTML = doacoes.length ? doacoes.map(d => `
            <div class="acc-donation-item">
                <img class="acc-donation-thumb" src="${escapeHtml(d.IMAGEM)}" alt="" onerror="this.style.visibility='hidden'">
                <div class="acc-donation-main">
                    <div class="acc-donation-desc">${escapeHtml(d.DESCRICAO)}</div>
                    <div class="acc-donation-meta">${formatarDataEmprestimo(String(d.CRIADA_EM).slice(0, 10))} ${Number(d.DANIFICADO) === 1 ? '· Danificado' : ''}</div>
                </div>
                <span class="wa-status ${d.STATUS === 'ACEITA' ? 'st-aprovado' : d.STATUS === 'RECUSADA' ? 'st-recusado' : 'st-pendente'}">${doacaoStatusLabel(d.STATUS)}</span>
            </div>`).join('') : '<div class="acc-empty">Você ainda não propôs nenhuma doação.</div>';
    } catch (e) {
        lista.innerHTML = '<div class="acc-empty">Erro de conexão.</div>';
    }
}

// ── SETUP GERAL ──
function accConfigurar() {
    document.querySelectorAll('.acc-tab').forEach(tab => tab.addEventListener('click', () => alternarAba(tab.dataset.aba)));
    document.getElementById('hdrUser')?.addEventListener('click', () => abrirConta('dados'));
    document.getElementById('cancelEditAcc')?.addEventListener('click', carregarCamposPerfil);
}

function escapeHtml(text) {
    return String(text ?? '').replace(/[&<>"']/g, function(char) {
        return ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;' })[char];
    });
}

function formatarDataEmprestimo(data) {
    if (!data) return '';
    return String(data).split('-').reverse().join('/');
}

function productImage(product) {
    if (product.image && String(product.image).trim() !== '') {
        return `<img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}">`;
    }
    return escapeHtml(product.icon || '📦');
}

function saveCart() {
    const dados = cart.map(item => ({ id: item.id, quantity: item.quantity }));
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(dados));
}

function loadCart() {
    const salvo = localStorage.getItem(CART_STORAGE_KEY);
    if (!salvo) return;
    try {
        const dados = JSON.parse(salvo);
        cart = [];
        products.forEach(p => productQuantities[p.id] = 0);
        dados.forEach(itemSalvo => {
            const product = products.find(p => p.id == itemSalvo.id);
            if (!product) return;
            const qty = Math.max(0, Math.min(parseInt(itemSalvo.quantity) || 0, product.stock));
            if (qty > 0) {
                productQuantities[product.id] = qty;
                cart.push({ ...product, quantity: qty });
            }
        });
        updateCartCount();
    } catch(e) {
        cart = [];
        products.forEach(p => productQuantities[p.id] = 0);
        localStorage.removeItem(CART_STORAGE_KEY);
    }
}

function resetCart() {
    cart = [];
    products.forEach(p => productQuantities[p.id] = 0);
    localStorage.removeItem(CART_STORAGE_KEY);
}

function renderProducts() {
    const grid = document.getElementById('productsGrid');
    const filtered = currentCategory === 'todos' ? products : products.filter(p => p.category === currentCategory);
    document.getElementById('productCount').textContent = filtered.length + ' ' + (filtered.length === 1 ? 'item' : 'itens');
    if (!filtered.length) {
        grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:3rem 0;font-size:0.9rem;">Nenhum componente cadastrado nesta categoria.</p>';
        return;
    }
    grid.innerHTML = filtered.map(product => buildProductCard(product)).join('');
}

function buildProductCard(product) {
    const available = product.stock - productQuantities[product.id];
    const qty = productQuantities[product.id];
    const stockClass = available === 0 ? 'stock-out' : available <= 5 ? 'stock-low' : 'stock-ok';
    return `
        <div class="product-card">
            <div class="product-image">${productImage(product)}</div>
            <div class="product-info">
                <h3 class="product-name">${escapeHtml(product.name)}</h3>
                <p class="product-description">${escapeHtml(product.description)}</p>
                <div class="product-stock">
                    <span>Disponível</span>
                    <span class="${stockClass}">${available} un</span>
                </div>
                <div class="product-actions">
                    <div class="quantity-control">
                        <button class="qty-btn" onclick="decreaseQuantity(${product.id})" ${qty === 0 ? 'disabled' : ''}>&#8722;</button>
                        <input type="number" class="qty-input" value="${qty}" min="0" max="${available + qty}" onchange="setQuantity(${product.id}, this.value)" onclick="this.select()">
                        <button class="qty-btn" onclick="increaseQuantity(${product.id})" ${available === 0 ? 'disabled' : ''}>+</button>
                    </div>
                    <button class="details-btn" onclick="showDetails(${product.id})">Ver Especificações</button>
                </div>
            </div>
        </div>`;
}

function increaseQuantity(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    if (product.stock - productQuantities[productId] > 0) {
        productQuantities[productId]++;
        const item = cart.find(i => i.id === productId);
        if (item) item.quantity++; else cart.push({ ...product, quantity: 1 });
        saveCart(); updateCartCount(); renderProducts();
        showNotification('Adicionado ao carrinho');
    }
}
function decreaseQuantity(productId) {
    if (productQuantities[productId] > 0) {
        productQuantities[productId]--;
        const item = cart.find(i => i.id === productId);
        if (item) { item.quantity--; if (item.quantity === 0) cart = cart.filter(i => i.id !== productId); }
        saveCart(); updateCartCount(); renderProducts();
    }
}
function setQuantity(productId, value) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    let qty = Math.max(0, Math.min(parseInt(value) || 0, product.stock));
    productQuantities[productId] = qty;
    if (qty === 0) { cart = cart.filter(i => i.id !== productId); }
    else { const item = cart.find(i => i.id === productId); if (item) item.quantity = qty; else cart.push({ ...product, quantity: qty }); }
    saveCart(); updateCartCount(); renderProducts();
}
function filterProducts(term) {
    const grid = document.getElementById('productsGrid');
    const base = currentCategory === 'todos' ? products : products.filter(p => p.category === currentCategory);
    const filtered = base.filter(p => p.name.toLowerCase().includes(term.toLowerCase()) || p.description.toLowerCase().includes(term.toLowerCase()));
    document.getElementById('productCount').textContent = filtered.length + ' itens';
    if (!filtered.length) { grid.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:3rem 0;font-size:0.9rem;">Nenhum componente encontrado</p>'; return; }
    grid.innerHTML = filtered.map(p => buildProductCard(p)).join('');
}
function updateCartCount() {
    document.getElementById('cartCount').textContent = cart.reduce((s, i) => s + i.quantity, 0);
}

// ── CART ──
function openCart() { document.getElementById('cartModal').classList.add('active'); renderCart(); }
function closeCart() { document.getElementById('cartModal').classList.remove('active'); }
function renderCart() {
    const el = document.getElementById('cartItems');
    if (!cart.length) { el.innerHTML = '<div class="empty-cart">Carrinho vazio</div>'; return; }
    el.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div class="cart-item-icon">${productImage(item)}</div>
            <div class="cart-item-info">
                <div class="cart-item-name">${escapeHtml(item.name)}</div>
                <div class="cart-item-quantity">${item.quantity} unidade${item.quantity > 1 ? 's' : ''}</div>
            </div>
            <div class="cart-item-controls">
                <button class="qty-btn" onclick="decreaseFromCart(${item.id})">&#8722;</button>
                <span style="font-family:'IBM Plex Mono',monospace;font-size:0.85rem;min-width:20px;text-align:center;">${item.quantity}</span>
                <button class="qty-btn" onclick="increaseFromCart(${item.id})">+</button>
                <button class="qty-btn cart-item-remove" title="Remover todas as unidades" onclick="removeItemFromCart(${item.id})">
                    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
                </button>
            </div>
        </div>`).join('');
}
function increaseFromCart(id) {
    const p = products.find(p => p.id === id);
    if (p && p.stock - productQuantities[id] > 0) {
        productQuantities[id]++; cart.find(i => i.id === id).quantity++;
        saveCart(); updateCartCount(); renderCart(); renderProducts();
    }
    else stoktechToast('Estoque esgotado para este item.', 'aviso');
}
function decreaseFromCart(id) {
    if (productQuantities[id] > 0) {
        productQuantities[id]--;
        const item = cart.find(i => i.id === id);
        item.quantity--;
        if (!item.quantity) cart = cart.filter(i => i.id !== id);
        saveCart(); updateCartCount(); renderCart(); renderProducts();
    }
}
function abrirModalConfirmarEmail(){

    document.getElementById(
        "modalConfirmarEmail"
    ).style.display = "flex";

}



function fecharModalEmail(){

    document.getElementById(
        "modalConfirmarEmail"
    ).style.display = "none";

}



async function confirmarEmailNovo(){


    const codigo =
    document.getElementById(
        "codigoConfirmacaoEmail"
    ).value.trim();



    if(codigo.length !== 6){

        alert(
            "Digite o código de 6 números."
        );

        return;

    }



    const formData = new FormData();


    formData.append(
        "codigo",
        codigo
    );



    try {


        const resposta =
        await fetch(
            "confirmar_email.php",
            {
                method:"POST",
                body:formData
            }
        );



        const dados =
        await resposta.json();



        alert(
            dados.mensagem
        );



        if(dados.sucesso){

            location.reload();

        }



    } catch(error){


        alert(
            "Erro ao confirmar email."
        );


    }

}
async function removeItemFromCart(id) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    const ok = await stoktechConfirm({
        titulo: 'Remover componente',
        mensagem: `Tem certeza que deseja remover todas as ${item.quantity} unidade(s) de "${item.name}" do carrinho?`,
        textoConfirmar: 'Remover'
    });
    if (!ok) return;
    productQuantities[id] = 0;
    cart = cart.filter(i => i.id !== id);
    saveCart(); updateCartCount(); renderCart(); renderProducts();
    stoktechToast('Componente removido do carrinho.', 'sucesso');
}
async function clearCart() {
    const ok = await stoktechConfirm({
        titulo: 'Limpar carrinho',
        mensagem: 'Você tem certeza que deseja limpar todos os itens do carrinho?',
        textoConfirmar: 'Limpar'
    });
    if (!ok) return;
    resetCart(); updateCartCount(); renderCart(); renderProducts();
}
async function requestItems() {
    if (!cart.length) { stoktechToast('Adicione itens antes de solicitar.', 'aviso'); return; }

    const btn = document.getElementById('requestItems');
    const textoOriginal = btn.textContent;
    btn.disabled = true; btn.textContent = 'Enviando...';

    try {
        const res = await fetch('menu_principal.php?acao=solicitar_emprestimo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ itens: cart.map(i => ({ id: i.id, quantidade: i.quantity })) })
        });
        const data = await res.json();
        if (!data.sucesso) { stoktechToast(data.mensagem, 'erro'); return; }

        resetCart(); updateCartCount(); renderProducts();
        showNotification('Solicitação enviada com sucesso');
        closeCart();
        abrirChatView(data.idemprestimo);
    } catch(e) {
        stoktechToast('Erro de conexão.', 'erro');
    } finally {
        btn.disabled = false; btn.textContent = textoOriginal;
    }
}

// ── DETAILS ──
function showDetails(id) {
    const p = products.find(p => p.id === id);
    if (!p) return;
    const specs = Object.keys(p.specs || {}).length ? Object.entries(p.specs).map(([k, v]) => `<div class="spec-item"><strong>${escapeHtml(k)}</strong><span>${escapeHtml(v)}</span></div>`).join('') : '<p style="color:var(--text-muted);font-size:0.88rem;">Nenhuma especificação cadastrada.</p>';
    document.getElementById('detailsContent').innerHTML = `
        <div class="details-header">
            <div class="details-image">${productImage(p)}</div>
            <div class="details-info">
                <h2>${escapeHtml(p.name)}</h2>
                <p>${escapeHtml(p.fullDescription)}</p>
            </div>
        </div>
        <div class="details-specs">
            <h3>Especificações Técnicas</h3>
            ${specs}
        </div>`;
    document.getElementById('detailsModal').classList.add('active');
}
function closeDetails() { document.getElementById('detailsModal').classList.remove('active'); }

// ── PROFILE ──
function updateProfileDisplay() {
    document.getElementById('headerUserName').textContent = userProfile.name;
    document.getElementById('headerUserEmail').textContent = userProfile.email;
    const av = document.getElementById('headerAvatar');
    if (userProfile.profileImage) {
        av.innerHTML = `<img src="${userProfile.profileImage}" alt="">`;
    } else {
        av.innerHTML = userProfile.name ? userProfile.name.charAt(0).toUpperCase() : '&#9751;';
        av.style.fontFamily = 'IBM Plex Sans, sans-serif';
        av.style.fontSize = '0.9rem';
        av.style.fontWeight = '700';
    }
}
function handleProfileImageUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => { document.getElementById('profilePreview').innerHTML = `<img src="${ev.target.result}" style="width:100%;height:100%;object-fit:cover;">`; };
    reader.readAsDataURL(file);
}
async function saveProfile() {

    const name = document.getElementById('editName').value.trim();
    const email = document.getElementById('editEmail').value.trim();
    const pw = document.getElementById('editPassword').value;
    const cpw = document.getElementById('confirmPassword').value;


    if (!name || !email) {
        stoktechToast('Nome e email são obrigatórios.', 'aviso');
        return;
    }


    if (pw && pw !== cpw) {
        stoktechToast('As senhas não coincidem.', 'aviso');
        return;
    }


    const btn = document.getElementById('saveProfile');

    btn.disabled = true;
    btn.textContent = 'Salvando...';


    const fd = new FormData();

    fd.append('nome', name);
    fd.append('email', email);


    if (pw) {
        fd.append('senha', pw);
    }


    const fotoInput = document.getElementById('profileImageInput');

    if (fotoInput.files[0]) {
        fd.append('foto', fotoInput.files[0]);
    }


    try {

        const res = await fetch(
            'atualizar_perfil.php',
            {
                method: 'POST',
                body: fd
            }
        );


        const data = await res.json();



        if (data.sucesso) {


            userProfile.name = name;



            // Se o email precisa de confirmação
            if (data.email_pendente) {


                abrirModalConfirmarEmail();


                showNotification(
                    data.mensagem
                );


                btn.disabled = false;
                btn.textContent = 'Salvar Alterações';

                return;

            }



            // Caso não tenha alteração de email
            userProfile.email = email;



            if (data.foto_perfil) {
                userProfile.profileImage = data.foto_perfil;
            }



            updateProfileDisplay();


            fotoInput.value = '';



            showNotification(
                data.mensagem
            );



        } else {


            stoktechToast(
                data.mensagem,
                'erro'
            );


        }



    } catch(error) {


        console.error(error);


        stoktechToast(
            'Erro de conexão.',
            'erro'
        );


    }



    btn.disabled = false;
    btn.textContent = 'Salvar Alterações';

}

// ── CHAT DE EMPRÉSTIMOS (estilo WhatsApp Web) ──
const USER_ID = <?= (int)($_SESSION['idusuario'] ?? 0) ?>;
const WA_VISTOS_KEY = 'stokUserVistos_' + USER_ID;
const WA_INTERVALO_MS = 3000;
let meusEmprestimos = [];
let waChatAberto = false;
let waVistos = {};
let waVistosExistia = false;
let waAssinatura = null;
let waSincronizando = false;
let waEnviando = false;

(function () {
    try {
        const salvo = localStorage.getItem(WA_VISTOS_KEY);
        if (salvo) { waVistos = JSON.parse(salvo) || {}; waVistosExistia = true; }
    } catch (e) { waVistos = {}; }
})();
function waSalvarVistos() { try { localStorage.setItem(WA_VISTOS_KEY, JSON.stringify(waVistos)); } catch (e) {} }

function waUltimoIdMsg(emp) {
    return (emp.MENSAGENS || []).reduce((max, m) => Math.max(max, Number(m.IDMENSAGEM) || 0), 0);
}
function waNaoLidas(emp) {
    const visto = Number(waVistos[emp.IDEMPRESTIMO] || 0);
    return (emp.MENSAGENS || []).filter(m => m.USUARIO_TIPO === 'ADMINISTRADOR' && Number(m.IDMENSAGEM) > visto).length;
}
function waMarcarVisto(emp) {
    const ultimo = waUltimoIdMsg(emp);
    if (Number(waVistos[emp.IDEMPRESTIMO] || 0) !== ultimo) { waVistos[emp.IDEMPRESTIMO] = ultimo; waSalvarVistos(); }
}
function waEncerrado(emp) { return ['DEVOLVIDO', 'RECUSADO', 'CANCELADO'].includes(String(emp.STATUS).toUpperCase()); }
function waRenovacaoPendente(emp) { return (emp.RENOVACOES || []).some(r => String(r.STATUS).toUpperCase() === 'PENDENTE'); }
function waBuscarEmp(id) { return meusEmprestimos.find(e => e.IDEMPRESTIMO == id); }

function atualizarBadgeChat() {
    const badge = document.getElementById('chatBadgeUser');
    if (!badge) return;
    const total = meusEmprestimos.reduce((soma, e) => soma + waNaoLidas(e), 0);
    badge.textContent = total > 99 ? '99+' : total;
    badge.style.display = total > 0 ? 'flex' : 'none';
}

// ── datas ──
function waDia(str) { return String(str || '').slice(0, 10); }
function waIso(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function waRotuloDia(dia) {
    if (dia === waIso(new Date())) return 'Hoje';
    const o = new Date(); o.setDate(o.getDate() - 1);
    if (dia === waIso(o)) return 'Ontem';
    return formatarDataEmprestimo(dia);
}
function waRotuloLista(ts) {
    const dia = waDia(ts);
    if (!dia) return '';
    if (dia === waIso(new Date())) { const h = String(ts).slice(11, 16); return (!h || h === '00:00') ? 'Hoje' : h; }
    const o = new Date(); o.setDate(o.getDate() - 1);
    if (dia === waIso(o)) return 'Ontem';
    return formatarDataEmprestimo(dia);
}
function waAtividade(emp) {
    const cand = [waDia(emp.DATA_EMPRESTIMO) + ' 00:00:00'];
    const ms = emp.MENSAGENS || [];
    if (ms.length) cand.push(String(ms[ms.length - 1].DATA_ENVIO));
    (emp.RENOVACOES || []).forEach(r => {
        if (r.DATA_SOLICITACAO) cand.push(String(r.DATA_SOLICITACAO));
        if (r.DATA_RESPOSTA) cand.push(String(r.DATA_RESPOSTA));
    });
    return cand.sort().pop();
}

// ── peças visuais ──
const WA_ICONE_LAB = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="6" height="6"></rect><rect x="5" y="5" width="14" height="14" rx="1"></rect><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"></path></svg>';
function waStatus(status) {
    const s = String(status || 'PENDENTE').toUpperCase();
    const nomes = { PENDENTE: 'Pendente', APROVADO: 'Aprovado', RETIRADO: 'Retirado', DEVOLVIDO: 'Devolvido', RECUSADO: 'Recusado', CANCELADO: 'Cancelado' };
    return `<span class="wa-status st-${s.toLowerCase()}">${nomes[s] || escapeHtml(s)}</span>`;
}
function waPreview(emp) {
    if (waRenovacaoPendente(emp)) return { texto: 'Renovação aguardando resposta', alerta: true };
    const ms = emp.MENSAGENS || [];
    if (ms.length) {
        const u = ms[ms.length - 1];
        const meu = u.USUARIO_TIPO !== 'ADMINISTRADOR';
        return { texto: (meu ? 'Você: ' : '') + String(u.MENSAGEM).replace(/\s+/g, ' '), alerta: false };
    }
    const n = (emp.ITENS || []).length;
    return { texto: `${n} item${n !== 1 ? 'ns' : ''} solicitado${n !== 1 ? 's' : ''}`, alerta: false };
}

// ── 2ª sidebar: meus empréstimos ──
function renderListaChats() {
    const el = document.getElementById('waListBody');
    if (!el) return;
    if (!meusEmprestimos.length) { el.innerHTML = '<div class="wa-list-empty">Você ainda não solicitou nenhum empréstimo.</div>'; return; }
    const itens = meusEmprestimos.slice().sort((a, b) => {
        const ta = waAtividade(a), tb = waAtividade(b);
        return ta < tb ? 1 : ta > tb ? -1 : Number(b.IDEMPRESTIMO) - Number(a.IDEMPRESTIMO);
    });
    const rolagem = el.scrollTop;
    el.innerHTML = itens.map(e => {
        const id = Number(e.IDEMPRESTIMO);
        const nl = waNaoLidas(e);
        const p = waPreview(e);
        return `
        <div class="wa-item ${id == currentChatId ? 'active' : ''} ${nl > 0 ? 'unread' : ''}" onclick="abrirChat(${id})">
            <div class="wa-avatar">${WA_ICONE_LAB}</div>
            <div class="wa-item-main">
                <div class="wa-item-top">
                    <span class="wa-item-name">Empréstimo #${id}</span>
                    <span class="wa-item-time">${waRotuloLista(waAtividade(e))}</span>
                </div>
                <div class="wa-item-mid">
                    <span class="wa-item-preview ${p.alerta ? 'alerta' : ''}">${escapeHtml(p.texto)}</span>
                    ${nl > 0 ? `<span class="wa-unread">${nl}</span>` : ''}
                </div>
                <div class="wa-item-bot">${waStatus(e.STATUS)}<span class="wa-item-id">${formatarDataEmprestimo(waDia(e.DATA_EMPRESTIMO))}</span></div>
            </div>
        </div>`;
    }).join('');
    el.scrollTop = rolagem;
}

// ── abrir / fechar a tela de chat ──
function mostrarTelaChat(sim) {
    waChatAberto = sim;
    if (sim) { contaAberta = false; document.getElementById('accountLayout')?.classList.remove('active'); }
    document.querySelector('.content-area').style.display = sim ? 'none' : '';
    document.getElementById('waLayout').classList.toggle('active', sim);
    document.body.classList.toggle('wa-mode', sim);
    atualizarVisibilidadeSidebarPrincipal();
}
async function abrirChatView(idParaAbrir = null) {
    if (MODO_CONVIDADO) return;
    closeSidebarMobile();
    mostrarTelaChat(true);
    if (!meusEmprestimos.length) document.getElementById('waListBody').innerHTML = '<div class="wa-list-empty">Carregando...</div>';
    else renderListaChats();
    try {
        await carregarMeusEmprestimos();
    } catch (e) {
        document.getElementById('waListBody').innerHTML = '<div class="wa-list-empty">Erro ao carregar empréstimos.</div>';
        return;
    }
    if (idParaAbrir != null && waBuscarEmp(idParaAbrir)) { abrirChat(idParaAbrir); return; }
    if (currentChatId != null && !waBuscarEmp(currentChatId)) currentChatId = null;
    const aberto = currentChatId == null ? null : waBuscarEmp(currentChatId);
    if (aberto) waMarcarVisto(aberto);
    renderListaChats();
    renderConversa({ irParaFim: true });
    atualizarBadgeChat();
}
function fecharChatView() {
    if (!waChatAberto) return;
    mostrarTelaChat(false);
}
function alternarChatView() { if (waChatAberto) fecharChatView(); else abrirChatView(); }

function abrirChat(id) {
    const emp = waBuscarEmp(id);
    if (!emp) { stoktechToast('Empréstimo não encontrado.', 'erro'); return; }
    currentChatId = Number(id);
    waMarcarVisto(emp);
    document.getElementById('waLayout').classList.add('chat-active');
    renderListaChats();
    renderConversa({ irParaFim: true });
    atualizarBadgeChat();
    if (!waEncerrado(emp) && window.innerWidth > 860) setTimeout(() => document.getElementById('waInput').focus(), 50);
}
function waVoltarLista() {
    currentChatId = null;
    document.getElementById('waLayout').classList.remove('chat-active');
    renderListaChats();
    renderConversa();
}

function waBarraAcoes(emp) {
    const bar = document.getElementById('waActionBar');
    const s = String(emp.STATUS).toUpperCase();
    let html = '', aviso = false;
    if (s === 'PENDENTE') {
        aviso = true;
        html = '<span><strong>Aguardando análise</strong> — o gerenciador vai responder por aqui.</span>';
    } else if (s === 'APROVADO') {
        html = `<span><strong>Aprovado</strong> — retire os itens no laboratório até ${formatarDataEmprestimo(waDia(emp.DATA_LIMITE_RETIRADA)) || '—'}.</span>`;
    } else if (s === 'RETIRADO') {
        if (waRenovacaoPendente(emp)) {
            aviso = true;
            html = '<span><strong>Renovação pendente</strong> — aguardando resposta do gerenciador.</span>';
        } else {
            html = `<span><strong>Retirado</strong> — devolução até ${formatarDataEmprestimo(waDia(emp.PRAZO_DEVOLUCAO)) || '—'}.</span>
                    <span class="wa-act-btns"><button class="primary-btn" onclick="solicitarRenovacao()">Solicitar renovação</button></span>`;
        }
    }
    bar.innerHTML = html;
    bar.classList.toggle('warn', aviso);
    bar.style.display = html ? 'flex' : 'none';
}

function waMontarLinhaDoTempo(emp) {
    const ev = [];
    const itens = (emp.ITENS || []).length
        ? emp.ITENS.map(i => `• ${escapeHtml(i.COMPONENTE_NOME)} — Quantidade: ${i.QUANTIDADE}`).join('<br>')
        : 'Nenhum item encontrado.';
    ev.push({ ts: waDia(emp.DATA_EMPRESTIMO) + ' 00:00:00', ord: 0, id: 0, html: `
        <div class="wa-card">
            <div class="wa-card-title">Solicitação de empréstimo #${emp.IDEMPRESTIMO}</div>
            <strong>Data da solicitação:</strong> ${formatarDataEmprestimo(waDia(emp.DATA_EMPRESTIMO))}<br><br>
            <strong>Itens:</strong><br>${itens}
        </div>` });

    if (emp.DATA_APROVACAO) ev.push({ ts: waDia(emp.DATA_APROVACAO) + ' 00:00:00', ord: 1, id: 0, html: `<div class="wa-notice">Empréstimo aprovado — retirada até ${formatarDataEmprestimo(waDia(emp.DATA_LIMITE_RETIRADA)) || '—'}</div>` });
    if (emp.DATA_RETIRADA) ev.push({ ts: waDia(emp.DATA_RETIRADA) + ' 00:00:00', ord: 1, id: 1, html: `<div class="wa-notice">Itens retirados — devolução até ${formatarDataEmprestimo(waDia(emp.PRAZO_DEVOLUCAO)) || '—'}</div>` });
    if (emp.DATA_DEVOLUCAO) ev.push({ ts: waDia(emp.DATA_DEVOLUCAO) + ' 00:00:00', ord: 1, id: 2, html: '<div class="wa-notice">Itens devolvidos — empréstimo concluído</div>' });

    (emp.MENSAGENS || []).forEach(m => {
        const adm = m.USUARIO_TIPO === 'ADMINISTRADOR';
        ev.push({ ts: String(m.DATA_ENVIO), ord: 2, id: Number(m.IDMENSAGEM), html: `
            <div class="wa-msg ${adm ? 'theirs' : 'mine'}">
                ${adm ? '<div class="wa-msg-author">Gerenciador</div>' : ''}
                <div class="wa-text">${escapeHtml(m.MENSAGEM)}</div>
                <span class="wa-msg-time">${escapeHtml(String(m.DATA_ENVIO).slice(11, 16))}</span>
            </div>` });
    });

    (emp.RENOVACOES || []).forEach(r => {
        const st = String(r.STATUS).toUpperCase();
        ev.push({ ts: String(r.DATA_SOLICITACAO || ''), ord: 3, id: Number(r.IDRENOVACAO), html: `
            <div class="wa-card warn">
                <div class="wa-card-title">Pedido de renovação</div>
                <strong>Nova data solicitada:</strong> ${formatarDataEmprestimo(waDia(r.NOVA_DATA_SOLICITADA))}<br>
                <strong>Motivo:</strong> ${escapeHtml(r.MOTIVO)}
            </div>` });
        if (st !== 'PENDENTE' && r.DATA_RESPOSTA) {
            ev.push({ ts: String(r.DATA_RESPOSTA), ord: 4, id: Number(r.IDRENOVACAO), html: `
                <div class="wa-card ${st === 'APROVADA' ? 'ok' : 'bad'}">
                    <div class="wa-card-title">Renovação ${st === 'APROVADA' ? 'aprovada' : 'recusada'}</div>
                    <strong>Comentário do gerenciador:</strong> ${escapeHtml(r.COMENTARIO_ADMIN || '—')}
                </div>` });
        }
    });

    ev.sort((a, b) => a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : (a.ord - b.ord) || (a.id - b.id));
    let html = '', ultimoDia = '';
    ev.forEach(e => {
        const dia = waDia(e.ts);
        if (dia && dia !== ultimoDia) { html += `<div class="wa-day"><span>${waRotuloDia(dia)}</span></div>`; ultimoDia = dia; }
        html += e.html;
    });
    return html;
}

function renderConversa(opts = {}) {
    const vazio = document.getElementById('waEmpty');
    const conv = document.getElementById('waConversa');
    const emp = currentChatId == null ? null : waBuscarEmp(currentChatId);
    if (!emp) { conv.style.display = 'none'; vazio.style.display = 'flex'; return; }
    vazio.style.display = 'none';
    conv.style.display = 'flex';

    document.getElementById('waHeadAvatar').innerHTML = WA_ICONE_LAB;
    const n = (emp.ITENS || []).length;
    document.getElementById('waHeadSub').textContent = `Empréstimo #${emp.IDEMPRESTIMO} · ${n} item${n !== 1 ? 'ns' : ''}`;
    document.getElementById('waHeadStatus').innerHTML = waStatus(emp.STATUS);
    waBarraAcoes(emp);

    const encerrado = waEncerrado(emp);
    const s = String(emp.STATUS).toUpperCase();
    document.getElementById('waInputArea').style.display = encerrado ? 'none' : 'flex';
    const fechado = document.getElementById('waClosed');
    fechado.style.display = encerrado ? 'block' : 'none';
    fechado.textContent = s === 'DEVOLVIDO'
        ? 'Empréstimo concluído. Este chat não aceita mais mensagens.'
        : `Empréstimo ${s === 'RECUSADO' ? 'recusado' : 'cancelado'}. Este chat não aceita mais mensagens.`;

    const box = document.getElementById('waMessages');
    const noFim = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    const anterior = box.scrollTop;
    box.innerHTML = waMontarLinhaDoTempo(emp);
    box.scrollTop = (opts.irParaFim || noFim) ? box.scrollHeight : anterior;
}

// ── dados ──
async function carregarMeusEmprestimos() {
    const resposta = await fetch('menu_principal.php?acao=listar_meus_emprestimos', { method: 'GET', credentials: 'same-origin', cache: 'no-store' });
    const dados = await resposta.json();
    if (!dados.sucesso) throw new Error(dados.mensagem || 'Erro ao carregar empréstimos.');
    meusEmprestimos = dados.emprestimos || [];
    if (!waVistosExistia) {
        meusEmprestimos.forEach(e => { waVistos[e.IDEMPRESTIMO] = waUltimoIdMsg(e); });
        waVistosExistia = true;
        waSalvarVistos();
    }
    atualizarBadgeChat();
    return meusEmprestimos;
}

// ── tempo real (polling leve a cada 3s) ──
async function sincronizarChat(forcar = false, opts = {}) {
    if (MODO_CONVIDADO) return;
    if (!forcar && (waSincronizando || document.hidden)) return;
    if (!forcar) waSincronizando = true;
    try {
        const res = await fetch('menu_principal.php?acao=resumo_meus_emprestimos', { credentials: 'same-origin', cache: 'no-store' });
        const data = await res.json();
        if (!data.sucesso) return;
        const assinatura = JSON.stringify(data.resumo);
        if (!forcar && assinatura === waAssinatura) return;
        waAssinatura = assinatura;
        await waAplicarAtualizacao(opts);
    } catch (e) { /* tenta de novo no próximo ciclo */ }
    finally { if (!forcar) waSincronizando = false; }
}
async function waAplicarAtualizacao(opts = {}) {
    const antes = new Map(meusEmprestimos.map(e => [String(e.IDEMPRESTIMO), { msg: waUltimoIdMsg(e), status: String(e.STATUS) }]));
    await carregarMeusEmprestimos();

    meusEmprestimos.forEach(e => {
        const id = String(e.IDEMPRESTIMO);
        const ant = antes.get(id);
        if (!ant) return;
        const vendo = waChatAberto && currentChatId == e.IDEMPRESTIMO && !document.hidden;
        const novas = (e.MENSAGENS || []).filter(m => Number(m.IDMENSAGEM) > ant.msg && m.USUARIO_TIPO === 'ADMINISTRADOR');
        if (novas.length && !vendo) stoktechToast(`Nova mensagem do gerenciador (empréstimo #${id})`, 'aviso');
        else if (String(e.STATUS) !== ant.status && !vendo) stoktechToast(`Empréstimo #${id}: ${String(e.STATUS).toLowerCase()}`, 'aviso');
    });

    if (waChatAberto) {
        const aberto = currentChatId == null ? null : waBuscarEmp(currentChatId);
        if (aberto && !document.hidden) waMarcarVisto(aberto);
        renderListaChats();
        if (currentChatId != null) renderConversa(opts);
    }
    atualizarBadgeChat();
}

function waAjustarTextarea(el) { el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 130) + 'px'; }
function waConfigurar() {
    if (MODO_CONVIDADO) return;
    const campo = document.getElementById('waInput');
    document.getElementById('waSend').addEventListener('click', sendChatMessage);
    campo.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendChatMessage(); }
    });
    campo.addEventListener('input', () => waAjustarTextarea(campo));
    document.getElementById('waBack').addEventListener('click', waVoltarLista);
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) return;
        if (waChatAberto && currentChatId != null) {
            const e = waBuscarEmp(currentChatId);
            if (e) { waMarcarVisto(e); renderListaChats(); atualizarBadgeChat(); }
        }
        sincronizarChat();
    });
    carregarMeusEmprestimos().catch(() => {});   // já mostra o contador de não lidas no header
    setInterval(() => sincronizarChat(), WA_INTERVALO_MS);
}

async function sendChatMessage() {
    const input = document.getElementById('waInput');
    const btn = document.getElementById('waSend');
    const msg = input.value.trim();
    if (!msg || currentChatId === null || currentChatId === undefined || waEnviando) return;

    waEnviando = true;
    btn.disabled = true;
    try {
        const resposta = await fetch('menu_principal.php?acao=enviar_mensagem_emprestimo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ idemprestimo: currentChatId, mensagem: msg })
        });
        const texto = await resposta.text();

        let dados;
        try {
            dados = JSON.parse(texto);
        } catch (erroJson) {
            stoktechToast('O PHP não retornou JSON. Resposta: ' + texto.substring(0, 300), 'erro');
            console.error(texto);
            return;
        }

        if (!dados.sucesso) {
            stoktechToast(dados.mensagem || 'Erro ao enviar mensagem.', 'erro');
            await sincronizarChat(true);
            return;
        }

        input.value = '';
        waAjustarTextarea(input);
        await sincronizarChat(true, { irParaFim: true });
    } catch (e) {
        stoktechToast('Erro de conexão ao enviar mensagem: ' + e.message, 'erro');
        console.error(e);
    } finally {
        waEnviando = false;
        btn.disabled = false;
        input.focus();
    }
}

async function solicitarRenovacao() {
    if (currentChatId === null || currentChatId === undefined) return;

    const novaData = prompt('Digite a nova data de devolução no formato AAAA-MM-DD:');
    if (novaData === null) return;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(novaData.trim())) {
        alert('Data inválida. Use o formato AAAA-MM-DD.');
        return;
    }

    const motivo = prompt('Explique o motivo da renovação:');
    if (motivo === null) return;
    if (motivo.trim() === '') {
        alert('O motivo da renovação é obrigatório.');
        return;
    }

    try {
        const res = await fetch('menu_principal.php?acao=solicitar_renovacao', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ idemprestimo: currentChatId, nova_data: novaData.trim(), motivo: motivo.trim() })
        });
        const data = await res.json();
        if (!data.sucesso) { alert(data.mensagem); return; }

        showNotification(data.mensagem);
        await sincronizarChat(true, { irParaFim: true });
    } catch (e) {
        alert('Erro de conexão ao solicitar renovação.');
        console.error(e);
    }
}

// ── NOTIFICATION ──
function showNotification(msg) {
    stoktechToast(msg, 'sucesso');
}
</script>
    <script src="js/protecao.js"></script>


        <!-- MODAL CONFIRMAR EMAIL -->

    <div id="modalConfirmarEmail" class="modal-email">

        <div class="modal-email-box">

            <h2>Confirmar novo email</h2>

            <p>
                Enviamos um código de confirmação para o novo email informado.
            </p>

            <input 
                type="text"
                id="codigoConfirmacaoEmail"
                maxlength="6"
                placeholder="Digite o código"
            >

            <button 
                type="button"
                onclick="confirmarEmailNovo()">
                Confirmar
            </button>

            <button 
                type="button"
                onclick="fecharModalEmail()">
                Cancelar
            </button>

        </div>

    </div>


</body>
</html>
</body>
</html>