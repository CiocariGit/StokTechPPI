<?php
// Inclua este arquivo sempre que uma ação do sistema precisar avisar
// um aluno pela aba "Notificações" da conta dele.
// require_once 'notificacoes_helper.php';

/**
 * Cria uma notificação para um usuário.
 * Nunca lança exceção: se a tabela NOTIFICACAO ainda não existir
 * (script SQL não executado) ou a inserção falhar, apenas ignora,
 * para não interromper a ação principal (aprovar pedido, etc).
 *
 * @param string $tipo INFO | SUCESSO | ALERTA | ERRO
 */
function criarNotificacao(PDO $pdo, int $idUsuario, string $titulo, string $mensagem, string $tipo = 'INFO', ?int $idEmprestimo = null): void
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO NOTIFICACAO (IDUSUARIO, TITULO, MENSAGEM, TIPO, IDEMPRESTIMO, LIDA, CRIADA_EM)
            VALUES (?, ?, ?, ?, ?, 0, NOW())
        ");
        $stmt->execute([$idUsuario, $titulo, $mensagem, $tipo, $idEmprestimo]);
    } catch (Throwable $e) {
        // silencioso de propósito — ver comentário acima
    }
}