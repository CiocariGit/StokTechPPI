<?php

session_start();

require_once 'conexao.php';
require_once 'auth.php';

header('Content-Type: application/json; charset=utf-8');


$id = $_SESSION['idusuario'];


$nome  = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';



if (!$nome || !$email) {

    echo json_encode([
        'sucesso'=>false,
        'mensagem'=>'Nome e email são obrigatórios.'
    ]);

    exit;
}



if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    echo json_encode([
        'sucesso'=>false,
        'mensagem'=>'Email inválido.'
    ]);

    exit;
}



// Dados atuais

$stmt = $pdo->prepare("
    SELECT EMAIL,FOTO_PERFIL
    FROM USUARIO
    WHERE IDUSUARIO=?
");

$stmt->execute([$id]);

$atual = $stmt->fetch();



$emailAtual = $atual['EMAIL'];



// Verifica email duplicado

$stmt = $pdo->prepare("
    SELECT IDUSUARIO
    FROM USUARIO
    WHERE EMAIL=?
    AND IDUSUARIO!=?
");

$stmt->execute([
    $email,
    $id
]);


if($stmt->fetch()){

    echo json_encode([
        'sucesso'=>false,
        'mensagem'=>'Este email já está sendo usado.'
    ]);

    exit;
}



// Foto

$foto = null;


if(isset($_FILES['foto']) && $_FILES['foto']['error']==0){


    $pasta="img/perfis/";


    if(!is_dir($pasta)){
        mkdir($pasta,0755,true);
    }



    $ext=strtolower(
        pathinfo(
            $_FILES['foto']['name'],
            PATHINFO_EXTENSION
        )
    );


    $permitidos=[
        'jpg',
        'jpeg',
        'png',
        'webp'
    ];



    if(!in_array($ext,$permitidos)){

        echo json_encode([
            'sucesso'=>false,
            'mensagem'=>'Formato de imagem inválido.'
        ]);

        exit;

    }



    $nomeArquivo =
    "perfil_".$id."_".time().".".$ext;



    move_uploaded_file(
        $_FILES['foto']['tmp_name'],
        $pasta.$nomeArquivo
    );


    $foto=$pasta.$nomeArquivo;



}



// Senha

$novaSenha=null;


if(!empty($senha)){


    if(strlen($senha)<6){

        echo json_encode([
            'sucesso'=>false,
            'mensagem'=>'A senha precisa ter 6 caracteres.'
        ]);

        exit;

    }


    $novaSenha=password_hash(
        $senha,
        PASSWORD_DEFAULT
    );

}



// Confirmação de email

$emailPendente=false;


if($email!=$emailAtual){


    $codigo=random_int(
        100000,
        999999
    );


    $expira=date(
        'Y-m-d H:i:s',
        strtotime('+10 minutes')
    );



    $stmt=$pdo->prepare("
        INSERT INTO CONFIRMACAO_EMAIL
        (
            IDUSUARIO,
            NOVO_EMAIL,
            CODIGO,
            EXPIRA
        )
        VALUES(?,?,?,?)
    ");



    $stmt->execute([

        $id,
        $email,
        $codigo,
        $expira

    ]);



    require_once 'email_helper.php';



    enviarEmail(

        $email,

        'Confirmação de novo email - StokTech',

        "

        <h2>
        Confirme seu novo email
        </h2>


        <p>
        Foi solicitada uma alteração de email na sua conta.
        </p>


        <p>
        Seu código:
        </p>


        <h1 style='color:#b662ff'>
        $codigo
        </h1>


        <p>
        O código expira em 10 minutos.
        </p>

        "

    );



    $emailPendente=true;


    // mantém o antigo até confirmar

    $email=$emailAtual;

}



// Monta update


$campos=[
    "NOME=?",
    "EMAIL=?"
];


$valores=[
    $nome,
    $email
];



if($novaSenha){

    $campos[]="SENHA=?";

    $valores[]=$novaSenha;

}



if($foto){

    $campos[]="FOTO_PERFIL=?";

    $valores[]=$foto;

}



$valores[]=$id;



$sql="
UPDATE USUARIO
SET ".implode(",",$campos)."
WHERE IDUSUARIO=?
";



$stmt=$pdo->prepare($sql);

$stmt->execute($valores);





$_SESSION['nome']=$nome;



if(!$emailPendente){

    $_SESSION['email']=$email;

}



if($foto){

    $_SESSION['foto_perfil']=$foto;

}



echo json_encode([

    'sucesso'=>true,

    'email_pendente'=>$emailPendente,

    'mensagem'=>

    $emailPendente

    ?

    'Código enviado para o novo email.'

    :

    'Perfil atualizado com sucesso.'

]);