<?php

require_once 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


function enviarEmail($destinatario, $assunto, $conteudo)
{
    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();
        $mail->Host       = 'smtp-stoktech.alwaysdata.net';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'stoktech@alwaysdata.net';
        $mail->Password   = 'StokTech2026@';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';


        $mail->setFrom(
            'stoktech@alwaysdata.net',
            'StokTech'
        );

        $mail->addAddress($destinatario);


        $mail->isHTML(true);

        $mail->Subject = $assunto;

        $mail->Body = "

        <div style='
        background:#0d0d0f;
        color:white;
        padding:30px;
        font-family:Arial;
        border-radius:10px;'>

        <h2>
        Stok<span style='color:#b662ff'>Tech</span>
        </h2>

        <hr>

        $conteudo

        </div>";

        $mail->send();

        return true;


    } catch(Exception $e){

        return false;

    }

}